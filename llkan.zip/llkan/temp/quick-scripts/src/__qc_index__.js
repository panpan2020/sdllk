
require('./assets/migration/use_v2.0.x_cc.Toggle_event');
require('./assets/scripts/EventManager');
require('./assets/scripts/end');
require('./assets/scripts/game');
require('./assets/scripts/load');
require('./assets/scripts/notice');
require('./assets/scripts/rank');
require('./assets/scripts/sandian');
require('./assets/scripts/shake');
require('./assets/scripts/table');
require('./assets/scripts/utools');
