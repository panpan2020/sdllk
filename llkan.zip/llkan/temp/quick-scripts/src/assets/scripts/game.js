"use strict";
cc._RF.push(module, '12975PGgwpC9qlWdgdPHssT', 'game');
// scripts/game.js

"use strict";

/**
 * 连连看主脚本文件
 * 
 * by 慕容秋 muroqiu@qq.com
 * 2018-02-25
 * 
 * 主要的逻辑：
 * A、洗牌 shuffle：遍历图片数组，取1个随机位置的图片和当前位置交换；
 * B、用一个二维数组（各个方向均比图片数组大1）保存图片的状态值，搜索路径时映射到这个数组搜索；
 * C、搜索顺序：
 *    1、同一条直线：判断直线间有无图片；
 *    2、有一个拐角：先定位出两个拐角点，若拐角点没有图片，再转换成一条直线的情况继续处理；
 *    3、两个拐角：某个方向移动，若到达点没有图片，再转换成一个拐角的情况继续处理；若到达点有图片，此方向不再继续搜索；
 */
// import { rndName } from "./utools";
var utools = require("./utools"); // import {shake} from './shage';


cc.Class({
  "extends": cc.Component,
  properties: {
    itemPrefab: cc.Prefab,
    spriteWin: cc.SpriteFrame,
    spriteLose: cc.SpriteFrame,
    spriteframeList: [cc.SpriteFrame],
    imageList: [cc.node],
    timeout: cc.Label,
    BtnAudio: cc.AudioClip,
    ErrorAudio: cc.AudioClip,
    SuccessAudio: cc.AudioClip,
    ContinueAudio: cc.AudioClip,
    bgMusicAudio: cc.AudioClip,
    endNode: cc.Node,
    gameScore: cc.Label,
    cameraNode: cc.Node,
    btnPreNode: cc.Button,
    tipsNode: cc.Label,
    winAudio: cc.AudioClip,
    failedAudio: cc.AudioClip,
    gameOverLab: cc.Label,
    _graphics: cc.Graphics,
    noticeNode: cc.Node,
    randBtn: cc.Button,
    rankPrefab: cc.Prefab,
    rankListNode: cc.Node,
    nickName: cc.Label,
    // 行数
    rows: 4,
    // 列数
    columns: 4,
    // 总的图片对数 = lines*rows/2，当为0时，表示已经全部消除 
    pairs: 8,
    // 倒计时
    duration: 20,
    count: 1,
    spriteWidth: 80,
    spriteHeight: 80,
    paddingLeft: 200,
    paddingTop: 500,
    // 图片状态： 消除
    _TYPE_DELED: -2,
    // 图片状态： 初始化
    _TYPE_INIT: -1,
    // 二维数组，比图片数组大一圈，记录图片状态值
    _canvasGrids: null,
    _lastClickX: -1,
    _lastClickY: -1,
    //背景音效
    _isPauseMusic: true,
    //score
    _score: 0,
    _totalScore: 0,
    //动画
    _aniShow: null,
    //结束时UI倒计时
    _overTMS: 5,
    //排行榜
    _rankListData: []
  },
  // use this for initialization

  /**
   * 系统加载事件
   */
  onLoad: function onLoad() {
    this.nickName.string = utools.rndName(3);
    this.timer = 0;
    this._graphics = this.node.getChildByName("graphics").getComponent(cc.Graphics);
    this._graphics.lineWidth = 5;
    this.rankListNode.active = false;

    this._initAnimal();

    this._setTipsLabNode(false);

    this._canvasGrids = new Array(); //在声明二维

    for (var i = 0; i < this.rows + 2; i++) {
      this._canvasGrids[i] = new Array(i);

      for (var j = 0; j < this.columns + 2; j++) {
        this._canvasGrids[i][j] = -1;
      }
    }

    this.imageList = new Array();

    for (var i = 0; i < this.rows; i++) {
      this.imageList[i] = new Array(i);

      for (var j = 0; j < this.columns; j++) {
        this.imageList[i][j] = null;
      }
    } // console.log("-----------ddd---------")


    this.initData();
    this.initMap();

    this._resetGame();

    this._setPauseBgMusic();

    this.gameScore.string = this._score;
    this.gameOverLab.string = "-5";

    this._doneMusic(false);

    this._initNoticeNode();

    this._initScrollView();
  },
  _initNoticeNode: function _initNoticeNode() {
    var self = this;
    setTimeout(function () {
      if (!self.noticeNode) {
        var tt = self.noticeNode.getComponent("notice"); // <color=#00FF00>玩家</c> <color=#7FFF00>厉害</c>厉害<color=#FFFF00>oo</c>

        tt.addStrToList("<color=#0FFF50>欢迎体验闪电连连看,如你有任何问题请点击头像告诉我哟!</c>");

        self._initNoticeNode();
      }
    }, 3000);
  },
  _setTipsLabNode: function _setTipsLabNode(flag) {
    this.tipsNode.node.active = flag;
    this.timeout.node.color = new cc.color(255, 255, 255);
  },
  btnEvent2Pre: function btnEvent2Pre() {
    cc.audioEngine.pauseAllEffects();
    cc.director.loadScene("load");
  },
  _doneMusic: function _doneMusic(sign) {
    if (sign) this._isPauseMusic = !this._isPauseMusic; // console.log("------------------",this._isPauseMusic)

    if (this._isPauseMusic) {// cc.audioEngine.playEffect(this.bgMusicAudio, true,1);
    } else {
      cc.audioEngine.pauseAllEffects();
    }
  },
  _setPauseBgMusic: function _setPauseBgMusic() {
    var self = this;
    this.node.getChildByName("pause").on(cc.Node.EventType.TOUCH_END, function (event) {
      self._doneMusic(true);
    });
  },
  _resetGame: function _resetGame() {
    var self = this;
    this.node.getChildByName("refresh").on(cc.Node.EventType.TOUCH_END, function (event) {
      cc.audioEngine.playEffect(self.ContinueAudio, false);
      cc.director.loadScene('game');
    });
  },

  /**
   * 初始化数据
   */
  initData: function initData() {
    for (var row = 0; row < this.rows; row++) {
      for (var column = 0; column < this.columns; column++) {
        var newNode = cc.instantiate(this.itemPrefab); //复制预制资源

        var index = row * this.rows + column;
        var type = index % this.spriteframeList.length; // console.log("------>>---", newNode.getChildByName("Background").getComponent(cc.Sprite))

        newNode.getChildByName("Background").getComponent(cc.Sprite).spriteFrame = this.spriteframeList[type];
        newNode.isempty = false;
        newNode.type = type;
        newNode.index = index;
        newNode.score = Math.floor(Math.random() * 10);
        this.imageList[row][column] = newNode; // type >= 0，为实际的图片类型值

        this._canvasGrids[row + 1][column + 1] = type;
      }
    }

    this.shuffle();
  },

  /**
   * 洗牌
   */
  shuffle: function shuffle() {
    for (var i = this.rows * this.columns - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var x = i % this.rows;
      var y = Math.floor(i / this.rows);
      var x_tmp = j % this.rows;
      var y_tmp = Math.floor(j / this.rows);
      var temp = this.imageList[x][y];
      this.imageList[x][y] = this.imageList[x_tmp][y_tmp];
      this.imageList[x_tmp][y_tmp] = temp;
    }
  },

  /**
   * 初始化
   */
  initMap: function initMap() {
    for (var row = 0; row < this.rows; row++) {
      for (var column = 0; column < this.columns; column++) {
        var newNode = this.imageList[row][column];
        this.node.addChild(newNode);
        newNode.setPosition(cc.Vec2(this.spriteWidth * row - this.paddingLeft, this.spriteHeight * column - this.paddingTop));
        newNode.pointX = row;
        newNode.pointY = column;
        newNode.on(cc.Node.EventType.TOUCH_END, this._clickNode, this);
      }
    }
  },
  _clickNode: function _clickNode(d) {
    cc.audioEngine.playEffect(this.BtnAudio, false); // console.log("-----_clickNode---------",node.currentTarget.getComponent("pic") )

    var self = this; // let  node = d.currentTarget.getComponent("pic");

    var node = d.currentTarget;
    var lastNode = null;

    if (self._lastClickX != -1 && self._lastClickY != -1) {
      lastNode = self.imageList[self._lastClickX][self._lastClickY];
    } // console.log("-----3--------",lastNode)
    // 存储第一次点击对象ID


    if (self._lastClickX == -1 || self._lastClickX == -1) {
      //   console.log("-----2--------")
      self._lastClickX = node.pointX;
      self._lastClickY = node.pointY;
    } else if (self._lastClickX == node.pointX && self._lastClickY == node.pointY) {// console.log("---3--不做任何处理--------")
    } else if (lastNode.type == node.type) {
      //如果相同图片
      if (self.isLinked(self._lastClickX, self._lastClickY, node.pointX, node.pointY)) {
        //并且可连通
        self._setUIScore(lastNode.score, node.score); // node.scheduleOnce(  ()=>{


        setTimeout(function () {
          // 这里的 this 指向 component
          self.clearLinked(self._lastClickX, self._lastClickY, node.pointX, node.pointY);
          self._lastClickX = -1;
          self._lastClickY = -1;
        }, 100);
      } else {
        self._lastClickX = node.pointX;
        self._lastClickY = node.pointY; // cc.audioEngine.playEffect(self.ErrorAudio, false);
      }
    } else {
      self._lastClickX = node.pointX;
      self._lastClickY = node.pointY;
    }
  },

  /**
   * 消除已连接
   * newNode.getChildByName("Background").getComponent(cc.Sprite).spriteFrame
   */
  clearLinked: function clearLinked(x1, y1, x2, y2) {
    this.imageList[x1][y1].getChildByName("Background").getComponent(cc.Sprite).spriteFrame = null; // console.log("----2------->>>---",this.imageList[x2][y2] )

    this.imageList[x2][y2].getChildByName("Background").getComponent(cc.Sprite).spriteFrame = null;
    this._canvasGrids[x1 + 1][y1 + 1] = this._TYPE_DELED;
    this._canvasGrids[x2 + 1][y2 + 1] = this._TYPE_DELED;
    cc.audioEngine.playEffect(this.SuccessAudio, false);

    this._graphics.clear();

    this.pairs -= 1; // console.log("----3------->>>---")

    if (this.pairs == 0) this.gamePass();
  },

  /**
   * 根据矩阵XY获取绝对坐标
   */
  getAbsXY: function getAbsXY(x, y) {
    var absX = 0;
    var absY = 0;

    if (x < 0) {
      absX = this.node.x + this.imageList[0][0].x - this.imageList[0][0].width;
    } else if (x >= this.rows) {
      absX = this.node.x + this.imageList[this.rows - 1][0].x + this.imageList[0][0].width;
    } else {
      absX = this.node.x + this.imageList[x][0].x;
    }

    if (y < 0) {
      absY = this.node.y + this.imageList[0][0].y - this.imageList[0][0].height;
    } else if (y >= this.columns) {
      absY = this.node.y + this.imageList[0][this.columns - 1].y + this.imageList[0][0].height;
    } else {
      absY = this.node.y + this.imageList[0][y].y;
    }

    return [absX, absY];
  },

  /**
   * 是否连通
   */
  isLinked: function isLinked(x1, y1, x2, y2) {
    var tmpXY = [];
    var tmpAbsXY = [];

    if (this.matchBlockLine(x1, y1, x2, y2)) {
      // 直线
      tmpAbsXY = this.getAbsXY(x1, y1);

      this._graphics.moveTo(tmpAbsXY[0], tmpAbsXY[1]);

      tmpAbsXY = this.getAbsXY(x2, y2);

      this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

      this._graphics.stroke();

      return true;
    } else {
      tmpXY = this.matchBlockCorner(x1, y1, x2, y2, null);

      if (tmpXY) {
        // 一个转角
        tmpAbsXY = this.getAbsXY(x1, y1);

        this._graphics.moveTo(tmpAbsXY[0], tmpAbsXY[1]);

        tmpAbsXY = this.getAbsXY(tmpXY[0], tmpXY[1]);

        this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

        tmpAbsXY = this.getAbsXY(x2, y2);

        this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

        this._graphics.stroke();

        return true;
      } else {
        tmpXY = this.matchBlockUnfold(x1, y1, x2, y2);

        if (tmpXY) {
          // 两个转角
          tmpAbsXY = this.getAbsXY(x1, y1);

          this._graphics.moveTo(tmpAbsXY[0], tmpAbsXY[1]);

          tmpAbsXY = this.getAbsXY(tmpXY[0], tmpXY[1]);

          this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

          tmpAbsXY = this.getAbsXY(tmpXY[2], tmpXY[3]);

          this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

          tmpAbsXY = this.getAbsXY(x2, y2);

          this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

          this._graphics.stroke();

          return true;
        }
      }
    }

    return false;
  },

  /**
   * 直连
   */
  matchBlockLine: function matchBlockLine(x1, y1, x2, y2) {
    // cc.warn('matchBlock  ' + x1 + ', ' + y1 + '  : ' + x2 + ', ' + y2);
    if (x1 != x2 && y1 != y2) {
      return false;
    }

    if (x1 == x2) {
      // 同一列
      if (x1 < 0 || x1 >= this.rows) {
        return true;
      }

      var Ymin = Math.min(y1, y2) + 1;
      var Ymax = Math.max(y1, y2);

      for (Ymin; Ymin < Ymax; Ymin++) {
        if (this._canvasGrids[x1 + 1][Ymin + 1] > this._TYPE_INIT) {
          return false;
        }
      }
    } else if (y1 == y2) {
      // 同一行
      if (y1 < 0 || y1 >= this.columns) {
        return true;
      }

      var Xmin = Math.min(x1, x2) + 1;
      var Xmax = Math.max(x1, x2);

      for (Xmin; Xmin < Xmax; Xmin++) {
        if (this._canvasGrids[Xmin + 1][y1 + 1] > this._TYPE_INIT) {
          return false;
        }
      }
    }

    return true;
  },

  /**
   * 转角逻辑
   */
  matchBlockCorner_point: function matchBlockCorner_point(x1, y1, x2, y2, x3, y3) {
    var stMatch = this.matchBlockLine(x1, y1, x3, y3);

    if (stMatch) {
      var tdMatch = this.matchBlockLine(x3, y3, x2, y2);

      if (tdMatch) {
        return [x3, y3];
      }
    }

    return null;
  },

  /**
   * 一个转角
   * 搜索到路径时，返回转角坐标 x3, y3
   */
  matchBlockCorner: function matchBlockCorner(x1, y1, x2, y2, isAxis_X) {
    // cc.warn('matchBlockCorner  ' + x1 + ', ' + y1 + '  : ' + x2 + ', ' + y2);
    var result; // 直连的返回

    if (x1 == x2 || y1 == y2) {
      return null;
    } // 转角点1 (x1, y2)，Y方向


    if (this._canvasGrids[x1 + 1][y2 + 1] <= this._TYPE_INIT && isAxis_X != false) {
      result = this.matchBlockCorner_point(x1, y1, x2, y2, x1, y2);

      if (result) {
        return result;
      }
    } // 转角点2 (x2, y1)，X方向


    if (this._canvasGrids[x2 + 1][y1 + 1] <= this._TYPE_INIT && isAxis_X != true) {
      result = this.matchBlockCorner_point(x1, y1, x2, y2, x2, y1);

      if (result) {
        return result;
      }
    }

    return null;
  },

  /**
   * 某个方向上的搜索逻辑
   */
  matchBlockUnfold_axis: function matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, isAxis_X) {
    var tmpXY = [];

    if (this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT) {
      tmpXY = this.matchBlockCorner(x3, y3, x2, y2, isAxis_X);

      if (tmpXY) {
        return [x3, y3].concat(tmpXY);
        ;
      }
    }

    return null;
  },

  /**
   * 由中心往外展开搜索路径，某个方向当碰到有图片时，这个方向就不再继续搜索
   * 搜索到路径时，返回两个转角点坐标 x3, y3, x4, y4
   */
  matchBlockUnfold: function matchBlockUnfold(x1, y1, x2, y2) {
    var result;
    var x3 = 0;
    var y3 = 0;
    var canUp = true;
    var canDown = true;
    var canLeft = true;
    var canRight = true; // cc.warn('matchBlockUnfold  ' + x1 + ', ' + y1 + '  : ' + x2 + ', ' + y2);

    for (var i = 1; i < this.rows; i++) {
      // 上
      x3 = x1;
      y3 = y1 + i;

      if (canUp && y3 <= this.columns) {
        canUp = this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT;
        result = this.matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, false);

        if (result) {
          return result;
        }
      } // 下


      x3 = x1;
      y3 = y1 - i;

      if (canDown && y3 >= -1) {
        canDown = this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT;
        result = this.matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, false);

        if (result) {
          return result;
        }
      } // 左


      x3 = x1 - i;
      y3 = y1;

      if (canLeft && x3 >= -1) {
        canLeft = this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT;
        result = this.matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, true);

        if (result) {
          return result;
        }
      } // 右


      x3 = x1 + i;
      y3 = y1;

      if (canRight && x3 <= this.rows) {
        canRight = this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT;
        result = this.matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, true);

        if (result) {
          return result;
        }
      }
    }

    return null;
  },
  _initAnimal: function _initAnimal() {
    this._aniShow = this.endNode.getComponent(cc.Animation);
    this._aniShow.node.active = false;

    this._aniShow.hideEnd = function () {
      this._aniShow.node.active = false;
    }.bind(this); // this._aniShow.node.on(cc.Node.EventType.MOUSE_DOWN,this.closeHandle,this);

  },
  closeHandle: function closeHandle(e, d) {
    // console.log("-----closeHandle----------",e,d)
    this._aniShow.node.active = false;
    cc.director.loadScene('game');
  },

  /**
   * 游戏结束
   */
  gameOver: function gameOver() {
    this.count = 0;
    this.timer = 0;
    cc.audioEngine.pauseAllEffects(); // console.log("-------gameOver-----------",this._score, this.rows * this.columns,this.endNode.getChildByName("win"))

    if (this._score < this.rows * this.columns / 2) {
      cc.audioEngine.playEffect(this.failedAudio, false);
      this.endNode.getChildByName("win").active = false;
      this.endNode.getChildByName("lose").active = true;
      this.endNode.getChildByName("lose").getComponent(cc.Sprite).spriteFrame = this.spriteLose;
    } else {
      cc.audioEngine.playEffect(this.winAudio, false);
      this.endNode.getChildByName("win").active = true;
      this.endNode.getChildByName("lose").active = false;
      this.endNode.getChildByName("win").getComponent(cc.Sprite).spriteFrame = this.spriteWin;
    }

    this._aniShow.node.active = true;

    var state = this._aniShow.play('scaleShow', 1);

    state.repeatCount = 1;
    this._aniShow.node.zIndex = 1000;
    this.gameOverLab.string = "-5";
  },

  /**
   * 过关
   */
  gamePass: function gamePass() {// cc.director.loadScene('gamepass');
  },
  // called every frame, uncomment this function to activate update callback

  /**
   * 系统的更新事件
   */
  update: function update(dt) {
    this.timer += dt;

    if (this._aniShow.node.active) {
      if (this.timer > this.count) {
        this._overTMS--;

        if (this._overTMS < 1) {
          this.closeHandle();
          return;
        }

        this.count += 1;
      }

      this.gameOverLab.string = "-" + this._overTMS;
      return;
    } // 大于已计时秒数


    if (this.timer > this.count) {
      this.timeout.string = this.duration - this.count;

      if (this.count >= this.duration) {
        this.gameOver();
      }

      this.count += 1;

      this._timeLabAni();
    }
  },
  //小于10一下闪烁提示
  _timeLabAni: function _timeLabAni() {
    var tt = Number(this.timeout.string);

    if (tt > 0 && tt < 10) {
      // console.log("---------", tt)
      // this.timeout.node.color = new cc.color(255,1,1); 
      var ani = this.timeout.node.getComponent(cc.Animation);
      var state = ani.play();
      state.repeatCount = 2;
    }
  },
  _bindEvent: function _bindEvent() {// EventManager.getInstance().addEventListener("shake", this.addEvent, this);
  },
  _myShake: function _myShake() {
    var mk = this.cameraNode.getComponent("shake");
    mk.shaker();
  },
  _storageKey: function _storageKey() {
    return "rand_data_key";
  },
  _initScrollView: function _initScrollView() {
    //test
    //cc.sys.localStorage.setItem(this._storageKey(),  "{}" )
    var content = this.rankListNode.getChildByName("scroll").getComponent(cc.ScrollView).content;
    var lastRankString = cc.sys.localStorage.getItem(this._storageKey());

    if (!lastRankString || lastRankString.length < 10) {
      this._rankListData = this._getItemData(10);
    } else {
      this._rankListData = JSON.parse(lastRankString);
    }

    this._rankListData.sort(function (a, b) {
      return b.s3 - a.s3;
    }); // listData = this._getItemData(10)


    for (var i = 0; i < 10; i++) {
      var item = cc.instantiate(this.rankPrefab);
      item.index = i;
      item.parent = content;
      var table = item.getComponent("table");
      this._rankListData[i].s1 = i + 1;
      table.setLabContent(this._rankListData[i]);
    } // console.log("--333-listData---------",JSON.stringify(  this._rankListData) )


    cc.sys.localStorage.setItem(this._storageKey(), JSON.stringify(this._rankListData));
  },
  onActionRank: function onActionRank(e, d) {
    this.rankListNode.active = !this.rankListNode.active;
  },
  _getItemData: function _getItemData(max) {
    var list = [];

    for (var i = 0; i < max; i++) {
      list.push({
        s1: i + 1,
        s2: utools.rndName(3),
        s3: Math.floor(Math.random() * 1000)
      });
    } // console.log("--list>>---", list)


    list.sort(function (a, b) {
      return b.s3 - a.s3;
    });
    return list;
  },
  _addRankList: function _addRankList() {
    var data = {
      s1: 1,
      s2: this.nickName.string,
      s3: this._score
    }; // console.log("-------_addRankList--------", data)

    var gend = this._rankListData[this._rankListData.length - 1]; // console.log("-------_addRankList--------", gend)

    if (gend.s3 > data.s3) {
      return;
    }

    for (var i = 0; i < this._rankListData.length; i++) {
      if (this._rankListData[i].s2 == data.s2 && this._rankListData[i].s3 < data.s3) {
        this._rankListData[i] = data;
        return;
      }
    }

    this._rankListData.push(data);

    this._rankListData.sort(function (a, b) {
      return b.s3 - a.s3;
    });
  },
  _setUIScore: function _setUIScore(lastScore, crtScore) {
    this._score += 2;
    this.gameScore.string = this._score;

    this._myShake(); // console.log("------_setUIScore-----",this._score , this.rows * this.columns)
    //是否刷新


    if (this._score >= this.rows * this.columns) {
      this._totalScore++; // this._resetGame()

      this.gameOver();
    }

    this._addRankList();
  }
});

cc._RF.pop();