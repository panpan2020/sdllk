"use strict";
cc._RF.push(module, '0266dbnzpVDpap1UcxUZw6r', 'shake');
// scripts/shake.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    _state: "idle"
  },
  onLoad: function onLoad() {},
  setAll: function setAll(x, y, times, duration) {
    // console.log("-------setAll-------------",x, y, times, duration)
    this.amplitudeX = x;
    this.amplitudeY = y;
    this.duration = duration;
    this.times = times;
  },
  shaker: function shaker(type) {
    if (type === void 0) {
      type = "out";
    }

    var node = this.node;
    this.shakeObj = {
      node: node,
      originPos: node.position,
      offset: cc.v2(15, 20),
      times: 4,
      duration: 0.4,
      startTime: Date.now(),
      amplitudeModifier: "out"
    };
    this.shakeObj.amplitudeModifier = type;
    this._state = "shaker";
    this.curTime = 0;
  },
  start: function start() {},
  update: function update(dt) {
    if (this._state == "shaker") {
      var shakeObj = this.shakeObj;
      this.node.position = cc.Vec2.ZERO;
      this.curTime += dt;
      var aX = shakeObj.offset.x;
      var aY = shakeObj.offset.y;
      var n = shakeObj.times;
      var duration = shakeObj.duration;
      var range = n * 2 * Math.PI;
      var am = shakeObj.amplitudeModifier;

      if (this.curTime < duration) {
        var factor = 1;
        var percent = this.curTime / duration;
        var angle = range * percent;
        var xo = aX * Math.cos(angle);
        var yo = aY * Math.sin(angle);

        if (am === "in") {
          factor = percent;
        } else if (am === "out") {
          factor = 1 - percent;
        } else if (am === "inOut") {
          factor = 2 * (percent < 0.5 ? percent : 1 - percent);
        }

        xo *= factor;
        yo *= factor;
        var p = Math.random() > 0.5 ? shakeObj.originPos.add(cc.v2(xo, yo)) : shakeObj.originPos.sub(cc.v2(xo, yo));
        shakeObj.node.position = p;
      } else {
        this._state = "idle";
        this.curTime = 0;
        shakeObj.node.position = shakeObj.originPos;
      }
    }
  }
});

cc._RF.pop();