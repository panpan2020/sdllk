"use strict";
cc._RF.push(module, '19353nRcxNDH5Of1JUWRefj', 'end');
// scripts/end.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // use this for initialization
  onLoad: function onLoad() {// var thebtn = cc.instantiate(this.btn);
    // this.node.addChild(thebtn);
    // thebtn.setPosition(cc.p(0, 0));
    // thebtn.on(cc.Node.EventType.TOUCH_END, function (event) {
    //     cc.director.loadScene('game');
    // });
  }
});

cc._RF.pop();