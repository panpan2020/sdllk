"use strict";
cc._RF.push(module, 'a8bb1WeJV9JI6KUmZK2jYpf', 'notice');
// scripts/notice.js

"use strict";

function _createForOfIteratorHelperLoose(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (it) return (it = it.call(o)).next.bind(it); if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; return function () { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

cc.Class({
  "extends": cc.Component,
  properties: {
    bg: cc.Node,
    richText: cc.RichText,
    _str_list: [],
    _running: false
  },
  onLoad: function onLoad() {
    console.log("========1=======");
    this._str_list = [];
    this._running = false;
  },
  start: function start() {
    this._str_list = []; // console.log("=======2======")

    this.unshowRichText(1);
  },
  addStrToList: function addStrToList(str) {
    this._str_list.push(str);

    if (!this._running) {
      this.showRichText(this._str_list.shift());
    }
  },
  showRichText: function showRichText(str) {
    var _this = this;

    // console.log("=======showRichText===========",this.node.position)
    this._running = true;

    if (this.bg != null && this.bg.getComponent(cc.Animation) != null) {
      this.bg.getComponent(cc.Animation).play('notice');
    }

    this._enableNode(true);

    this.richText.string = str;
    var maskWidth = cc.find('Mask', this.node).width; // console.log("=======4======",str,maskWidth)

    this.richText.node.x = maskWidth / 2 * 1.6;
    console.log("=======5======", this.richText.node.x, this.richText.node.width, -maskWidth - this.richText.node.width);
    this.richText.node.runAction(cc.sequence(cc.moveBy(10, cc.v2(-maskWidth - this.richText.node.width - 100, 0)), cc.callFunc(function () {
      console.log("=======43=====", str);

      if (_this._str_list.length > 0) {
        _this.showRichText(_this._str_list.shift());
      } else {
        _this.unshowRichText(2);

        _this._running = false;
      }
    })));
  },
  unshowRichText: function unshowRichText(from) {
    // console.log("---------stop----------", from)
    if (this.bg != null && this.bg.getComponent(cc.Animation) != null) {
      this.bg.getComponent(cc.Animation).stop('notice');
    }

    this._enableNode(false);
  },
  _enableNode: function _enableNode(flag) {
    for (var _iterator = _createForOfIteratorHelperLoose(this.node.children), _step; !(_step = _iterator()).done;) {
      var item = _step.value;
      item.active = flag;
    }
  }
});

cc._RF.pop();