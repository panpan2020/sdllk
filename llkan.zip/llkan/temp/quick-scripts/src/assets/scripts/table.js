"use strict";
cc._RF.push(module, '9ba34lAu6NG8KupHeC87EBN', 'table');
// scripts/table.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    nameLab: cc.Label,
    duanwieLab: cc.Label,
    zhanjiLab: cc.Label
  },
  start: function start() {},
  // update (dt) {},
  setLabContent: function setLabContent(data) {
    this.nameLab.string = data.s1;
    this.duanwieLab.string = data.s2;
    this.zhanjiLab.string = data.s3;
  }
});

cc._RF.pop();