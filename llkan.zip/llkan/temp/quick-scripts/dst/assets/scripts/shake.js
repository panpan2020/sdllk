
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/shake.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0266dbnzpVDpap1UcxUZw6r', 'shake');
// scripts/shake.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    _state: "idle"
  },
  onLoad: function onLoad() {},
  setAll: function setAll(x, y, times, duration) {
    // console.log("-------setAll-------------",x, y, times, duration)
    this.amplitudeX = x;
    this.amplitudeY = y;
    this.duration = duration;
    this.times = times;
  },
  shaker: function shaker(type) {
    if (type === void 0) {
      type = "out";
    }

    var node = this.node;
    this.shakeObj = {
      node: node,
      originPos: node.position,
      offset: cc.v2(15, 20),
      times: 4,
      duration: 0.4,
      startTime: Date.now(),
      amplitudeModifier: "out"
    };
    this.shakeObj.amplitudeModifier = type;
    this._state = "shaker";
    this.curTime = 0;
  },
  start: function start() {},
  update: function update(dt) {
    if (this._state == "shaker") {
      var shakeObj = this.shakeObj;
      this.node.position = cc.Vec2.ZERO;
      this.curTime += dt;
      var aX = shakeObj.offset.x;
      var aY = shakeObj.offset.y;
      var n = shakeObj.times;
      var duration = shakeObj.duration;
      var range = n * 2 * Math.PI;
      var am = shakeObj.amplitudeModifier;

      if (this.curTime < duration) {
        var factor = 1;
        var percent = this.curTime / duration;
        var angle = range * percent;
        var xo = aX * Math.cos(angle);
        var yo = aY * Math.sin(angle);

        if (am === "in") {
          factor = percent;
        } else if (am === "out") {
          factor = 1 - percent;
        } else if (am === "inOut") {
          factor = 2 * (percent < 0.5 ? percent : 1 - percent);
        }

        xo *= factor;
        yo *= factor;
        var p = Math.random() > 0.5 ? shakeObj.originPos.add(cc.v2(xo, yo)) : shakeObj.originPos.sub(cc.v2(xo, yo));
        shakeObj.node.position = p;
      } else {
        this._state = "idle";
        this.curTime = 0;
        shakeObj.node.position = shakeObj.originPos;
      }
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2hha2UuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJfc3RhdGUiLCJvbkxvYWQiLCJzZXRBbGwiLCJ4IiwieSIsInRpbWVzIiwiZHVyYXRpb24iLCJhbXBsaXR1ZGVYIiwiYW1wbGl0dWRlWSIsInNoYWtlciIsInR5cGUiLCJub2RlIiwic2hha2VPYmoiLCJvcmlnaW5Qb3MiLCJwb3NpdGlvbiIsIm9mZnNldCIsInYyIiwic3RhcnRUaW1lIiwiRGF0ZSIsIm5vdyIsImFtcGxpdHVkZU1vZGlmaWVyIiwiY3VyVGltZSIsInN0YXJ0IiwidXBkYXRlIiwiZHQiLCJWZWMyIiwiWkVSTyIsImFYIiwiYVkiLCJuIiwicmFuZ2UiLCJNYXRoIiwiUEkiLCJhbSIsImZhY3RvciIsInBlcmNlbnQiLCJhbmdsZSIsInhvIiwiY29zIiwieW8iLCJzaW4iLCJwIiwicmFuZG9tIiwiYWRkIiwic3ViIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsTUFBTSxFQUFFO0FBREEsR0FIUDtBQVFMQyxFQUFBQSxNQVJLLG9CQVFLLENBQUUsQ0FSUDtBQVVMQyxFQUFBQSxNQVZLLGtCQVVFQyxDQVZGLEVBVUtDLENBVkwsRUFVUUMsS0FWUixFQVVlQyxRQVZmLEVBVXlCO0FBQzFCO0FBQ0EsU0FBS0MsVUFBTCxHQUFrQkosQ0FBbEI7QUFDQSxTQUFLSyxVQUFMLEdBQWtCSixDQUFsQjtBQUNBLFNBQUtFLFFBQUwsR0FBZ0JBLFFBQWhCO0FBQ0EsU0FBS0QsS0FBTCxHQUFhQSxLQUFiO0FBQ0gsR0FoQkk7QUFrQkxJLEVBQUFBLE1BbEJLLGtCQWtCRUMsSUFsQkYsRUFrQmdCO0FBQUEsUUFBZEEsSUFBYztBQUFkQSxNQUFBQSxJQUFjLEdBQVAsS0FBTztBQUFBOztBQUNqQixRQUFJQyxJQUFJLEdBQUcsS0FBS0EsSUFBaEI7QUFDQSxTQUFLQyxRQUFMLEdBQWdCO0FBQ1pELE1BQUFBLElBQUksRUFBRUEsSUFETTtBQUVaRSxNQUFBQSxTQUFTLEVBQUVGLElBQUksQ0FBQ0csUUFGSjtBQUdaQyxNQUFBQSxNQUFNLEVBQUVuQixFQUFFLENBQUNvQixFQUFILENBQU0sRUFBTixFQUFVLEVBQVYsQ0FISTtBQUlaWCxNQUFBQSxLQUFLLEVBQUUsQ0FKSztBQUtaQyxNQUFBQSxRQUFRLEVBQUUsR0FMRTtBQU1aVyxNQUFBQSxTQUFTLEVBQUVDLElBQUksQ0FBQ0MsR0FBTCxFQU5DO0FBT1pDLE1BQUFBLGlCQUFpQixFQUFFO0FBUFAsS0FBaEI7QUFTQSxTQUFLUixRQUFMLENBQWNRLGlCQUFkLEdBQWtDVixJQUFsQztBQUNBLFNBQUtWLE1BQUwsR0FBYyxRQUFkO0FBQ0EsU0FBS3FCLE9BQUwsR0FBZSxDQUFmO0FBQ0gsR0FoQ0k7QUFrQ0xDLEVBQUFBLEtBbENLLG1CQWtDRyxDQUVQLENBcENJO0FBc0NMQyxFQUFBQSxNQXRDSyxrQkFzQ0VDLEVBdENGLEVBc0NNO0FBQ1AsUUFBSSxLQUFLeEIsTUFBTCxJQUFlLFFBQW5CLEVBQTZCO0FBQ3pCLFVBQUlZLFFBQVEsR0FBRyxLQUFLQSxRQUFwQjtBQUNBLFdBQUtELElBQUwsQ0FBVUcsUUFBVixHQUFxQmxCLEVBQUUsQ0FBQzZCLElBQUgsQ0FBUUMsSUFBN0I7QUFDQSxXQUFLTCxPQUFMLElBQWdCRyxFQUFoQjtBQUNBLFVBQU1HLEVBQUUsR0FBR2YsUUFBUSxDQUFDRyxNQUFULENBQWdCWixDQUEzQjtBQUNBLFVBQU15QixFQUFFLEdBQUdoQixRQUFRLENBQUNHLE1BQVQsQ0FBZ0JYLENBQTNCO0FBQ0EsVUFBTXlCLENBQUMsR0FBR2pCLFFBQVEsQ0FBQ1AsS0FBbkI7QUFDQSxVQUFNQyxRQUFRLEdBQUdNLFFBQVEsQ0FBQ04sUUFBMUI7QUFDQSxVQUFNd0IsS0FBSyxHQUFHRCxDQUFDLEdBQUcsQ0FBSixHQUFRRSxJQUFJLENBQUNDLEVBQTNCO0FBQ0EsVUFBTUMsRUFBRSxHQUFHckIsUUFBUSxDQUFDUSxpQkFBcEI7O0FBQ0EsVUFBSSxLQUFLQyxPQUFMLEdBQWVmLFFBQW5CLEVBQTZCO0FBQ3pCLFlBQUk0QixNQUFNLEdBQUcsQ0FBYjtBQUNBLFlBQU1DLE9BQU8sR0FBRyxLQUFLZCxPQUFMLEdBQWVmLFFBQS9CO0FBQ0EsWUFBTThCLEtBQUssR0FBR04sS0FBSyxHQUFHSyxPQUF0QjtBQUNBLFlBQUlFLEVBQUUsR0FBR1YsRUFBRSxHQUFHSSxJQUFJLENBQUNPLEdBQUwsQ0FBU0YsS0FBVCxDQUFkO0FBQ0EsWUFBSUcsRUFBRSxHQUFHWCxFQUFFLEdBQUdHLElBQUksQ0FBQ1MsR0FBTCxDQUFTSixLQUFULENBQWQ7O0FBRUEsWUFBSUgsRUFBRSxLQUFLLElBQVgsRUFBaUI7QUFDYkMsVUFBQUEsTUFBTSxHQUFHQyxPQUFUO0FBQ0gsU0FGRCxNQUVPLElBQUlGLEVBQUUsS0FBSyxLQUFYLEVBQWtCO0FBQ3JCQyxVQUFBQSxNQUFNLEdBQUcsSUFBSUMsT0FBYjtBQUNILFNBRk0sTUFFQSxJQUFJRixFQUFFLEtBQUssT0FBWCxFQUFvQjtBQUN2QkMsVUFBQUEsTUFBTSxHQUFHLEtBQUtDLE9BQU8sR0FBRyxHQUFWLEdBQWdCQSxPQUFoQixHQUEwQixJQUFJQSxPQUFuQyxDQUFUO0FBQ0g7O0FBQ0RFLFFBQUFBLEVBQUUsSUFBSUgsTUFBTjtBQUNBSyxRQUFBQSxFQUFFLElBQUlMLE1BQU47QUFDQSxZQUFJTyxDQUFDLEdBQUdWLElBQUksQ0FBQ1csTUFBTCxLQUFnQixHQUFoQixHQUFzQjlCLFFBQVEsQ0FBQ0MsU0FBVCxDQUFtQjhCLEdBQW5CLENBQXVCL0MsRUFBRSxDQUFDb0IsRUFBSCxDQUFNcUIsRUFBTixFQUFVRSxFQUFWLENBQXZCLENBQXRCLEdBQThEM0IsUUFBUSxDQUFDQyxTQUFULENBQW1CK0IsR0FBbkIsQ0FBdUJoRCxFQUFFLENBQUNvQixFQUFILENBQU1xQixFQUFOLEVBQVVFLEVBQVYsQ0FBdkIsQ0FBdEU7QUFFQTNCLFFBQUFBLFFBQVEsQ0FBQ0QsSUFBVCxDQUFjRyxRQUFkLEdBQXlCMkIsQ0FBekI7QUFDSCxPQW5CRCxNQW1CTztBQUNILGFBQUt6QyxNQUFMLEdBQWMsTUFBZDtBQUNBLGFBQUtxQixPQUFMLEdBQWUsQ0FBZjtBQUNBVCxRQUFBQSxRQUFRLENBQUNELElBQVQsQ0FBY0csUUFBZCxHQUF5QkYsUUFBUSxDQUFDQyxTQUFsQztBQUNIO0FBQ0o7QUFFSjtBQTNFSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBfc3RhdGU6IFwiaWRsZVwiXHJcbiAgICB9LFxyXG4gXHJcblxyXG4gICAgb25Mb2FkICgpIHt9LFxyXG4gIFxyXG4gICAgc2V0QWxsKHgsIHksIHRpbWVzLCBkdXJhdGlvbikge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0tLS0tLXNldEFsbC0tLS0tLS0tLS0tLS1cIix4LCB5LCB0aW1lcywgZHVyYXRpb24pXHJcbiAgICAgICAgdGhpcy5hbXBsaXR1ZGVYID0geDtcclxuICAgICAgICB0aGlzLmFtcGxpdHVkZVkgPSB5O1xyXG4gICAgICAgIHRoaXMuZHVyYXRpb24gPSBkdXJhdGlvbjtcclxuICAgICAgICB0aGlzLnRpbWVzID0gdGltZXM7XHJcbiAgICB9LFxyXG5cclxuICAgIHNoYWtlcih0eXBlID0gXCJvdXRcIikge1xyXG4gICAgICAgIGxldCBub2RlID0gdGhpcy5ub2RlO1xyXG4gICAgICAgIHRoaXMuc2hha2VPYmogPSB7XHJcbiAgICAgICAgICAgIG5vZGU6IG5vZGUsXHJcbiAgICAgICAgICAgIG9yaWdpblBvczogbm9kZS5wb3NpdGlvbixcclxuICAgICAgICAgICAgb2Zmc2V0OiBjYy52MigxNSwgMjApLFxyXG4gICAgICAgICAgICB0aW1lczogNCxcclxuICAgICAgICAgICAgZHVyYXRpb246IDAuNCxcclxuICAgICAgICAgICAgc3RhcnRUaW1lOiBEYXRlLm5vdygpLFxyXG4gICAgICAgICAgICBhbXBsaXR1ZGVNb2RpZmllcjogXCJvdXRcIlxyXG4gICAgICAgIH1cclxuICAgICAgICB0aGlzLnNoYWtlT2JqLmFtcGxpdHVkZU1vZGlmaWVyID0gdHlwZTtcclxuICAgICAgICB0aGlzLl9zdGF0ZSA9IFwic2hha2VyXCI7XHJcbiAgICAgICAgdGhpcy5jdXJUaW1lID0gMDtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQoKSB7IFxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUoZHQpIHtcclxuICAgICAgICBpZiAodGhpcy5fc3RhdGUgPT0gXCJzaGFrZXJcIikge1xyXG4gICAgICAgICAgICBsZXQgc2hha2VPYmogPSB0aGlzLnNoYWtlT2JqO1xyXG4gICAgICAgICAgICB0aGlzLm5vZGUucG9zaXRpb24gPSBjYy5WZWMyLlpFUk87XHJcbiAgICAgICAgICAgIHRoaXMuY3VyVGltZSArPSBkdDtcclxuICAgICAgICAgICAgY29uc3QgYVggPSBzaGFrZU9iai5vZmZzZXQueDtcclxuICAgICAgICAgICAgY29uc3QgYVkgPSBzaGFrZU9iai5vZmZzZXQueTtcclxuICAgICAgICAgICAgY29uc3QgbiA9IHNoYWtlT2JqLnRpbWVzO1xyXG4gICAgICAgICAgICBjb25zdCBkdXJhdGlvbiA9IHNoYWtlT2JqLmR1cmF0aW9uO1xyXG4gICAgICAgICAgICBjb25zdCByYW5nZSA9IG4gKiAyICogTWF0aC5QSTtcclxuICAgICAgICAgICAgY29uc3QgYW0gPSBzaGFrZU9iai5hbXBsaXR1ZGVNb2RpZmllcjtcclxuICAgICAgICAgICAgaWYgKHRoaXMuY3VyVGltZSA8IGR1cmF0aW9uKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgZmFjdG9yID0gMSAgO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcGVyY2VudCA9IHRoaXMuY3VyVGltZSAvIGR1cmF0aW9uOyAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBjb25zdCBhbmdsZSA9IHJhbmdlICogcGVyY2VudDtcclxuICAgICAgICAgICAgICAgIGxldCB4byA9IGFYICogTWF0aC5jb3MoYW5nbGUpO1xyXG4gICAgICAgICAgICAgICAgbGV0IHlvID0gYVkgKiBNYXRoLnNpbihhbmdsZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgaWYgKGFtID09PSBcImluXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICBmYWN0b3IgPSBwZXJjZW50O1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChhbSA9PT0gXCJvdXRcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGZhY3RvciA9IDEgLSBwZXJjZW50O1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChhbSA9PT0gXCJpbk91dFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZmFjdG9yID0gMiAqIChwZXJjZW50IDwgMC41ID8gcGVyY2VudCA6IDEgLSBwZXJjZW50KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHhvICo9IGZhY3RvcjtcclxuICAgICAgICAgICAgICAgIHlvICo9IGZhY3RvcjtcclxuICAgICAgICAgICAgICAgIGxldCBwID0gTWF0aC5yYW5kb20oKSA+IDAuNSA/IHNoYWtlT2JqLm9yaWdpblBvcy5hZGQoY2MudjIoeG8sIHlvKSkgOiBzaGFrZU9iai5vcmlnaW5Qb3Muc3ViKGNjLnYyKHhvLCB5bykpOyBcclxuXHJcbiAgICAgICAgICAgICAgICBzaGFrZU9iai5ub2RlLnBvc2l0aW9uID0gcDtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuX3N0YXRlID0gXCJpZGxlXCI7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmN1clRpbWUgPSAwO1xyXG4gICAgICAgICAgICAgICAgc2hha2VPYmoubm9kZS5wb3NpdGlvbiA9IHNoYWtlT2JqLm9yaWdpblBvcztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9LFxyXG59KTtcclxuXHJcbiJdfQ==