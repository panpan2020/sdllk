
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/EventManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ffd8bMMRqVKo7UxWfZFZiF8', 'EventManager');
// scripts/EventManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.EventMgr = exports.EventManager = void 0;
var EventManager = /** @class */ (function () {
    function EventManager() {
        this._eventListeners = {};
    }
    EventManager.getInstance = function () {
        if (!this.instance) {
            this.instance = new EventManager();
        }
        return this.instance;
    };
    EventManager.destroy = function () {
        if (this.instance) {
            this.instance = null;
        }
    };
    EventManager.prototype.getEventListenersIndex = function (eventName, callBack, target) {
        var index = -1;
        for (var i = 0; i < this._eventListeners[eventName].length; i++) {
            var iterator = this._eventListeners[eventName][i];
            if (iterator.callBack == callBack && (!target || iterator.target == target)) {
                index = i;
                break;
            }
        }
        return index;
    };
    EventManager.prototype.addEventListener = function (eventName, callBack, target) {
        if (!eventName) {
            console.warn("eventName is empty" + eventName);
            return;
        }
        if (null == callBack) {
            console.log('addEventListener callBack is nil');
            return false;
        }
        var callTarget = { callBack: callBack, target: target };
        if (null == this._eventListeners[eventName]) {
            this._eventListeners[eventName] = [callTarget];
        }
        else {
            var index = this.getEventListenersIndex(eventName, callBack, target);
            if (-1 == index) {
                this._eventListeners[eventName].push(callTarget);
            }
        }
        return true;
    };
    EventManager.prototype.setEventListener = function (eventName, callBack, target) {
        if (!eventName) {
            console.warn("eventName is empty" + eventName);
            return;
        }
        if (null == callBack) {
            console.log('setEventListener callBack is nil');
            return false;
        }
        var callTarget = { callBack: callBack, target: target };
        this._eventListeners[eventName] = [callTarget];
        return true;
    };
    EventManager.prototype.removeEventListener = function (eventName, callBack, target) {
        if (null != this._eventListeners[eventName]) {
            var index = this.getEventListenersIndex(eventName, callBack, target);
            if (-1 != index) {
                this._eventListeners[eventName].splice(index, 1);
            }
        }
    };
    EventManager.prototype.raiseEvent = function (eventName, eventData) {
        // console.log(`==================== raiseEvent ${eventName} begin | ${JSON.stringify(eventData)}`);
        if (null != this._eventListeners[eventName]) {
            // 将所有回调提取出来，再调用，避免调用回调的时候操作了事件的删除
            var callbackList = [];
            for (var _i = 0, _a = this._eventListeners[eventName]; _i < _a.length; _i++) {
                var iterator = _a[_i];
                callbackList.push({ callBack: iterator.callBack, target: iterator.target });
            }
            for (var _b = 0, callbackList_1 = callbackList; _b < callbackList_1.length; _b++) {
                var iterator = callbackList_1[_b];
                iterator.callBack.call(iterator.target, eventName, eventData);
            }
        }
    };
    EventManager.instance = null;
    return EventManager;
}());
exports.EventManager = EventManager;
exports.EventMgr = EventManager.getInstance();

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcRXZlbnRNYW5hZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBYUE7SUFlSTtRQUdRLG9CQUFlLEdBQXdDLEVBQUUsQ0FBQztJQUZsRSxDQUFDO0lBZGEsd0JBQVcsR0FBekI7UUFDSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNoQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7U0FDdEM7UUFDRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7SUFDekIsQ0FBQztJQUVhLG9CQUFPLEdBQXJCO1FBQ0ksSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7U0FDeEI7SUFDTCxDQUFDO0lBT08sNkNBQXNCLEdBQTlCLFVBQStCLFNBQWlCLEVBQUUsUUFBOEIsRUFBRSxNQUFZO1FBQzFGLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2YsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQzdELElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbEQsSUFBSSxRQUFRLENBQUMsUUFBUSxJQUFJLFFBQVEsSUFBSSxDQUFDLENBQUMsTUFBTSxJQUFJLFFBQVEsQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLEVBQUU7Z0JBQ3pFLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ1YsTUFBTTthQUNUO1NBQ0o7UUFDRCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0lBRUQsdUNBQWdCLEdBQWhCLFVBQWlCLFNBQWlCLEVBQUUsUUFBOEIsRUFBRSxNQUFZO1FBQzVFLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDWixPQUFPLENBQUMsSUFBSSxDQUFDLG9CQUFvQixHQUFHLFNBQVMsQ0FBQyxDQUFDO1lBQy9DLE9BQU87U0FDVjtRQUVELElBQUksSUFBSSxJQUFJLFFBQVEsRUFBRTtZQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7WUFDaEQsT0FBTyxLQUFLLENBQUM7U0FDaEI7UUFDRCxJQUFJLFVBQVUsR0FBbUIsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQztRQUN4RSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxFQUFFO1lBQ3pDLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUVsRDthQUFNO1lBQ0gsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDckUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEVBQUU7Z0JBQ2IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDcEQ7U0FDSjtRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCx1Q0FBZ0IsR0FBaEIsVUFBaUIsU0FBaUIsRUFBRSxRQUE4QixFQUFFLE1BQVk7UUFDNUUsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNaLE9BQU8sQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsU0FBUyxDQUFDLENBQUM7WUFDL0MsT0FBTztTQUNWO1FBRUQsSUFBSSxJQUFJLElBQUksUUFBUSxFQUFFO1lBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztZQUNoRCxPQUFPLEtBQUssQ0FBQztTQUNoQjtRQUNELElBQUksVUFBVSxHQUFtQixFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDO1FBQ3hFLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMvQyxPQUFPLElBQUksQ0FBQztJQUNoQixDQUFDO0lBRUQsMENBQW1CLEdBQW5CLFVBQW9CLFNBQWlCLEVBQUUsUUFBOEIsRUFBRSxNQUFZO1FBQy9FLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLEVBQUU7WUFDekMsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDckUsSUFBSSxDQUFDLENBQUMsSUFBSSxLQUFLLEVBQUU7Z0JBQ2IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ3BEO1NBQ0o7SUFDTCxDQUFDO0lBRUQsaUNBQVUsR0FBVixVQUFXLFNBQWlCLEVBQUUsU0FBZTtRQUN6QyxvR0FBb0c7UUFDcEcsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUN6QyxrQ0FBa0M7WUFDbEMsSUFBSSxZQUFZLEdBQXFCLEVBQUUsQ0FBQztZQUN4QyxLQUF1QixVQUErQixFQUEvQixLQUFBLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLEVBQS9CLGNBQStCLEVBQS9CLElBQStCLEVBQUU7Z0JBQW5ELElBQU0sUUFBUSxTQUFBO2dCQUNmLFlBQVksQ0FBQyxJQUFJLENBQUMsRUFBRSxRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7YUFDL0U7WUFDRCxLQUF1QixVQUFZLEVBQVosNkJBQVksRUFBWiwwQkFBWSxFQUFaLElBQVksRUFBRTtnQkFBaEMsSUFBTSxRQUFRLHFCQUFBO2dCQUNmLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2FBQ2pFO1NBQ0o7SUFFTCxDQUFDO0lBNUZjLHFCQUFRLEdBQWlCLElBQUksQ0FBQztJQTZGakQsbUJBQUM7Q0E5RkQsQUE4RkMsSUFBQTtBQTlGWSxvQ0FBWTtBQWdHZCxRQUFBLFFBQVEsR0FBRyxZQUFZLENBQUMsV0FBVyxFQUFFLENBQUMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcblxuLypcbiogICDkuovku7bnrqHnkIblmajvvIzkuovku7bnmoTnm5HlkKzjgIHop6blj5HjgIHnp7vpmaRcbiogICBcbiovXG5leHBvcnQgdHlwZSBFdmVudE1hbmFnZXJDYWxsRnVuYyA9IChldmVudE5hbWU6IHN0cmluZywgZXZlbnREYXRhOiBhbnkpID0+IHZvaWQ7XG5cbmludGVyZmFjZSBDYWxsQmFja1RhcmdldCB7XG4gICAgY2FsbEJhY2s6IEV2ZW50TWFuYWdlckNhbGxGdW5jLFxuICAgIHRhcmdldDogYW55LFxufVxuXG5leHBvcnQgY2xhc3MgRXZlbnRNYW5hZ2VyIHtcbiAgICBwcml2YXRlIHN0YXRpYyBpbnN0YW5jZTogRXZlbnRNYW5hZ2VyID0gbnVsbDtcbiAgICBwdWJsaWMgc3RhdGljIGdldEluc3RhbmNlKCk6IEV2ZW50TWFuYWdlciB7XG4gICAgICAgIGlmICghdGhpcy5pbnN0YW5jZSkge1xuICAgICAgICAgICAgdGhpcy5pbnN0YW5jZSA9IG5ldyBFdmVudE1hbmFnZXIoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy5pbnN0YW5jZTtcbiAgICB9XG5cbiAgICBwdWJsaWMgc3RhdGljIGRlc3Ryb3koKTogdm9pZCB7XG4gICAgICAgIGlmICh0aGlzLmluc3RhbmNlKSB7XG4gICAgICAgICAgICB0aGlzLmluc3RhbmNlID0gbnVsbDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHByaXZhdGUgY29uc3RydWN0b3IoKSB7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBfZXZlbnRMaXN0ZW5lcnM6IHsgW2tleTogc3RyaW5nXTogQ2FsbEJhY2tUYXJnZXRbXSB9ID0ge307XG5cbiAgICBwcml2YXRlIGdldEV2ZW50TGlzdGVuZXJzSW5kZXgoZXZlbnROYW1lOiBzdHJpbmcsIGNhbGxCYWNrOiBFdmVudE1hbmFnZXJDYWxsRnVuYywgdGFyZ2V0PzogYW55KTogbnVtYmVyIHtcbiAgICAgICAgbGV0IGluZGV4ID0gLTE7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5fZXZlbnRMaXN0ZW5lcnNbZXZlbnROYW1lXS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbGV0IGl0ZXJhdG9yID0gdGhpcy5fZXZlbnRMaXN0ZW5lcnNbZXZlbnROYW1lXVtpXTtcbiAgICAgICAgICAgIGlmIChpdGVyYXRvci5jYWxsQmFjayA9PSBjYWxsQmFjayAmJiAoIXRhcmdldCB8fCBpdGVyYXRvci50YXJnZXQgPT0gdGFyZ2V0KSkge1xuICAgICAgICAgICAgICAgIGluZGV4ID0gaTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaW5kZXg7XG4gICAgfVxuXG4gICAgYWRkRXZlbnRMaXN0ZW5lcihldmVudE5hbWU6IHN0cmluZywgY2FsbEJhY2s6IEV2ZW50TWFuYWdlckNhbGxGdW5jLCB0YXJnZXQ/OiBhbnkpOiBib29sZWFuIHtcbiAgICAgICAgaWYgKCFldmVudE5hbWUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihcImV2ZW50TmFtZSBpcyBlbXB0eVwiICsgZXZlbnROYW1lKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChudWxsID09IGNhbGxCYWNrKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnYWRkRXZlbnRMaXN0ZW5lciBjYWxsQmFjayBpcyBuaWwnKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBsZXQgY2FsbFRhcmdldDogQ2FsbEJhY2tUYXJnZXQgPSB7IGNhbGxCYWNrOiBjYWxsQmFjaywgdGFyZ2V0OiB0YXJnZXQgfTtcbiAgICAgICAgaWYgKG51bGwgPT0gdGhpcy5fZXZlbnRMaXN0ZW5lcnNbZXZlbnROYW1lXSkge1xuICAgICAgICAgICAgdGhpcy5fZXZlbnRMaXN0ZW5lcnNbZXZlbnROYW1lXSA9IFtjYWxsVGFyZ2V0XTtcblxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbGV0IGluZGV4ID0gdGhpcy5nZXRFdmVudExpc3RlbmVyc0luZGV4KGV2ZW50TmFtZSwgY2FsbEJhY2ssIHRhcmdldCk7XG4gICAgICAgICAgICBpZiAoLTEgPT0gaW5kZXgpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9ldmVudExpc3RlbmVyc1tldmVudE5hbWVdLnB1c2goY2FsbFRhcmdldCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICBzZXRFdmVudExpc3RlbmVyKGV2ZW50TmFtZTogc3RyaW5nLCBjYWxsQmFjazogRXZlbnRNYW5hZ2VyQ2FsbEZ1bmMsIHRhcmdldD86IGFueSk6IGJvb2xlYW4ge1xuICAgICAgICBpZiAoIWV2ZW50TmFtZSkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKFwiZXZlbnROYW1lIGlzIGVtcHR5XCIgKyBldmVudE5hbWUpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG51bGwgPT0gY2FsbEJhY2spIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdzZXRFdmVudExpc3RlbmVyIGNhbGxCYWNrIGlzIG5pbCcpO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGxldCBjYWxsVGFyZ2V0OiBDYWxsQmFja1RhcmdldCA9IHsgY2FsbEJhY2s6IGNhbGxCYWNrLCB0YXJnZXQ6IHRhcmdldCB9O1xuICAgICAgICB0aGlzLl9ldmVudExpc3RlbmVyc1tldmVudE5hbWVdID0gW2NhbGxUYXJnZXRdO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG5cbiAgICByZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50TmFtZTogc3RyaW5nLCBjYWxsQmFjazogRXZlbnRNYW5hZ2VyQ2FsbEZ1bmMsIHRhcmdldD86IGFueSkge1xuICAgICAgICBpZiAobnVsbCAhPSB0aGlzLl9ldmVudExpc3RlbmVyc1tldmVudE5hbWVdKSB7XG4gICAgICAgICAgICBsZXQgaW5kZXggPSB0aGlzLmdldEV2ZW50TGlzdGVuZXJzSW5kZXgoZXZlbnROYW1lLCBjYWxsQmFjaywgdGFyZ2V0KTtcbiAgICAgICAgICAgIGlmICgtMSAhPSBpbmRleCkge1xuICAgICAgICAgICAgICAgIHRoaXMuX2V2ZW50TGlzdGVuZXJzW2V2ZW50TmFtZV0uc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJhaXNlRXZlbnQoZXZlbnROYW1lOiBzdHJpbmcsIGV2ZW50RGF0YT86IGFueSkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhgPT09PT09PT09PT09PT09PT09PT0gcmFpc2VFdmVudCAke2V2ZW50TmFtZX0gYmVnaW4gfCAke0pTT04uc3RyaW5naWZ5KGV2ZW50RGF0YSl9YCk7XG4gICAgICAgIGlmIChudWxsICE9IHRoaXMuX2V2ZW50TGlzdGVuZXJzW2V2ZW50TmFtZV0pIHtcbiAgICAgICAgICAgIC8vIOWwhuaJgOacieWbnuiwg+aPkOWPluWHuuadpe+8jOWGjeiwg+eUqO+8jOmBv+WFjeiwg+eUqOWbnuiwg+eahOaXtuWAmeaTjeS9nOS6huS6i+S7tueahOWIoOmZpFxuICAgICAgICAgICAgbGV0IGNhbGxiYWNrTGlzdDogQ2FsbEJhY2tUYXJnZXRbXSA9IFtdO1xuICAgICAgICAgICAgZm9yIChjb25zdCBpdGVyYXRvciBvZiB0aGlzLl9ldmVudExpc3RlbmVyc1tldmVudE5hbWVdKSB7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2tMaXN0LnB1c2goeyBjYWxsQmFjazogaXRlcmF0b3IuY2FsbEJhY2ssIHRhcmdldDogaXRlcmF0b3IudGFyZ2V0IH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChjb25zdCBpdGVyYXRvciBvZiBjYWxsYmFja0xpc3QpIHtcbiAgICAgICAgICAgICAgICBpdGVyYXRvci5jYWxsQmFjay5jYWxsKGl0ZXJhdG9yLnRhcmdldCwgZXZlbnROYW1lLCBldmVudERhdGEpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICBcbiAgICB9XG59XG5cbmV4cG9ydCBsZXQgRXZlbnRNZ3IgPSBFdmVudE1hbmFnZXIuZ2V0SW5zdGFuY2UoKTsiXX0=