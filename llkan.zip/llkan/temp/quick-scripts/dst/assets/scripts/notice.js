
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/notice.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a8bb1WeJV9JI6KUmZK2jYpf', 'notice');
// scripts/notice.js

"use strict";

function _createForOfIteratorHelperLoose(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (it) return (it = it.call(o)).next.bind(it); if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; return function () { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

cc.Class({
  "extends": cc.Component,
  properties: {
    bg: cc.Node,
    richText: cc.RichText,
    _str_list: [],
    _running: false
  },
  onLoad: function onLoad() {
    console.log("========1=======");
    this._str_list = [];
    this._running = false;
  },
  start: function start() {
    this._str_list = []; // console.log("=======2======")

    this.unshowRichText(1);
  },
  addStrToList: function addStrToList(str) {
    this._str_list.push(str);

    if (!this._running) {
      this.showRichText(this._str_list.shift());
    }
  },
  showRichText: function showRichText(str) {
    var _this = this;

    // console.log("=======showRichText===========",this.node.position)
    this._running = true;

    if (this.bg != null && this.bg.getComponent(cc.Animation) != null) {
      this.bg.getComponent(cc.Animation).play('notice');
    }

    this._enableNode(true);

    this.richText.string = str;
    var maskWidth = cc.find('Mask', this.node).width; // console.log("=======4======",str,maskWidth)

    this.richText.node.x = maskWidth / 2 * 1.6;
    console.log("=======5======", this.richText.node.x, this.richText.node.width, -maskWidth - this.richText.node.width);
    this.richText.node.runAction(cc.sequence(cc.moveBy(10, cc.v2(-maskWidth - this.richText.node.width - 100, 0)), cc.callFunc(function () {
      console.log("=======43=====", str);

      if (_this._str_list.length > 0) {
        _this.showRichText(_this._str_list.shift());
      } else {
        _this.unshowRichText(2);

        _this._running = false;
      }
    })));
  },
  unshowRichText: function unshowRichText(from) {
    // console.log("---------stop----------", from)
    if (this.bg != null && this.bg.getComponent(cc.Animation) != null) {
      this.bg.getComponent(cc.Animation).stop('notice');
    }

    this._enableNode(false);
  },
  _enableNode: function _enableNode(flag) {
    for (var _iterator = _createForOfIteratorHelperLoose(this.node.children), _step; !(_step = _iterator()).done;) {
      var item = _step.value;
      item.active = flag;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcbm90aWNlLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiYmciLCJOb2RlIiwicmljaFRleHQiLCJSaWNoVGV4dCIsIl9zdHJfbGlzdCIsIl9ydW5uaW5nIiwib25Mb2FkIiwiY29uc29sZSIsImxvZyIsInN0YXJ0IiwidW5zaG93UmljaFRleHQiLCJhZGRTdHJUb0xpc3QiLCJzdHIiLCJwdXNoIiwic2hvd1JpY2hUZXh0Iiwic2hpZnQiLCJnZXRDb21wb25lbnQiLCJBbmltYXRpb24iLCJwbGF5IiwiX2VuYWJsZU5vZGUiLCJzdHJpbmciLCJtYXNrV2lkdGgiLCJmaW5kIiwibm9kZSIsIndpZHRoIiwieCIsInJ1bkFjdGlvbiIsInNlcXVlbmNlIiwibW92ZUJ5IiwidjIiLCJjYWxsRnVuYyIsImxlbmd0aCIsImZyb20iLCJzdG9wIiwiZmxhZyIsImNoaWxkcmVuIiwiaXRlbSIsImFjdGl2ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFFTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEVBQUUsRUFBRUosRUFBRSxDQUFDSyxJQURDO0FBRVJDLElBQUFBLFFBQVEsRUFBRU4sRUFBRSxDQUFDTyxRQUZMO0FBSVJDLElBQUFBLFNBQVMsRUFBRSxFQUpIO0FBS1JDLElBQUFBLFFBQVEsRUFBRTtBQUxGLEdBRlA7QUFVTEMsRUFBQUEsTUFWSyxvQkFVSTtBQUNMQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxrQkFBWjtBQUNBLFNBQUtKLFNBQUwsR0FBaUIsRUFBakI7QUFDQSxTQUFLQyxRQUFMLEdBQWdCLEtBQWhCO0FBRUgsR0FmSTtBQWlCTEksRUFBQUEsS0FqQkssbUJBaUJHO0FBQ0osU0FBS0wsU0FBTCxHQUFpQixFQUFqQixDQURJLENBRUo7O0FBQ0EsU0FBS00sY0FBTCxDQUFvQixDQUFwQjtBQUNILEdBckJJO0FBdUJMQyxFQUFBQSxZQXZCSyx3QkF1QlFDLEdBdkJSLEVBdUJhO0FBRWQsU0FBS1IsU0FBTCxDQUFlUyxJQUFmLENBQW9CRCxHQUFwQjs7QUFDQSxRQUFJLENBQUMsS0FBS1AsUUFBVixFQUFvQjtBQUNoQixXQUFLUyxZQUFMLENBQWtCLEtBQUtWLFNBQUwsQ0FBZVcsS0FBZixFQUFsQjtBQUNIO0FBQ0osR0E3Qkk7QUErQkxELEVBQUFBLFlBL0JLLHdCQStCUUYsR0EvQlIsRUErQmE7QUFBQTs7QUFDZDtBQUNBLFNBQUtQLFFBQUwsR0FBZ0IsSUFBaEI7O0FBQ0EsUUFBRyxLQUFLTCxFQUFMLElBQVMsSUFBVCxJQUFlLEtBQUtBLEVBQUwsQ0FBUWdCLFlBQVIsQ0FBcUJwQixFQUFFLENBQUNxQixTQUF4QixLQUFvQyxJQUF0RCxFQUEyRDtBQUN2RCxXQUFLakIsRUFBTCxDQUFRZ0IsWUFBUixDQUFxQnBCLEVBQUUsQ0FBQ3FCLFNBQXhCLEVBQW1DQyxJQUFuQyxDQUF3QyxRQUF4QztBQUNIOztBQUVELFNBQUtDLFdBQUwsQ0FBaUIsSUFBakI7O0FBRUEsU0FBS2pCLFFBQUwsQ0FBY2tCLE1BQWQsR0FBdUJSLEdBQXZCO0FBQ0EsUUFBSVMsU0FBUyxHQUFHekIsRUFBRSxDQUFDMEIsSUFBSCxDQUFRLE1BQVIsRUFBZ0IsS0FBS0MsSUFBckIsRUFBMkJDLEtBQTNDLENBVmMsQ0FZZDs7QUFFQSxTQUFLdEIsUUFBTCxDQUFjcUIsSUFBZCxDQUFtQkUsQ0FBbkIsR0FBdUJKLFNBQVMsR0FBRyxDQUFaLEdBQWdCLEdBQXZDO0FBRUFkLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaLEVBQThCLEtBQUtOLFFBQUwsQ0FBY3FCLElBQWQsQ0FBbUJFLENBQWpELEVBQW9ELEtBQUt2QixRQUFMLENBQWNxQixJQUFkLENBQW1CQyxLQUF2RSxFQUE4RSxDQUFDSCxTQUFELEdBQWEsS0FBS25CLFFBQUwsQ0FBY3FCLElBQWQsQ0FBbUJDLEtBQTlHO0FBRUEsU0FBS3RCLFFBQUwsQ0FBY3FCLElBQWQsQ0FBbUJHLFNBQW5CLENBQTZCOUIsRUFBRSxDQUFDK0IsUUFBSCxDQUN6Qi9CLEVBQUUsQ0FBQ2dDLE1BQUgsQ0FBVSxFQUFWLEVBQWNoQyxFQUFFLENBQUNpQyxFQUFILENBQU0sQ0FBQ1IsU0FBRCxHQUFhLEtBQUtuQixRQUFMLENBQWNxQixJQUFkLENBQW1CQyxLQUFoQyxHQUF3QyxHQUE5QyxFQUFtRCxDQUFuRCxDQUFkLENBRHlCLEVBRXpCNUIsRUFBRSxDQUFDa0MsUUFBSCxDQUFZLFlBQU07QUFDZHZCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFaLEVBQThCSSxHQUE5Qjs7QUFDQSxVQUFJLEtBQUksQ0FBQ1IsU0FBTCxDQUFlMkIsTUFBZixHQUF3QixDQUE1QixFQUErQjtBQUMzQixRQUFBLEtBQUksQ0FBQ2pCLFlBQUwsQ0FBa0IsS0FBSSxDQUFDVixTQUFMLENBQWVXLEtBQWYsRUFBbEI7QUFDSCxPQUZELE1BR0s7QUFDRCxRQUFBLEtBQUksQ0FBQ0wsY0FBTCxDQUFvQixDQUFwQjs7QUFDQSxRQUFBLEtBQUksQ0FBQ0wsUUFBTCxHQUFnQixLQUFoQjtBQUNIO0FBQ0osS0FURCxDQUZ5QixDQUE3QjtBQWNILEdBL0RJO0FBaUVMSyxFQUFBQSxjQWpFSywwQkFpRVVzQixJQWpFVixFQWlFZ0I7QUFDakI7QUFDQSxRQUFJLEtBQUtoQyxFQUFMLElBQVcsSUFBWCxJQUFtQixLQUFLQSxFQUFMLENBQVFnQixZQUFSLENBQXFCcEIsRUFBRSxDQUFDcUIsU0FBeEIsS0FBcUMsSUFBNUQsRUFBa0U7QUFDOUQsV0FBS2pCLEVBQUwsQ0FBUWdCLFlBQVIsQ0FBcUJwQixFQUFFLENBQUNxQixTQUF4QixFQUFtQ2dCLElBQW5DLENBQXdDLFFBQXhDO0FBQ0g7O0FBQ0QsU0FBS2QsV0FBTCxDQUFpQixLQUFqQjtBQUNILEdBdkVJO0FBeUVMQSxFQUFBQSxXQXpFSyx1QkF5RU9lLElBekVQLEVBeUVhO0FBQ2QseURBQWlCLEtBQUtYLElBQUwsQ0FBVVksUUFBM0Isd0NBQXFDO0FBQUEsVUFBNUJDLElBQTRCO0FBQ2pDQSxNQUFBQSxJQUFJLENBQUNDLE1BQUwsR0FBY0gsSUFBZDtBQUNIO0FBQ0o7QUE3RUksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGJnOiBjYy5Ob2RlLFxyXG4gICAgICAgIHJpY2hUZXh0OiBjYy5SaWNoVGV4dCxcclxuXHJcbiAgICAgICAgX3N0cl9saXN0OiBbXSxcclxuICAgICAgICBfcnVubmluZzogZmFsc2UsXHJcbiAgICB9LFxyXG5cclxuICAgIG9uTG9hZCgpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIj09PT09PT09MT09PT09PT1cIilcclxuICAgICAgICB0aGlzLl9zdHJfbGlzdCA9IFtdO1xyXG4gICAgICAgIHRoaXMuX3J1bm5pbmcgPSBmYWxzZTtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIHN0YXJ0KCkge1xyXG4gICAgICAgIHRoaXMuX3N0cl9saXN0ID0gW107XHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCI9PT09PT09Mj09PT09PVwiKVxyXG4gICAgICAgIHRoaXMudW5zaG93UmljaFRleHQoMSk7XHJcbiAgICB9LFxyXG5cclxuICAgIGFkZFN0clRvTGlzdChzdHIpIHtcclxuXHJcbiAgICAgICAgdGhpcy5fc3RyX2xpc3QucHVzaChzdHIpO1xyXG4gICAgICAgIGlmICghdGhpcy5fcnVubmluZykge1xyXG4gICAgICAgICAgICB0aGlzLnNob3dSaWNoVGV4dCh0aGlzLl9zdHJfbGlzdC5zaGlmdCgpKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHNob3dSaWNoVGV4dChzdHIpIHtcclxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIj09PT09PT1zaG93UmljaFRleHQ9PT09PT09PT09PVwiLHRoaXMubm9kZS5wb3NpdGlvbilcclxuICAgICAgICB0aGlzLl9ydW5uaW5nID0gdHJ1ZTtcclxuICAgICAgICBpZih0aGlzLmJnIT1udWxsJiZ0aGlzLmJnLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pIT1udWxsKXtcclxuICAgICAgICAgICAgdGhpcy5iZy5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKS5wbGF5KCdub3RpY2UnKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMuX2VuYWJsZU5vZGUodHJ1ZSk7XHJcblxyXG4gICAgICAgIHRoaXMucmljaFRleHQuc3RyaW5nID0gc3RyO1xyXG4gICAgICAgIGxldCBtYXNrV2lkdGggPSBjYy5maW5kKCdNYXNrJywgdGhpcy5ub2RlKS53aWR0aDtcclxuXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCI9PT09PT09ND09PT09PVwiLHN0cixtYXNrV2lkdGgpXHJcblxyXG4gICAgICAgIHRoaXMucmljaFRleHQubm9kZS54ID0gbWFza1dpZHRoIC8gMiAqIDEuNjtcclxuXHJcbiAgICAgICAgY29uc29sZS5sb2coXCI9PT09PT09NT09PT09PVwiLCB0aGlzLnJpY2hUZXh0Lm5vZGUueCwgdGhpcy5yaWNoVGV4dC5ub2RlLndpZHRoLCAtbWFza1dpZHRoIC0gdGhpcy5yaWNoVGV4dC5ub2RlLndpZHRoKTtcclxuXHJcbiAgICAgICAgdGhpcy5yaWNoVGV4dC5ub2RlLnJ1bkFjdGlvbihjYy5zZXF1ZW5jZShcclxuICAgICAgICAgICAgY2MubW92ZUJ5KDEwLCBjYy52MigtbWFza1dpZHRoIC0gdGhpcy5yaWNoVGV4dC5ub2RlLndpZHRoIC0gMTAwLCAwKSksXHJcbiAgICAgICAgICAgIGNjLmNhbGxGdW5jKCgpID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiPT09PT09PTQzPT09PT1cIiwgc3RyKVxyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX3N0cl9saXN0Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNob3dSaWNoVGV4dCh0aGlzLl9zdHJfbGlzdC5zaGlmdCgpKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudW5zaG93UmljaFRleHQoMik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fcnVubmluZyA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICkpO1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgdW5zaG93UmljaFRleHQoZnJvbSkge1xyXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0tLS0tLS0tc3RvcC0tLS0tLS0tLS1cIiwgZnJvbSlcclxuICAgICAgICBpZiAodGhpcy5iZyAhPSBudWxsICYmIHRoaXMuYmcuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbikgIT1udWxsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuYmcuZ2V0Q29tcG9uZW50KGNjLkFuaW1hdGlvbikuc3RvcCgnbm90aWNlJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX2VuYWJsZU5vZGUoZmFsc2UpO1xyXG4gICAgfSxcclxuXHJcbiAgICBfZW5hYmxlTm9kZShmbGFnKSB7XHJcbiAgICAgICAgZm9yIChsZXQgaXRlbSBvZiB0aGlzLm5vZGUuY2hpbGRyZW4pIHtcclxuICAgICAgICAgICAgaXRlbS5hY3RpdmUgPSBmbGFnO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSk7XHJcbiJdfQ==