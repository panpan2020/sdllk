
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '12975PGgwpC9qlWdgdPHssT', 'game');
// scripts/game.js

"use strict";

/**
 * 连连看主脚本文件
 * 
 * by 慕容秋 muroqiu@qq.com
 * 2018-02-25
 * 
 * 主要的逻辑：
 * A、洗牌 shuffle：遍历图片数组，取1个随机位置的图片和当前位置交换；
 * B、用一个二维数组（各个方向均比图片数组大1）保存图片的状态值，搜索路径时映射到这个数组搜索；
 * C、搜索顺序：
 *    1、同一条直线：判断直线间有无图片；
 *    2、有一个拐角：先定位出两个拐角点，若拐角点没有图片，再转换成一条直线的情况继续处理；
 *    3、两个拐角：某个方向移动，若到达点没有图片，再转换成一个拐角的情况继续处理；若到达点有图片，此方向不再继续搜索；
 */
// import { rndName } from "./utools";
var utools = require("./utools"); // import {shake} from './shage';


cc.Class({
  "extends": cc.Component,
  properties: {
    itemPrefab: cc.Prefab,
    spriteWin: cc.SpriteFrame,
    spriteLose: cc.SpriteFrame,
    spriteframeList: [cc.SpriteFrame],
    imageList: [cc.node],
    timeout: cc.Label,
    BtnAudio: cc.AudioClip,
    ErrorAudio: cc.AudioClip,
    SuccessAudio: cc.AudioClip,
    ContinueAudio: cc.AudioClip,
    bgMusicAudio: cc.AudioClip,
    endNode: cc.Node,
    gameScore: cc.Label,
    cameraNode: cc.Node,
    btnPreNode: cc.Button,
    tipsNode: cc.Label,
    winAudio: cc.AudioClip,
    failedAudio: cc.AudioClip,
    gameOverLab: cc.Label,
    _graphics: cc.Graphics,
    noticeNode: cc.Node,
    randBtn: cc.Button,
    rankPrefab: cc.Prefab,
    rankListNode: cc.Node,
    nickName: cc.Label,
    // 行数
    rows: 4,
    // 列数
    columns: 4,
    // 总的图片对数 = lines*rows/2，当为0时，表示已经全部消除 
    pairs: 8,
    // 倒计时
    duration: 20,
    count: 1,
    spriteWidth: 80,
    spriteHeight: 80,
    paddingLeft: 200,
    paddingTop: 500,
    // 图片状态： 消除
    _TYPE_DELED: -2,
    // 图片状态： 初始化
    _TYPE_INIT: -1,
    // 二维数组，比图片数组大一圈，记录图片状态值
    _canvasGrids: null,
    _lastClickX: -1,
    _lastClickY: -1,
    //背景音效
    _isPauseMusic: true,
    //score
    _score: 0,
    _totalScore: 0,
    //动画
    _aniShow: null,
    //结束时UI倒计时
    _overTMS: 5,
    //排行榜
    _rankListData: []
  },
  // use this for initialization

  /**
   * 系统加载事件
   */
  onLoad: function onLoad() {
    this.nickName.string = utools.rndName(3);
    this.timer = 0;
    this._graphics = this.node.getChildByName("graphics").getComponent(cc.Graphics);
    this._graphics.lineWidth = 5;
    this.rankListNode.active = false;

    this._initAnimal();

    this._setTipsLabNode(false);

    this._canvasGrids = new Array(); //在声明二维

    for (var i = 0; i < this.rows + 2; i++) {
      this._canvasGrids[i] = new Array(i);

      for (var j = 0; j < this.columns + 2; j++) {
        this._canvasGrids[i][j] = -1;
      }
    }

    this.imageList = new Array();

    for (var i = 0; i < this.rows; i++) {
      this.imageList[i] = new Array(i);

      for (var j = 0; j < this.columns; j++) {
        this.imageList[i][j] = null;
      }
    } // console.log("-----------ddd---------")


    this.initData();
    this.initMap();

    this._resetGame();

    this._setPauseBgMusic();

    this.gameScore.string = this._score;
    this.gameOverLab.string = "-5";

    this._doneMusic(false);

    this._initNoticeNode();

    this._initScrollView();
  },
  _initNoticeNode: function _initNoticeNode() {
    var self = this;
    setTimeout(function () {
      if (!self.noticeNode) {
        var tt = self.noticeNode.getComponent("notice"); // <color=#00FF00>玩家</c> <color=#7FFF00>厉害</c>厉害<color=#FFFF00>oo</c>

        tt.addStrToList("<color=#0FFF50>欢迎体验闪电连连看,如你有任何问题请点击头像告诉我哟!</c>");

        self._initNoticeNode();
      }
    }, 3000);
  },
  _setTipsLabNode: function _setTipsLabNode(flag) {
    this.tipsNode.node.active = flag;
    this.timeout.node.color = new cc.color(255, 255, 255);
  },
  btnEvent2Pre: function btnEvent2Pre() {
    cc.audioEngine.pauseAllEffects();
    cc.director.loadScene("load");
  },
  _doneMusic: function _doneMusic(sign) {
    if (sign) this._isPauseMusic = !this._isPauseMusic; // console.log("------------------",this._isPauseMusic)

    if (this._isPauseMusic) {// cc.audioEngine.playEffect(this.bgMusicAudio, true,1);
    } else {
      cc.audioEngine.pauseAllEffects();
    }
  },
  _setPauseBgMusic: function _setPauseBgMusic() {
    var self = this;
    this.node.getChildByName("pause").on(cc.Node.EventType.TOUCH_END, function (event) {
      self._doneMusic(true);
    });
  },
  _resetGame: function _resetGame() {
    var self = this;
    this.node.getChildByName("refresh").on(cc.Node.EventType.TOUCH_END, function (event) {
      cc.audioEngine.playEffect(self.ContinueAudio, false);
      cc.director.loadScene('game');
    });
  },

  /**
   * 初始化数据
   */
  initData: function initData() {
    for (var row = 0; row < this.rows; row++) {
      for (var column = 0; column < this.columns; column++) {
        var newNode = cc.instantiate(this.itemPrefab); //复制预制资源

        var index = row * this.rows + column;
        var type = index % this.spriteframeList.length; // console.log("------>>---", newNode.getChildByName("Background").getComponent(cc.Sprite))

        newNode.getChildByName("Background").getComponent(cc.Sprite).spriteFrame = this.spriteframeList[type];
        newNode.isempty = false;
        newNode.type = type;
        newNode.index = index;
        newNode.score = Math.floor(Math.random() * 10);
        this.imageList[row][column] = newNode; // type >= 0，为实际的图片类型值

        this._canvasGrids[row + 1][column + 1] = type;
      }
    }

    this.shuffle();
  },

  /**
   * 洗牌
   */
  shuffle: function shuffle() {
    for (var i = this.rows * this.columns - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var x = i % this.rows;
      var y = Math.floor(i / this.rows);
      var x_tmp = j % this.rows;
      var y_tmp = Math.floor(j / this.rows);
      var temp = this.imageList[x][y];
      this.imageList[x][y] = this.imageList[x_tmp][y_tmp];
      this.imageList[x_tmp][y_tmp] = temp;
    }
  },

  /**
   * 初始化
   */
  initMap: function initMap() {
    for (var row = 0; row < this.rows; row++) {
      for (var column = 0; column < this.columns; column++) {
        var newNode = this.imageList[row][column];
        this.node.addChild(newNode);
        newNode.setPosition(cc.Vec2(this.spriteWidth * row - this.paddingLeft, this.spriteHeight * column - this.paddingTop));
        newNode.pointX = row;
        newNode.pointY = column;
        newNode.on(cc.Node.EventType.TOUCH_END, this._clickNode, this);
      }
    }
  },
  _clickNode: function _clickNode(d) {
    cc.audioEngine.playEffect(this.BtnAudio, false); // console.log("-----_clickNode---------",node.currentTarget.getComponent("pic") )

    var self = this; // let  node = d.currentTarget.getComponent("pic");

    var node = d.currentTarget;
    var lastNode = null;

    if (self._lastClickX != -1 && self._lastClickY != -1) {
      lastNode = self.imageList[self._lastClickX][self._lastClickY];
    } // console.log("-----3--------",lastNode)
    // 存储第一次点击对象ID


    if (self._lastClickX == -1 || self._lastClickX == -1) {
      //   console.log("-----2--------")
      self._lastClickX = node.pointX;
      self._lastClickY = node.pointY;
    } else if (self._lastClickX == node.pointX && self._lastClickY == node.pointY) {// console.log("---3--不做任何处理--------")
    } else if (lastNode.type == node.type) {
      //如果相同图片
      if (self.isLinked(self._lastClickX, self._lastClickY, node.pointX, node.pointY)) {
        //并且可连通
        self._setUIScore(lastNode.score, node.score); // node.scheduleOnce(  ()=>{


        setTimeout(function () {
          // 这里的 this 指向 component
          self.clearLinked(self._lastClickX, self._lastClickY, node.pointX, node.pointY);
          self._lastClickX = -1;
          self._lastClickY = -1;
        }, 100);
      } else {
        self._lastClickX = node.pointX;
        self._lastClickY = node.pointY; // cc.audioEngine.playEffect(self.ErrorAudio, false);
      }
    } else {
      self._lastClickX = node.pointX;
      self._lastClickY = node.pointY;
    }
  },

  /**
   * 消除已连接
   * newNode.getChildByName("Background").getComponent(cc.Sprite).spriteFrame
   */
  clearLinked: function clearLinked(x1, y1, x2, y2) {
    this.imageList[x1][y1].getChildByName("Background").getComponent(cc.Sprite).spriteFrame = null; // console.log("----2------->>>---",this.imageList[x2][y2] )

    this.imageList[x2][y2].getChildByName("Background").getComponent(cc.Sprite).spriteFrame = null;
    this._canvasGrids[x1 + 1][y1 + 1] = this._TYPE_DELED;
    this._canvasGrids[x2 + 1][y2 + 1] = this._TYPE_DELED;
    cc.audioEngine.playEffect(this.SuccessAudio, false);

    this._graphics.clear();

    this.pairs -= 1; // console.log("----3------->>>---")

    if (this.pairs == 0) this.gamePass();
  },

  /**
   * 根据矩阵XY获取绝对坐标
   */
  getAbsXY: function getAbsXY(x, y) {
    var absX = 0;
    var absY = 0;

    if (x < 0) {
      absX = this.node.x + this.imageList[0][0].x - this.imageList[0][0].width;
    } else if (x >= this.rows) {
      absX = this.node.x + this.imageList[this.rows - 1][0].x + this.imageList[0][0].width;
    } else {
      absX = this.node.x + this.imageList[x][0].x;
    }

    if (y < 0) {
      absY = this.node.y + this.imageList[0][0].y - this.imageList[0][0].height;
    } else if (y >= this.columns) {
      absY = this.node.y + this.imageList[0][this.columns - 1].y + this.imageList[0][0].height;
    } else {
      absY = this.node.y + this.imageList[0][y].y;
    }

    return [absX, absY];
  },

  /**
   * 是否连通
   */
  isLinked: function isLinked(x1, y1, x2, y2) {
    var tmpXY = [];
    var tmpAbsXY = [];

    if (this.matchBlockLine(x1, y1, x2, y2)) {
      // 直线
      tmpAbsXY = this.getAbsXY(x1, y1);

      this._graphics.moveTo(tmpAbsXY[0], tmpAbsXY[1]);

      tmpAbsXY = this.getAbsXY(x2, y2);

      this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

      this._graphics.stroke();

      return true;
    } else {
      tmpXY = this.matchBlockCorner(x1, y1, x2, y2, null);

      if (tmpXY) {
        // 一个转角
        tmpAbsXY = this.getAbsXY(x1, y1);

        this._graphics.moveTo(tmpAbsXY[0], tmpAbsXY[1]);

        tmpAbsXY = this.getAbsXY(tmpXY[0], tmpXY[1]);

        this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

        tmpAbsXY = this.getAbsXY(x2, y2);

        this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

        this._graphics.stroke();

        return true;
      } else {
        tmpXY = this.matchBlockUnfold(x1, y1, x2, y2);

        if (tmpXY) {
          // 两个转角
          tmpAbsXY = this.getAbsXY(x1, y1);

          this._graphics.moveTo(tmpAbsXY[0], tmpAbsXY[1]);

          tmpAbsXY = this.getAbsXY(tmpXY[0], tmpXY[1]);

          this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

          tmpAbsXY = this.getAbsXY(tmpXY[2], tmpXY[3]);

          this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

          tmpAbsXY = this.getAbsXY(x2, y2);

          this._graphics.lineTo(tmpAbsXY[0], tmpAbsXY[1]);

          this._graphics.stroke();

          return true;
        }
      }
    }

    return false;
  },

  /**
   * 直连
   */
  matchBlockLine: function matchBlockLine(x1, y1, x2, y2) {
    // cc.warn('matchBlock  ' + x1 + ', ' + y1 + '  : ' + x2 + ', ' + y2);
    if (x1 != x2 && y1 != y2) {
      return false;
    }

    if (x1 == x2) {
      // 同一列
      if (x1 < 0 || x1 >= this.rows) {
        return true;
      }

      var Ymin = Math.min(y1, y2) + 1;
      var Ymax = Math.max(y1, y2);

      for (Ymin; Ymin < Ymax; Ymin++) {
        if (this._canvasGrids[x1 + 1][Ymin + 1] > this._TYPE_INIT) {
          return false;
        }
      }
    } else if (y1 == y2) {
      // 同一行
      if (y1 < 0 || y1 >= this.columns) {
        return true;
      }

      var Xmin = Math.min(x1, x2) + 1;
      var Xmax = Math.max(x1, x2);

      for (Xmin; Xmin < Xmax; Xmin++) {
        if (this._canvasGrids[Xmin + 1][y1 + 1] > this._TYPE_INIT) {
          return false;
        }
      }
    }

    return true;
  },

  /**
   * 转角逻辑
   */
  matchBlockCorner_point: function matchBlockCorner_point(x1, y1, x2, y2, x3, y3) {
    var stMatch = this.matchBlockLine(x1, y1, x3, y3);

    if (stMatch) {
      var tdMatch = this.matchBlockLine(x3, y3, x2, y2);

      if (tdMatch) {
        return [x3, y3];
      }
    }

    return null;
  },

  /**
   * 一个转角
   * 搜索到路径时，返回转角坐标 x3, y3
   */
  matchBlockCorner: function matchBlockCorner(x1, y1, x2, y2, isAxis_X) {
    // cc.warn('matchBlockCorner  ' + x1 + ', ' + y1 + '  : ' + x2 + ', ' + y2);
    var result; // 直连的返回

    if (x1 == x2 || y1 == y2) {
      return null;
    } // 转角点1 (x1, y2)，Y方向


    if (this._canvasGrids[x1 + 1][y2 + 1] <= this._TYPE_INIT && isAxis_X != false) {
      result = this.matchBlockCorner_point(x1, y1, x2, y2, x1, y2);

      if (result) {
        return result;
      }
    } // 转角点2 (x2, y1)，X方向


    if (this._canvasGrids[x2 + 1][y1 + 1] <= this._TYPE_INIT && isAxis_X != true) {
      result = this.matchBlockCorner_point(x1, y1, x2, y2, x2, y1);

      if (result) {
        return result;
      }
    }

    return null;
  },

  /**
   * 某个方向上的搜索逻辑
   */
  matchBlockUnfold_axis: function matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, isAxis_X) {
    var tmpXY = [];

    if (this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT) {
      tmpXY = this.matchBlockCorner(x3, y3, x2, y2, isAxis_X);

      if (tmpXY) {
        return [x3, y3].concat(tmpXY);
        ;
      }
    }

    return null;
  },

  /**
   * 由中心往外展开搜索路径，某个方向当碰到有图片时，这个方向就不再继续搜索
   * 搜索到路径时，返回两个转角点坐标 x3, y3, x4, y4
   */
  matchBlockUnfold: function matchBlockUnfold(x1, y1, x2, y2) {
    var result;
    var x3 = 0;
    var y3 = 0;
    var canUp = true;
    var canDown = true;
    var canLeft = true;
    var canRight = true; // cc.warn('matchBlockUnfold  ' + x1 + ', ' + y1 + '  : ' + x2 + ', ' + y2);

    for (var i = 1; i < this.rows; i++) {
      // 上
      x3 = x1;
      y3 = y1 + i;

      if (canUp && y3 <= this.columns) {
        canUp = this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT;
        result = this.matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, false);

        if (result) {
          return result;
        }
      } // 下


      x3 = x1;
      y3 = y1 - i;

      if (canDown && y3 >= -1) {
        canDown = this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT;
        result = this.matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, false);

        if (result) {
          return result;
        }
      } // 左


      x3 = x1 - i;
      y3 = y1;

      if (canLeft && x3 >= -1) {
        canLeft = this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT;
        result = this.matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, true);

        if (result) {
          return result;
        }
      } // 右


      x3 = x1 + i;
      y3 = y1;

      if (canRight && x3 <= this.rows) {
        canRight = this._canvasGrids[x3 + 1][y3 + 1] <= this._TYPE_INIT;
        result = this.matchBlockUnfold_axis(x1, y1, x2, y2, x3, y3, true);

        if (result) {
          return result;
        }
      }
    }

    return null;
  },
  _initAnimal: function _initAnimal() {
    this._aniShow = this.endNode.getComponent(cc.Animation);
    this._aniShow.node.active = false;

    this._aniShow.hideEnd = function () {
      this._aniShow.node.active = false;
    }.bind(this); // this._aniShow.node.on(cc.Node.EventType.MOUSE_DOWN,this.closeHandle,this);

  },
  closeHandle: function closeHandle(e, d) {
    // console.log("-----closeHandle----------",e,d)
    this._aniShow.node.active = false;
    cc.director.loadScene('game');
  },

  /**
   * 游戏结束
   */
  gameOver: function gameOver() {
    this.count = 0;
    this.timer = 0;
    cc.audioEngine.pauseAllEffects(); // console.log("-------gameOver-----------",this._score, this.rows * this.columns,this.endNode.getChildByName("win"))

    if (this._score < this.rows * this.columns / 2) {
      cc.audioEngine.playEffect(this.failedAudio, false);
      this.endNode.getChildByName("win").active = false;
      this.endNode.getChildByName("lose").active = true;
      this.endNode.getChildByName("lose").getComponent(cc.Sprite).spriteFrame = this.spriteLose;
    } else {
      cc.audioEngine.playEffect(this.winAudio, false);
      this.endNode.getChildByName("win").active = true;
      this.endNode.getChildByName("lose").active = false;
      this.endNode.getChildByName("win").getComponent(cc.Sprite).spriteFrame = this.spriteWin;
    }

    this._aniShow.node.active = true;

    var state = this._aniShow.play('scaleShow', 1);

    state.repeatCount = 1;
    this._aniShow.node.zIndex = 1000;
    this.gameOverLab.string = "-5";
  },

  /**
   * 过关
   */
  gamePass: function gamePass() {// cc.director.loadScene('gamepass');
  },
  // called every frame, uncomment this function to activate update callback

  /**
   * 系统的更新事件
   */
  update: function update(dt) {
    this.timer += dt;

    if (this._aniShow.node.active) {
      if (this.timer > this.count) {
        this._overTMS--;

        if (this._overTMS < 1) {
          this.closeHandle();
          return;
        }

        this.count += 1;
      }

      this.gameOverLab.string = "-" + this._overTMS;
      return;
    } // 大于已计时秒数


    if (this.timer > this.count) {
      this.timeout.string = this.duration - this.count;

      if (this.count >= this.duration) {
        this.gameOver();
      }

      this.count += 1;

      this._timeLabAni();
    }
  },
  //小于10一下闪烁提示
  _timeLabAni: function _timeLabAni() {
    var tt = Number(this.timeout.string);

    if (tt > 0 && tt < 10) {
      // console.log("---------", tt)
      // this.timeout.node.color = new cc.color(255,1,1); 
      var ani = this.timeout.node.getComponent(cc.Animation);
      var state = ani.play();
      state.repeatCount = 2;
    }
  },
  _bindEvent: function _bindEvent() {// EventManager.getInstance().addEventListener("shake", this.addEvent, this);
  },
  _myShake: function _myShake() {
    var mk = this.cameraNode.getComponent("shake");
    mk.shaker();
  },
  _storageKey: function _storageKey() {
    return "rand_data_key";
  },
  _initScrollView: function _initScrollView() {
    //test
    //cc.sys.localStorage.setItem(this._storageKey(),  "{}" )
    var content = this.rankListNode.getChildByName("scroll").getComponent(cc.ScrollView).content;
    var lastRankString = cc.sys.localStorage.getItem(this._storageKey());

    if (!lastRankString || lastRankString.length < 10) {
      this._rankListData = this._getItemData(10);
    } else {
      this._rankListData = JSON.parse(lastRankString);
    }

    this._rankListData.sort(function (a, b) {
      return b.s3 - a.s3;
    }); // listData = this._getItemData(10)


    for (var i = 0; i < 10; i++) {
      var item = cc.instantiate(this.rankPrefab);
      item.index = i;
      item.parent = content;
      var table = item.getComponent("table");
      this._rankListData[i].s1 = i + 1;
      table.setLabContent(this._rankListData[i]);
    } // console.log("--333-listData---------",JSON.stringify(  this._rankListData) )


    cc.sys.localStorage.setItem(this._storageKey(), JSON.stringify(this._rankListData));
  },
  onActionRank: function onActionRank(e, d) {
    this.rankListNode.active = !this.rankListNode.active;
  },
  _getItemData: function _getItemData(max) {
    var list = [];

    for (var i = 0; i < max; i++) {
      list.push({
        s1: i + 1,
        s2: utools.rndName(3),
        s3: Math.floor(Math.random() * 1000)
      });
    } // console.log("--list>>---", list)


    list.sort(function (a, b) {
      return b.s3 - a.s3;
    });
    return list;
  },
  _addRankList: function _addRankList() {
    var data = {
      s1: 1,
      s2: this.nickName.string,
      s3: this._score
    }; // console.log("-------_addRankList--------", data)

    var gend = this._rankListData[this._rankListData.length - 1]; // console.log("-------_addRankList--------", gend)

    if (gend.s3 > data.s3) {
      return;
    }

    for (var i = 0; i < this._rankListData.length; i++) {
      if (this._rankListData[i].s2 == data.s2 && this._rankListData[i].s3 < data.s3) {
        this._rankListData[i] = data;
        return;
      }
    }

    this._rankListData.push(data);

    this._rankListData.sort(function (a, b) {
      return b.s3 - a.s3;
    });
  },
  _setUIScore: function _setUIScore(lastScore, crtScore) {
    this._score += 2;
    this.gameScore.string = this._score;

    this._myShake(); // console.log("------_setUIScore-----",this._score , this.rows * this.columns)
    //是否刷新


    if (this._score >= this.rows * this.columns) {
      this._totalScore++; // this._resetGame()

      this.gameOver();
    }

    this._addRankList();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZ2FtZS5qcyJdLCJuYW1lcyI6WyJ1dG9vbHMiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJpdGVtUHJlZmFiIiwiUHJlZmFiIiwic3ByaXRlV2luIiwiU3ByaXRlRnJhbWUiLCJzcHJpdGVMb3NlIiwic3ByaXRlZnJhbWVMaXN0IiwiaW1hZ2VMaXN0Iiwibm9kZSIsInRpbWVvdXQiLCJMYWJlbCIsIkJ0bkF1ZGlvIiwiQXVkaW9DbGlwIiwiRXJyb3JBdWRpbyIsIlN1Y2Nlc3NBdWRpbyIsIkNvbnRpbnVlQXVkaW8iLCJiZ011c2ljQXVkaW8iLCJlbmROb2RlIiwiTm9kZSIsImdhbWVTY29yZSIsImNhbWVyYU5vZGUiLCJidG5QcmVOb2RlIiwiQnV0dG9uIiwidGlwc05vZGUiLCJ3aW5BdWRpbyIsImZhaWxlZEF1ZGlvIiwiZ2FtZU92ZXJMYWIiLCJfZ3JhcGhpY3MiLCJHcmFwaGljcyIsIm5vdGljZU5vZGUiLCJyYW5kQnRuIiwicmFua1ByZWZhYiIsInJhbmtMaXN0Tm9kZSIsIm5pY2tOYW1lIiwicm93cyIsImNvbHVtbnMiLCJwYWlycyIsImR1cmF0aW9uIiwiY291bnQiLCJzcHJpdGVXaWR0aCIsInNwcml0ZUhlaWdodCIsInBhZGRpbmdMZWZ0IiwicGFkZGluZ1RvcCIsIl9UWVBFX0RFTEVEIiwiX1RZUEVfSU5JVCIsIl9jYW52YXNHcmlkcyIsIl9sYXN0Q2xpY2tYIiwiX2xhc3RDbGlja1kiLCJfaXNQYXVzZU11c2ljIiwiX3Njb3JlIiwiX3RvdGFsU2NvcmUiLCJfYW5pU2hvdyIsIl9vdmVyVE1TIiwiX3JhbmtMaXN0RGF0YSIsIm9uTG9hZCIsInN0cmluZyIsInJuZE5hbWUiLCJ0aW1lciIsImdldENoaWxkQnlOYW1lIiwiZ2V0Q29tcG9uZW50IiwibGluZVdpZHRoIiwiYWN0aXZlIiwiX2luaXRBbmltYWwiLCJfc2V0VGlwc0xhYk5vZGUiLCJBcnJheSIsImkiLCJqIiwiaW5pdERhdGEiLCJpbml0TWFwIiwiX3Jlc2V0R2FtZSIsIl9zZXRQYXVzZUJnTXVzaWMiLCJfZG9uZU11c2ljIiwiX2luaXROb3RpY2VOb2RlIiwiX2luaXRTY3JvbGxWaWV3Iiwic2VsZiIsInNldFRpbWVvdXQiLCJ0dCIsImFkZFN0clRvTGlzdCIsImZsYWciLCJjb2xvciIsImJ0bkV2ZW50MlByZSIsImF1ZGlvRW5naW5lIiwicGF1c2VBbGxFZmZlY3RzIiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJzaWduIiwib24iLCJFdmVudFR5cGUiLCJUT1VDSF9FTkQiLCJldmVudCIsInBsYXlFZmZlY3QiLCJyb3ciLCJjb2x1bW4iLCJuZXdOb2RlIiwiaW5zdGFudGlhdGUiLCJpbmRleCIsInR5cGUiLCJsZW5ndGgiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSIsImlzZW1wdHkiLCJzY29yZSIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSIsInNodWZmbGUiLCJ4IiwieSIsInhfdG1wIiwieV90bXAiLCJ0ZW1wIiwiYWRkQ2hpbGQiLCJzZXRQb3NpdGlvbiIsIlZlYzIiLCJwb2ludFgiLCJwb2ludFkiLCJfY2xpY2tOb2RlIiwiZCIsImN1cnJlbnRUYXJnZXQiLCJsYXN0Tm9kZSIsImlzTGlua2VkIiwiX3NldFVJU2NvcmUiLCJjbGVhckxpbmtlZCIsIngxIiwieTEiLCJ4MiIsInkyIiwiY2xlYXIiLCJnYW1lUGFzcyIsImdldEFic1hZIiwiYWJzWCIsImFic1kiLCJ3aWR0aCIsImhlaWdodCIsInRtcFhZIiwidG1wQWJzWFkiLCJtYXRjaEJsb2NrTGluZSIsIm1vdmVUbyIsImxpbmVUbyIsInN0cm9rZSIsIm1hdGNoQmxvY2tDb3JuZXIiLCJtYXRjaEJsb2NrVW5mb2xkIiwiWW1pbiIsIm1pbiIsIlltYXgiLCJtYXgiLCJYbWluIiwiWG1heCIsIm1hdGNoQmxvY2tDb3JuZXJfcG9pbnQiLCJ4MyIsInkzIiwic3RNYXRjaCIsInRkTWF0Y2giLCJpc0F4aXNfWCIsInJlc3VsdCIsIm1hdGNoQmxvY2tVbmZvbGRfYXhpcyIsImNvbmNhdCIsImNhblVwIiwiY2FuRG93biIsImNhbkxlZnQiLCJjYW5SaWdodCIsIkFuaW1hdGlvbiIsImhpZGVFbmQiLCJiaW5kIiwiY2xvc2VIYW5kbGUiLCJlIiwiZ2FtZU92ZXIiLCJzdGF0ZSIsInBsYXkiLCJyZXBlYXRDb3VudCIsInpJbmRleCIsInVwZGF0ZSIsImR0IiwiX3RpbWVMYWJBbmkiLCJOdW1iZXIiLCJhbmkiLCJfYmluZEV2ZW50IiwiX215U2hha2UiLCJtayIsInNoYWtlciIsIl9zdG9yYWdlS2V5IiwiY29udGVudCIsIlNjcm9sbFZpZXciLCJsYXN0UmFua1N0cmluZyIsInN5cyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJfZ2V0SXRlbURhdGEiLCJKU09OIiwicGFyc2UiLCJzb3J0IiwiYSIsImIiLCJzMyIsIml0ZW0iLCJwYXJlbnQiLCJ0YWJsZSIsInMxIiwic2V0TGFiQ29udGVudCIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJvbkFjdGlvblJhbmsiLCJsaXN0IiwicHVzaCIsInMyIiwiX2FkZFJhbmtMaXN0IiwiZGF0YSIsImdlbmQiLCJsYXN0U2NvcmUiLCJjcnRTY29yZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJQSxNQUFNLEdBQUdDLE9BQU8sQ0FBQyxVQUFELENBQXBCLEVBQ0E7OztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsVUFBVSxFQUFFSixFQUFFLENBQUNLLE1BRFA7QUFFUkMsSUFBQUEsU0FBUyxFQUFFTixFQUFFLENBQUNPLFdBRk47QUFJUkMsSUFBQUEsVUFBVSxFQUFFUixFQUFFLENBQUNPLFdBSlA7QUFPUkUsSUFBQUEsZUFBZSxFQUFFLENBQUNULEVBQUUsQ0FBQ08sV0FBSixDQVBUO0FBU1JHLElBQUFBLFNBQVMsRUFBRSxDQUFDVixFQUFFLENBQUNXLElBQUosQ0FUSDtBQVdSQyxJQUFBQSxPQUFPLEVBQUVaLEVBQUUsQ0FBQ2EsS0FYSjtBQVlSQyxJQUFBQSxRQUFRLEVBQUVkLEVBQUUsQ0FBQ2UsU0FaTDtBQWNSQyxJQUFBQSxVQUFVLEVBQUVoQixFQUFFLENBQUNlLFNBZFA7QUFnQlJFLElBQUFBLFlBQVksRUFBRWpCLEVBQUUsQ0FBQ2UsU0FoQlQ7QUFpQlJHLElBQUFBLGFBQWEsRUFBRWxCLEVBQUUsQ0FBQ2UsU0FqQlY7QUFvQlJJLElBQUFBLFlBQVksRUFBRW5CLEVBQUUsQ0FBQ2UsU0FwQlQ7QUFzQlJLLElBQUFBLE9BQU8sRUFBRXBCLEVBQUUsQ0FBQ3FCLElBdEJKO0FBdUJSQyxJQUFBQSxTQUFTLEVBQUV0QixFQUFFLENBQUNhLEtBdkJOO0FBd0JSVSxJQUFBQSxVQUFVLEVBQUV2QixFQUFFLENBQUNxQixJQXhCUDtBQXlCUkcsSUFBQUEsVUFBVSxFQUFFeEIsRUFBRSxDQUFDeUIsTUF6QlA7QUEyQlJDLElBQUFBLFFBQVEsRUFBRTFCLEVBQUUsQ0FBQ2EsS0EzQkw7QUE2QlJjLElBQUFBLFFBQVEsRUFBRTNCLEVBQUUsQ0FBQ2UsU0E3Qkw7QUErQlJhLElBQUFBLFdBQVcsRUFBRTVCLEVBQUUsQ0FBQ2UsU0EvQlI7QUFpQ1JjLElBQUFBLFdBQVcsRUFBRTdCLEVBQUUsQ0FBQ2EsS0FqQ1I7QUFtQ1JpQixJQUFBQSxTQUFTLEVBQUU5QixFQUFFLENBQUMrQixRQW5DTjtBQXFDUkMsSUFBQUEsVUFBVSxFQUFFaEMsRUFBRSxDQUFDcUIsSUFyQ1A7QUF1Q1JZLElBQUFBLE9BQU8sRUFBRWpDLEVBQUUsQ0FBQ3lCLE1BdkNKO0FBd0NSUyxJQUFBQSxVQUFVLEVBQUNsQyxFQUFFLENBQUNLLE1BeENOO0FBeUNSOEIsSUFBQUEsWUFBWSxFQUFDbkMsRUFBRSxDQUFDcUIsSUF6Q1I7QUEyQ1JlLElBQUFBLFFBQVEsRUFBRXBDLEVBQUUsQ0FBQ2EsS0EzQ0w7QUE2Q1I7QUFDQXdCLElBQUFBLElBQUksRUFBRSxDQTlDRTtBQStDUjtBQUNBQyxJQUFBQSxPQUFPLEVBQUUsQ0FoREQ7QUFpRFI7QUFDQUMsSUFBQUEsS0FBSyxFQUFFLENBbERDO0FBbURSO0FBQ0FDLElBQUFBLFFBQVEsRUFBRSxFQXBERjtBQXFEUkMsSUFBQUEsS0FBSyxFQUFFLENBckRDO0FBc0RSQyxJQUFBQSxXQUFXLEVBQUUsRUF0REw7QUF1RFJDLElBQUFBLFlBQVksRUFBRSxFQXZETjtBQXdEUkMsSUFBQUEsV0FBVyxFQUFFLEdBeERMO0FBeURSQyxJQUFBQSxVQUFVLEVBQUUsR0F6REo7QUEwRFI7QUFDQUMsSUFBQUEsV0FBVyxFQUFFLENBQUMsQ0EzRE47QUE0RFI7QUFDQUMsSUFBQUEsVUFBVSxFQUFFLENBQUMsQ0E3REw7QUE4RFI7QUFDQUMsSUFBQUEsWUFBWSxFQUFFLElBL0ROO0FBZ0VSQyxJQUFBQSxXQUFXLEVBQUUsQ0FBQyxDQWhFTjtBQWlFUkMsSUFBQUEsV0FBVyxFQUFFLENBQUMsQ0FqRU47QUFtRVI7QUFDQUMsSUFBQUEsYUFBYSxFQUFFLElBcEVQO0FBcUVSO0FBQ0FDLElBQUFBLE1BQU0sRUFBRSxDQXRFQTtBQXVFUkMsSUFBQUEsV0FBVyxFQUFFLENBdkVMO0FBd0VSO0FBQ0FDLElBQUFBLFFBQVEsRUFBRSxJQXpFRjtBQTBFUjtBQUNBQyxJQUFBQSxRQUFRLEVBQUUsQ0EzRUY7QUE0RVI7QUFDQUMsSUFBQUEsYUFBYSxFQUFDO0FBN0VOLEdBSFA7QUFtRkw7O0FBQ0E7QUFDSjtBQUNBO0FBQ0lDLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUNoQixTQUFLckIsUUFBTCxDQUFjc0IsTUFBZCxHQUF1QjVELE1BQU0sQ0FBQzZELE9BQVAsQ0FBZSxDQUFmLENBQXZCO0FBQ0EsU0FBS0MsS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLOUIsU0FBTCxHQUFpQixLQUFLbkIsSUFBTCxDQUFVa0QsY0FBVixDQUF5QixVQUF6QixFQUFxQ0MsWUFBckMsQ0FBa0Q5RCxFQUFFLENBQUMrQixRQUFyRCxDQUFqQjtBQUNBLFNBQUtELFNBQUwsQ0FBZWlDLFNBQWYsR0FBMkIsQ0FBM0I7QUFFQSxTQUFLNUIsWUFBTCxDQUFrQjZCLE1BQWxCLEdBQTJCLEtBQTNCOztBQUVBLFNBQUtDLFdBQUw7O0FBQ0EsU0FBS0MsZUFBTCxDQUFxQixLQUFyQjs7QUFFQSxTQUFLbEIsWUFBTCxHQUFvQixJQUFJbUIsS0FBSixFQUFwQixDQVhnQixDQVloQjs7QUFDQSxTQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsS0FBSy9CLElBQUwsR0FBWSxDQUFoQyxFQUFtQytCLENBQUMsRUFBcEMsRUFBd0M7QUFDcEMsV0FBS3BCLFlBQUwsQ0FBa0JvQixDQUFsQixJQUF1QixJQUFJRCxLQUFKLENBQVVDLENBQVYsQ0FBdkI7O0FBQ0EsV0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHLEtBQUsvQixPQUFMLEdBQWUsQ0FBbkMsRUFBc0MrQixDQUFDLEVBQXZDLEVBQTJDO0FBQ3ZDLGFBQUtyQixZQUFMLENBQWtCb0IsQ0FBbEIsRUFBcUJDLENBQXJCLElBQTBCLENBQUMsQ0FBM0I7QUFDSDtBQUNKOztBQUVELFNBQUszRCxTQUFMLEdBQWlCLElBQUl5RCxLQUFKLEVBQWpCOztBQUNBLFNBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxLQUFLL0IsSUFBekIsRUFBK0IrQixDQUFDLEVBQWhDLEVBQW9DO0FBQ2hDLFdBQUsxRCxTQUFMLENBQWUwRCxDQUFmLElBQW9CLElBQUlELEtBQUosQ0FBVUMsQ0FBVixDQUFwQjs7QUFDQSxXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsS0FBSy9CLE9BQXpCLEVBQWtDK0IsQ0FBQyxFQUFuQyxFQUF1QztBQUNuQyxhQUFLM0QsU0FBTCxDQUFlMEQsQ0FBZixFQUFrQkMsQ0FBbEIsSUFBdUIsSUFBdkI7QUFDSDtBQUNKLEtBMUJlLENBNEJoQjs7O0FBRUEsU0FBS0MsUUFBTDtBQUNBLFNBQUtDLE9BQUw7O0FBQ0EsU0FBS0MsVUFBTDs7QUFDQSxTQUFLQyxnQkFBTDs7QUFFQSxTQUFLbkQsU0FBTCxDQUFlb0MsTUFBZixHQUF3QixLQUFLTixNQUE3QjtBQUNBLFNBQUt2QixXQUFMLENBQWlCNkIsTUFBakIsR0FBMEIsSUFBMUI7O0FBRUEsU0FBS2dCLFVBQUwsQ0FBZ0IsS0FBaEI7O0FBR0EsU0FBS0MsZUFBTDs7QUFDQSxTQUFLQyxlQUFMO0FBQ0gsR0FsSUk7QUFtSUxELEVBQUFBLGVBbklLLDZCQW1JYTtBQUVkLFFBQUlFLElBQUksR0FBRyxJQUFYO0FBQ0FDLElBQUFBLFVBQVUsQ0FBQyxZQUFNO0FBQ2IsVUFBRyxDQUFDRCxJQUFJLENBQUM3QyxVQUFULEVBQXFCO0FBQ2pCLFlBQUkrQyxFQUFFLEdBQUdGLElBQUksQ0FBQzdDLFVBQUwsQ0FBZ0I4QixZQUFoQixDQUE2QixRQUE3QixDQUFULENBRGlCLENBRWpCOztBQUNBaUIsUUFBQUEsRUFBRSxDQUFDQyxZQUFILENBQWdCLGdEQUFoQjs7QUFDQUgsUUFBQUEsSUFBSSxDQUFDRixlQUFMO0FBQ0g7QUFFSixLQVJTLEVBUVAsSUFSTyxDQUFWO0FBVUgsR0FoSkk7QUFrSkxULEVBQUFBLGVBbEpLLDJCQWtKV2UsSUFsSlgsRUFrSmlCO0FBQ2xCLFNBQUt2RCxRQUFMLENBQWNmLElBQWQsQ0FBbUJxRCxNQUFuQixHQUE0QmlCLElBQTVCO0FBQ0EsU0FBS3JFLE9BQUwsQ0FBYUQsSUFBYixDQUFrQnVFLEtBQWxCLEdBQTBCLElBQUlsRixFQUFFLENBQUNrRixLQUFQLENBQWEsR0FBYixFQUFrQixHQUFsQixFQUF1QixHQUF2QixDQUExQjtBQUNILEdBckpJO0FBdUpMQyxFQUFBQSxZQXZKSywwQkF1SlU7QUFDWG5GLElBQUFBLEVBQUUsQ0FBQ29GLFdBQUgsQ0FBZUMsZUFBZjtBQUNBckYsSUFBQUEsRUFBRSxDQUFDc0YsUUFBSCxDQUFZQyxTQUFaLENBQXNCLE1BQXRCO0FBQ0gsR0ExSkk7QUE0SkxiLEVBQUFBLFVBNUpLLHNCQTRKTWMsSUE1Sk4sRUE0Slk7QUFDYixRQUFJQSxJQUFKLEVBQ0ksS0FBS3JDLGFBQUwsR0FBcUIsQ0FBQyxLQUFLQSxhQUEzQixDQUZTLENBR2I7O0FBRUEsUUFBSSxLQUFLQSxhQUFULEVBQXdCLENBQ3BCO0FBRUgsS0FIRCxNQUdPO0FBQ0huRCxNQUFBQSxFQUFFLENBQUNvRixXQUFILENBQWVDLGVBQWY7QUFDSDtBQUVKLEdBeEtJO0FBMEtMWixFQUFBQSxnQkExS0ssOEJBMEtjO0FBQ2YsUUFBSUksSUFBSSxHQUFHLElBQVg7QUFDQSxTQUFLbEUsSUFBTCxDQUFVa0QsY0FBVixDQUF5QixPQUF6QixFQUFrQzRCLEVBQWxDLENBQXFDekYsRUFBRSxDQUFDcUIsSUFBSCxDQUFRcUUsU0FBUixDQUFrQkMsU0FBdkQsRUFBa0UsVUFBQ0MsS0FBRCxFQUFXO0FBRXpFZixNQUFBQSxJQUFJLENBQUNILFVBQUwsQ0FBZ0IsSUFBaEI7QUFDSCxLQUhEO0FBSUgsR0FoTEk7QUFpTExGLEVBQUFBLFVBakxLLHdCQWlMUTtBQUNULFFBQUlLLElBQUksR0FBRyxJQUFYO0FBQ0EsU0FBS2xFLElBQUwsQ0FBVWtELGNBQVYsQ0FBeUIsU0FBekIsRUFBb0M0QixFQUFwQyxDQUF1Q3pGLEVBQUUsQ0FBQ3FCLElBQUgsQ0FBUXFFLFNBQVIsQ0FBa0JDLFNBQXpELEVBQW9FLFVBQUNDLEtBQUQsRUFBVztBQUMzRTVGLE1BQUFBLEVBQUUsQ0FBQ29GLFdBQUgsQ0FBZVMsVUFBZixDQUEwQmhCLElBQUksQ0FBQzNELGFBQS9CLEVBQThDLEtBQTlDO0FBQ0FsQixNQUFBQSxFQUFFLENBQUNzRixRQUFILENBQVlDLFNBQVosQ0FBc0IsTUFBdEI7QUFDSCxLQUhEO0FBSUgsR0F2TEk7O0FBd0xMO0FBQ0o7QUFDQTtBQUNJakIsRUFBQUEsUUFBUSxFQUFFLG9CQUFZO0FBQ2xCLFNBQUssSUFBSXdCLEdBQUcsR0FBRyxDQUFmLEVBQWtCQSxHQUFHLEdBQUcsS0FBS3pELElBQTdCLEVBQW1DeUQsR0FBRyxFQUF0QyxFQUEwQztBQUN0QyxXQUFLLElBQUlDLE1BQU0sR0FBRyxDQUFsQixFQUFxQkEsTUFBTSxHQUFHLEtBQUt6RCxPQUFuQyxFQUE0Q3lELE1BQU0sRUFBbEQsRUFBc0Q7QUFDbEQsWUFBSUMsT0FBTyxHQUFHaEcsRUFBRSxDQUFDaUcsV0FBSCxDQUFlLEtBQUs3RixVQUFwQixDQUFkLENBRGtELENBQ1U7O0FBQzVELFlBQUk4RixLQUFLLEdBQUdKLEdBQUcsR0FBRyxLQUFLekQsSUFBWCxHQUFrQjBELE1BQTlCO0FBQ0EsWUFBSUksSUFBSSxHQUFHRCxLQUFLLEdBQUcsS0FBS3pGLGVBQUwsQ0FBcUIyRixNQUF4QyxDQUhrRCxDQUtsRDs7QUFDQUosUUFBQUEsT0FBTyxDQUFDbkMsY0FBUixDQUF1QixZQUF2QixFQUFxQ0MsWUFBckMsQ0FBa0Q5RCxFQUFFLENBQUNxRyxNQUFyRCxFQUE2REMsV0FBN0QsR0FBMkUsS0FBSzdGLGVBQUwsQ0FBcUIwRixJQUFyQixDQUEzRTtBQUNBSCxRQUFBQSxPQUFPLENBQUNPLE9BQVIsR0FBa0IsS0FBbEI7QUFDQVAsUUFBQUEsT0FBTyxDQUFDRyxJQUFSLEdBQWVBLElBQWY7QUFDQUgsUUFBQUEsT0FBTyxDQUFDRSxLQUFSLEdBQWdCQSxLQUFoQjtBQUNBRixRQUFBQSxPQUFPLENBQUNRLEtBQVIsR0FBZ0JDLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsRUFBM0IsQ0FBaEI7QUFFQSxhQUFLakcsU0FBTCxDQUFlb0YsR0FBZixFQUFvQkMsTUFBcEIsSUFBOEJDLE9BQTlCLENBWmtELENBYWxEOztBQUNBLGFBQUtoRCxZQUFMLENBQWtCOEMsR0FBRyxHQUFHLENBQXhCLEVBQTJCQyxNQUFNLEdBQUcsQ0FBcEMsSUFBeUNJLElBQXpDO0FBQ0g7QUFDSjs7QUFDRCxTQUFLUyxPQUFMO0FBQ0gsR0EvTUk7O0FBaU5MO0FBQ0o7QUFDQTtBQUVJQSxFQUFBQSxPQUFPLEVBQUUsbUJBQVk7QUFDakIsU0FBSyxJQUFJeEMsQ0FBQyxHQUFHLEtBQUsvQixJQUFMLEdBQVksS0FBS0MsT0FBakIsR0FBMkIsQ0FBeEMsRUFBMkM4QixDQUFDLEdBQUcsQ0FBL0MsRUFBa0RBLENBQUMsRUFBbkQsRUFBdUQ7QUFDbkQsVUFBSUMsQ0FBQyxHQUFHb0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxNQUFpQnZDLENBQUMsR0FBRyxDQUFyQixDQUFYLENBQVI7QUFDQSxVQUFJeUMsQ0FBQyxHQUFHekMsQ0FBQyxHQUFHLEtBQUsvQixJQUFqQjtBQUNBLFVBQUl5RSxDQUFDLEdBQUdMLElBQUksQ0FBQ0MsS0FBTCxDQUFXdEMsQ0FBQyxHQUFHLEtBQUsvQixJQUFwQixDQUFSO0FBQ0EsVUFBSTBFLEtBQUssR0FBRzFDLENBQUMsR0FBRyxLQUFLaEMsSUFBckI7QUFDQSxVQUFJMkUsS0FBSyxHQUFHUCxJQUFJLENBQUNDLEtBQUwsQ0FBV3JDLENBQUMsR0FBRyxLQUFLaEMsSUFBcEIsQ0FBWjtBQUNBLFVBQUk0RSxJQUFJLEdBQUcsS0FBS3ZHLFNBQUwsQ0FBZW1HLENBQWYsRUFBa0JDLENBQWxCLENBQVg7QUFDQSxXQUFLcEcsU0FBTCxDQUFlbUcsQ0FBZixFQUFrQkMsQ0FBbEIsSUFBdUIsS0FBS3BHLFNBQUwsQ0FBZXFHLEtBQWYsRUFBc0JDLEtBQXRCLENBQXZCO0FBQ0EsV0FBS3RHLFNBQUwsQ0FBZXFHLEtBQWYsRUFBc0JDLEtBQXRCLElBQStCQyxJQUEvQjtBQUNIO0FBQ0osR0FoT0k7O0FBa09MO0FBQ0o7QUFDQTtBQUNJMUMsRUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBQ2pCLFNBQUssSUFBSXVCLEdBQUcsR0FBRyxDQUFmLEVBQWtCQSxHQUFHLEdBQUcsS0FBS3pELElBQTdCLEVBQW1DeUQsR0FBRyxFQUF0QyxFQUEwQztBQUN0QyxXQUFLLElBQUlDLE1BQU0sR0FBRyxDQUFsQixFQUFxQkEsTUFBTSxHQUFHLEtBQUt6RCxPQUFuQyxFQUE0Q3lELE1BQU0sRUFBbEQsRUFBc0Q7QUFDbEQsWUFBSUMsT0FBTyxHQUFHLEtBQUt0RixTQUFMLENBQWVvRixHQUFmLEVBQW9CQyxNQUFwQixDQUFkO0FBQ0EsYUFBS3BGLElBQUwsQ0FBVXVHLFFBQVYsQ0FBbUJsQixPQUFuQjtBQUVBQSxRQUFBQSxPQUFPLENBQUNtQixXQUFSLENBQW9CbkgsRUFBRSxDQUFDb0gsSUFBSCxDQUFRLEtBQUsxRSxXQUFMLEdBQW1Cb0QsR0FBbkIsR0FBeUIsS0FBS2xELFdBQXRDLEVBQW1ELEtBQUtELFlBQUwsR0FBb0JvRCxNQUFwQixHQUE2QixLQUFLbEQsVUFBckYsQ0FBcEI7QUFFQW1ELFFBQUFBLE9BQU8sQ0FBQ3FCLE1BQVIsR0FBaUJ2QixHQUFqQjtBQUNBRSxRQUFBQSxPQUFPLENBQUNzQixNQUFSLEdBQWlCdkIsTUFBakI7QUFFQUMsUUFBQUEsT0FBTyxDQUFDUCxFQUFSLENBQVd6RixFQUFFLENBQUNxQixJQUFILENBQVFxRSxTQUFSLENBQWtCQyxTQUE3QixFQUF3QyxLQUFLNEIsVUFBN0MsRUFBeUQsSUFBekQ7QUFDSDtBQUNKO0FBRUosR0FwUEk7QUFzUExBLEVBQUFBLFVBdFBLLHNCQXNQTUMsQ0F0UE4sRUFzUFM7QUFFVnhILElBQUFBLEVBQUUsQ0FBQ29GLFdBQUgsQ0FBZVMsVUFBZixDQUEwQixLQUFLL0UsUUFBL0IsRUFBeUMsS0FBekMsRUFGVSxDQUlWOztBQUNBLFFBQUkrRCxJQUFJLEdBQUcsSUFBWCxDQUxVLENBTVY7O0FBQ0EsUUFBSWxFLElBQUksR0FBRzZHLENBQUMsQ0FBQ0MsYUFBYjtBQUVBLFFBQUlDLFFBQVEsR0FBRyxJQUFmOztBQUNBLFFBQUk3QyxJQUFJLENBQUM1QixXQUFMLElBQW9CLENBQUMsQ0FBckIsSUFBMEI0QixJQUFJLENBQUMzQixXQUFMLElBQW9CLENBQUMsQ0FBbkQsRUFBc0Q7QUFFbER3RSxNQUFBQSxRQUFRLEdBQUc3QyxJQUFJLENBQUNuRSxTQUFMLENBQWVtRSxJQUFJLENBQUM1QixXQUFwQixFQUFpQzRCLElBQUksQ0FBQzNCLFdBQXRDLENBQVg7QUFFSCxLQWRTLENBaUJWO0FBRUE7OztBQUNBLFFBQUkyQixJQUFJLENBQUM1QixXQUFMLElBQW9CLENBQUMsQ0FBckIsSUFBMEI0QixJQUFJLENBQUM1QixXQUFMLElBQW9CLENBQUMsQ0FBbkQsRUFBc0Q7QUFDbEQ7QUFFQTRCLE1BQUFBLElBQUksQ0FBQzVCLFdBQUwsR0FBbUJ0QyxJQUFJLENBQUMwRyxNQUF4QjtBQUNBeEMsTUFBQUEsSUFBSSxDQUFDM0IsV0FBTCxHQUFtQnZDLElBQUksQ0FBQzJHLE1BQXhCO0FBQ0gsS0FMRCxNQUtPLElBQUl6QyxJQUFJLENBQUM1QixXQUFMLElBQW9CdEMsSUFBSSxDQUFDMEcsTUFBekIsSUFBbUN4QyxJQUFJLENBQUMzQixXQUFMLElBQW9CdkMsSUFBSSxDQUFDMkcsTUFBaEUsRUFBd0UsQ0FDM0U7QUFFSCxLQUhNLE1BR0EsSUFBSUksUUFBUSxDQUFDdkIsSUFBVCxJQUFpQnhGLElBQUksQ0FBQ3dGLElBQTFCLEVBQWdDO0FBQU07QUFDekMsVUFBSXRCLElBQUksQ0FBQzhDLFFBQUwsQ0FBYzlDLElBQUksQ0FBQzVCLFdBQW5CLEVBQWdDNEIsSUFBSSxDQUFDM0IsV0FBckMsRUFBa0R2QyxJQUFJLENBQUMwRyxNQUF2RCxFQUErRDFHLElBQUksQ0FBQzJHLE1BQXBFLENBQUosRUFBaUY7QUFBSztBQUNsRnpDLFFBQUFBLElBQUksQ0FBQytDLFdBQUwsQ0FBaUJGLFFBQVEsQ0FBQ2xCLEtBQTFCLEVBQWlDN0YsSUFBSSxDQUFDNkYsS0FBdEMsRUFENkUsQ0FFN0U7OztBQUNBMUIsUUFBQUEsVUFBVSxDQUFDLFlBQU07QUFDYjtBQUNBRCxVQUFBQSxJQUFJLENBQUNnRCxXQUFMLENBQWlCaEQsSUFBSSxDQUFDNUIsV0FBdEIsRUFBbUM0QixJQUFJLENBQUMzQixXQUF4QyxFQUFxRHZDLElBQUksQ0FBQzBHLE1BQTFELEVBQWtFMUcsSUFBSSxDQUFDMkcsTUFBdkU7QUFFQXpDLFVBQUFBLElBQUksQ0FBQzVCLFdBQUwsR0FBbUIsQ0FBQyxDQUFwQjtBQUNBNEIsVUFBQUEsSUFBSSxDQUFDM0IsV0FBTCxHQUFtQixDQUFDLENBQXBCO0FBQ0gsU0FOUyxFQU1QLEdBTk8sQ0FBVjtBQVFILE9BWEQsTUFXTztBQUVIMkIsUUFBQUEsSUFBSSxDQUFDNUIsV0FBTCxHQUFtQnRDLElBQUksQ0FBQzBHLE1BQXhCO0FBQ0F4QyxRQUFBQSxJQUFJLENBQUMzQixXQUFMLEdBQW1CdkMsSUFBSSxDQUFDMkcsTUFBeEIsQ0FIRyxDQUlIO0FBQ0g7QUFDSixLQWxCTSxNQWtCQTtBQUVIekMsTUFBQUEsSUFBSSxDQUFDNUIsV0FBTCxHQUFtQnRDLElBQUksQ0FBQzBHLE1BQXhCO0FBQ0F4QyxNQUFBQSxJQUFJLENBQUMzQixXQUFMLEdBQW1CdkMsSUFBSSxDQUFDMkcsTUFBeEI7QUFFSDtBQUNKLEdBMVNJOztBQTRTTDtBQUNKO0FBQ0E7QUFDQTtBQUNJTyxFQUFBQSxXQUFXLEVBQUUscUJBQVVDLEVBQVYsRUFBY0MsRUFBZCxFQUFrQkMsRUFBbEIsRUFBc0JDLEVBQXRCLEVBQTBCO0FBRW5DLFNBQUt2SCxTQUFMLENBQWVvSCxFQUFmLEVBQW1CQyxFQUFuQixFQUF1QmxFLGNBQXZCLENBQXNDLFlBQXRDLEVBQW9EQyxZQUFwRCxDQUFpRTlELEVBQUUsQ0FBQ3FHLE1BQXBFLEVBQTRFQyxXQUE1RSxHQUEwRixJQUExRixDQUZtQyxDQUluQzs7QUFDQSxTQUFLNUYsU0FBTCxDQUFlc0gsRUFBZixFQUFtQkMsRUFBbkIsRUFBdUJwRSxjQUF2QixDQUFzQyxZQUF0QyxFQUFvREMsWUFBcEQsQ0FBaUU5RCxFQUFFLENBQUNxRyxNQUFwRSxFQUE0RUMsV0FBNUUsR0FBMEYsSUFBMUY7QUFFQSxTQUFLdEQsWUFBTCxDQUFrQjhFLEVBQUUsR0FBRyxDQUF2QixFQUEwQkMsRUFBRSxHQUFHLENBQS9CLElBQW9DLEtBQUtqRixXQUF6QztBQUNBLFNBQUtFLFlBQUwsQ0FBa0JnRixFQUFFLEdBQUcsQ0FBdkIsRUFBMEJDLEVBQUUsR0FBRyxDQUEvQixJQUFvQyxLQUFLbkYsV0FBekM7QUFFQTlDLElBQUFBLEVBQUUsQ0FBQ29GLFdBQUgsQ0FBZVMsVUFBZixDQUEwQixLQUFLNUUsWUFBL0IsRUFBNkMsS0FBN0M7O0FBRUEsU0FBS2EsU0FBTCxDQUFlb0csS0FBZjs7QUFDQSxTQUFLM0YsS0FBTCxJQUFjLENBQWQsQ0FibUMsQ0FjbkM7O0FBRUEsUUFBSSxLQUFLQSxLQUFMLElBQWMsQ0FBbEIsRUFDSSxLQUFLNEYsUUFBTDtBQUNQLEdBbFVJOztBQW9VTDtBQUNKO0FBQ0E7QUFDSUMsRUFBQUEsUUFBUSxFQUFFLGtCQUFVdkIsQ0FBVixFQUFhQyxDQUFiLEVBQWdCO0FBQ3RCLFFBQUl1QixJQUFJLEdBQUcsQ0FBWDtBQUNBLFFBQUlDLElBQUksR0FBRyxDQUFYOztBQUNBLFFBQUl6QixDQUFDLEdBQUcsQ0FBUixFQUFXO0FBQ1B3QixNQUFBQSxJQUFJLEdBQUcsS0FBSzFILElBQUwsQ0FBVWtHLENBQVYsR0FBYyxLQUFLbkcsU0FBTCxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUJtRyxDQUFuQyxHQUF1QyxLQUFLbkcsU0FBTCxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUI2SCxLQUFuRTtBQUNILEtBRkQsTUFFTyxJQUFJMUIsQ0FBQyxJQUFJLEtBQUt4RSxJQUFkLEVBQW9CO0FBQ3ZCZ0csTUFBQUEsSUFBSSxHQUFHLEtBQUsxSCxJQUFMLENBQVVrRyxDQUFWLEdBQWMsS0FBS25HLFNBQUwsQ0FBZSxLQUFLMkIsSUFBTCxHQUFZLENBQTNCLEVBQThCLENBQTlCLEVBQWlDd0UsQ0FBL0MsR0FBbUQsS0FBS25HLFNBQUwsQ0FBZSxDQUFmLEVBQWtCLENBQWxCLEVBQXFCNkgsS0FBL0U7QUFDSCxLQUZNLE1BRUE7QUFDSEYsTUFBQUEsSUFBSSxHQUFHLEtBQUsxSCxJQUFMLENBQVVrRyxDQUFWLEdBQWMsS0FBS25HLFNBQUwsQ0FBZW1HLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUJBLENBQTFDO0FBQ0g7O0FBQ0QsUUFBSUMsQ0FBQyxHQUFHLENBQVIsRUFBVztBQUNQd0IsTUFBQUEsSUFBSSxHQUFHLEtBQUszSCxJQUFMLENBQVVtRyxDQUFWLEdBQWMsS0FBS3BHLFNBQUwsQ0FBZSxDQUFmLEVBQWtCLENBQWxCLEVBQXFCb0csQ0FBbkMsR0FBdUMsS0FBS3BHLFNBQUwsQ0FBZSxDQUFmLEVBQWtCLENBQWxCLEVBQXFCOEgsTUFBbkU7QUFDSCxLQUZELE1BRU8sSUFBSTFCLENBQUMsSUFBSSxLQUFLeEUsT0FBZCxFQUF1QjtBQUMxQmdHLE1BQUFBLElBQUksR0FBRyxLQUFLM0gsSUFBTCxDQUFVbUcsQ0FBVixHQUFjLEtBQUtwRyxTQUFMLENBQWUsQ0FBZixFQUFrQixLQUFLNEIsT0FBTCxHQUFlLENBQWpDLEVBQW9Dd0UsQ0FBbEQsR0FBc0QsS0FBS3BHLFNBQUwsQ0FBZSxDQUFmLEVBQWtCLENBQWxCLEVBQXFCOEgsTUFBbEY7QUFDSCxLQUZNLE1BRUE7QUFDSEYsTUFBQUEsSUFBSSxHQUFHLEtBQUszSCxJQUFMLENBQVVtRyxDQUFWLEdBQWMsS0FBS3BHLFNBQUwsQ0FBZSxDQUFmLEVBQWtCb0csQ0FBbEIsRUFBcUJBLENBQTFDO0FBQ0g7O0FBRUQsV0FBTyxDQUFDdUIsSUFBRCxFQUFPQyxJQUFQLENBQVA7QUFDSCxHQTFWSTs7QUE0Vkw7QUFDSjtBQUNBO0FBQ0lYLEVBQUFBLFFBQVEsRUFBRSxrQkFBVUcsRUFBVixFQUFjQyxFQUFkLEVBQWtCQyxFQUFsQixFQUFzQkMsRUFBdEIsRUFBMEI7QUFDaEMsUUFBSVEsS0FBSyxHQUFHLEVBQVo7QUFDQSxRQUFJQyxRQUFRLEdBQUcsRUFBZjs7QUFFQSxRQUFJLEtBQUtDLGNBQUwsQ0FBb0JiLEVBQXBCLEVBQXdCQyxFQUF4QixFQUE0QkMsRUFBNUIsRUFBZ0NDLEVBQWhDLENBQUosRUFBeUM7QUFDckM7QUFDQVMsTUFBQUEsUUFBUSxHQUFHLEtBQUtOLFFBQUwsQ0FBY04sRUFBZCxFQUFrQkMsRUFBbEIsQ0FBWDs7QUFDQSxXQUFLakcsU0FBTCxDQUFlOEcsTUFBZixDQUFzQkYsUUFBUSxDQUFDLENBQUQsQ0FBOUIsRUFBbUNBLFFBQVEsQ0FBQyxDQUFELENBQTNDOztBQUNBQSxNQUFBQSxRQUFRLEdBQUcsS0FBS04sUUFBTCxDQUFjSixFQUFkLEVBQWtCQyxFQUFsQixDQUFYOztBQUNBLFdBQUtuRyxTQUFMLENBQWUrRyxNQUFmLENBQXNCSCxRQUFRLENBQUMsQ0FBRCxDQUE5QixFQUFtQ0EsUUFBUSxDQUFDLENBQUQsQ0FBM0M7O0FBQ0EsV0FBSzVHLFNBQUwsQ0FBZWdILE1BQWY7O0FBRUEsYUFBTyxJQUFQO0FBQ0gsS0FURCxNQVNPO0FBQ0hMLE1BQUFBLEtBQUssR0FBRyxLQUFLTSxnQkFBTCxDQUFzQmpCLEVBQXRCLEVBQTBCQyxFQUExQixFQUE4QkMsRUFBOUIsRUFBa0NDLEVBQWxDLEVBQXNDLElBQXRDLENBQVI7O0FBQ0EsVUFBSVEsS0FBSixFQUFXO0FBQ1A7QUFDQUMsUUFBQUEsUUFBUSxHQUFHLEtBQUtOLFFBQUwsQ0FBY04sRUFBZCxFQUFrQkMsRUFBbEIsQ0FBWDs7QUFDQSxhQUFLakcsU0FBTCxDQUFlOEcsTUFBZixDQUFzQkYsUUFBUSxDQUFDLENBQUQsQ0FBOUIsRUFBbUNBLFFBQVEsQ0FBQyxDQUFELENBQTNDOztBQUNBQSxRQUFBQSxRQUFRLEdBQUcsS0FBS04sUUFBTCxDQUFjSyxLQUFLLENBQUMsQ0FBRCxDQUFuQixFQUF3QkEsS0FBSyxDQUFDLENBQUQsQ0FBN0IsQ0FBWDs7QUFDQSxhQUFLM0csU0FBTCxDQUFlK0csTUFBZixDQUFzQkgsUUFBUSxDQUFDLENBQUQsQ0FBOUIsRUFBbUNBLFFBQVEsQ0FBQyxDQUFELENBQTNDOztBQUNBQSxRQUFBQSxRQUFRLEdBQUcsS0FBS04sUUFBTCxDQUFjSixFQUFkLEVBQWtCQyxFQUFsQixDQUFYOztBQUNBLGFBQUtuRyxTQUFMLENBQWUrRyxNQUFmLENBQXNCSCxRQUFRLENBQUMsQ0FBRCxDQUE5QixFQUFtQ0EsUUFBUSxDQUFDLENBQUQsQ0FBM0M7O0FBQ0EsYUFBSzVHLFNBQUwsQ0FBZWdILE1BQWY7O0FBRUEsZUFBTyxJQUFQO0FBQ0gsT0FYRCxNQVlLO0FBQ0RMLFFBQUFBLEtBQUssR0FBRyxLQUFLTyxnQkFBTCxDQUFzQmxCLEVBQXRCLEVBQTBCQyxFQUExQixFQUE4QkMsRUFBOUIsRUFBa0NDLEVBQWxDLENBQVI7O0FBQ0EsWUFBSVEsS0FBSixFQUFXO0FBQ1A7QUFDQUMsVUFBQUEsUUFBUSxHQUFHLEtBQUtOLFFBQUwsQ0FBY04sRUFBZCxFQUFrQkMsRUFBbEIsQ0FBWDs7QUFDQSxlQUFLakcsU0FBTCxDQUFlOEcsTUFBZixDQUFzQkYsUUFBUSxDQUFDLENBQUQsQ0FBOUIsRUFBbUNBLFFBQVEsQ0FBQyxDQUFELENBQTNDOztBQUNBQSxVQUFBQSxRQUFRLEdBQUcsS0FBS04sUUFBTCxDQUFjSyxLQUFLLENBQUMsQ0FBRCxDQUFuQixFQUF3QkEsS0FBSyxDQUFDLENBQUQsQ0FBN0IsQ0FBWDs7QUFDQSxlQUFLM0csU0FBTCxDQUFlK0csTUFBZixDQUFzQkgsUUFBUSxDQUFDLENBQUQsQ0FBOUIsRUFBbUNBLFFBQVEsQ0FBQyxDQUFELENBQTNDOztBQUNBQSxVQUFBQSxRQUFRLEdBQUcsS0FBS04sUUFBTCxDQUFjSyxLQUFLLENBQUMsQ0FBRCxDQUFuQixFQUF3QkEsS0FBSyxDQUFDLENBQUQsQ0FBN0IsQ0FBWDs7QUFDQSxlQUFLM0csU0FBTCxDQUFlK0csTUFBZixDQUFzQkgsUUFBUSxDQUFDLENBQUQsQ0FBOUIsRUFBbUNBLFFBQVEsQ0FBQyxDQUFELENBQTNDOztBQUNBQSxVQUFBQSxRQUFRLEdBQUcsS0FBS04sUUFBTCxDQUFjSixFQUFkLEVBQWtCQyxFQUFsQixDQUFYOztBQUNBLGVBQUtuRyxTQUFMLENBQWUrRyxNQUFmLENBQXNCSCxRQUFRLENBQUMsQ0FBRCxDQUE5QixFQUFtQ0EsUUFBUSxDQUFDLENBQUQsQ0FBM0M7O0FBQ0EsZUFBSzVHLFNBQUwsQ0FBZWdILE1BQWY7O0FBRUEsaUJBQU8sSUFBUDtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxXQUFPLEtBQVA7QUFDSCxHQTlZSTs7QUFnWkw7QUFDSjtBQUNBO0FBQ0lILEVBQUFBLGNBQWMsRUFBRSx3QkFBVWIsRUFBVixFQUFjQyxFQUFkLEVBQWtCQyxFQUFsQixFQUFzQkMsRUFBdEIsRUFBMEI7QUFDdEM7QUFDQSxRQUFJSCxFQUFFLElBQUlFLEVBQU4sSUFBWUQsRUFBRSxJQUFJRSxFQUF0QixFQUEwQjtBQUN0QixhQUFPLEtBQVA7QUFDSDs7QUFFRCxRQUFJSCxFQUFFLElBQUlFLEVBQVYsRUFBYztBQUNWO0FBQ0EsVUFBSUYsRUFBRSxHQUFHLENBQUwsSUFBVUEsRUFBRSxJQUFJLEtBQUt6RixJQUF6QixFQUErQjtBQUMzQixlQUFPLElBQVA7QUFDSDs7QUFDRCxVQUFJNEcsSUFBSSxHQUFHeEMsSUFBSSxDQUFDeUMsR0FBTCxDQUFTbkIsRUFBVCxFQUFhRSxFQUFiLElBQW1CLENBQTlCO0FBQ0EsVUFBSWtCLElBQUksR0FBRzFDLElBQUksQ0FBQzJDLEdBQUwsQ0FBU3JCLEVBQVQsRUFBYUUsRUFBYixDQUFYOztBQUNBLFdBQUtnQixJQUFMLEVBQVdBLElBQUksR0FBR0UsSUFBbEIsRUFBd0JGLElBQUksRUFBNUIsRUFBZ0M7QUFDNUIsWUFBSSxLQUFLakcsWUFBTCxDQUFrQjhFLEVBQUUsR0FBRyxDQUF2QixFQUEwQm1CLElBQUksR0FBRyxDQUFqQyxJQUFzQyxLQUFLbEcsVUFBL0MsRUFBMkQ7QUFDdkQsaUJBQU8sS0FBUDtBQUNIO0FBQ0o7QUFDSixLQVpELE1BWU8sSUFBSWdGLEVBQUUsSUFBSUUsRUFBVixFQUFjO0FBQ2pCO0FBQ0EsVUFBSUYsRUFBRSxHQUFHLENBQUwsSUFBVUEsRUFBRSxJQUFJLEtBQUt6RixPQUF6QixFQUFrQztBQUM5QixlQUFPLElBQVA7QUFDSDs7QUFDRCxVQUFJK0csSUFBSSxHQUFHNUMsSUFBSSxDQUFDeUMsR0FBTCxDQUFTcEIsRUFBVCxFQUFhRSxFQUFiLElBQW1CLENBQTlCO0FBQ0EsVUFBSXNCLElBQUksR0FBRzdDLElBQUksQ0FBQzJDLEdBQUwsQ0FBU3RCLEVBQVQsRUFBYUUsRUFBYixDQUFYOztBQUNBLFdBQUtxQixJQUFMLEVBQVdBLElBQUksR0FBR0MsSUFBbEIsRUFBd0JELElBQUksRUFBNUIsRUFBZ0M7QUFDNUIsWUFBSSxLQUFLckcsWUFBTCxDQUFrQnFHLElBQUksR0FBRyxDQUF6QixFQUE0QnRCLEVBQUUsR0FBRyxDQUFqQyxJQUFzQyxLQUFLaEYsVUFBL0MsRUFBMkQ7QUFDdkQsaUJBQU8sS0FBUDtBQUNIO0FBQ0o7QUFDSjs7QUFFRCxXQUFPLElBQVA7QUFDSCxHQXBiSTs7QUFzYkw7QUFDSjtBQUNBO0FBQ0l3RyxFQUFBQSxzQkFBc0IsRUFBRSxnQ0FBVXpCLEVBQVYsRUFBY0MsRUFBZCxFQUFrQkMsRUFBbEIsRUFBc0JDLEVBQXRCLEVBQTBCdUIsRUFBMUIsRUFBOEJDLEVBQTlCLEVBQWtDO0FBQ3RELFFBQUlDLE9BQU8sR0FBRyxLQUFLZixjQUFMLENBQW9CYixFQUFwQixFQUF3QkMsRUFBeEIsRUFBNEJ5QixFQUE1QixFQUFnQ0MsRUFBaEMsQ0FBZDs7QUFDQSxRQUFJQyxPQUFKLEVBQWE7QUFDVCxVQUFJQyxPQUFPLEdBQUcsS0FBS2hCLGNBQUwsQ0FBb0JhLEVBQXBCLEVBQXdCQyxFQUF4QixFQUE0QnpCLEVBQTVCLEVBQWdDQyxFQUFoQyxDQUFkOztBQUNBLFVBQUkwQixPQUFKLEVBQWE7QUFDVCxlQUFPLENBQUNILEVBQUQsRUFBS0MsRUFBTCxDQUFQO0FBQ0g7QUFDSjs7QUFDRCxXQUFPLElBQVA7QUFDSCxHQWxjSTs7QUFvY0w7QUFDSjtBQUNBO0FBQ0E7QUFDSVYsRUFBQUEsZ0JBQWdCLEVBQUUsMEJBQVVqQixFQUFWLEVBQWNDLEVBQWQsRUFBa0JDLEVBQWxCLEVBQXNCQyxFQUF0QixFQUEwQjJCLFFBQTFCLEVBQW9DO0FBQ2xEO0FBQ0EsUUFBSUMsTUFBSixDQUZrRCxDQUdsRDs7QUFDQSxRQUFJL0IsRUFBRSxJQUFJRSxFQUFOLElBQVlELEVBQUUsSUFBSUUsRUFBdEIsRUFBMEI7QUFDdEIsYUFBTyxJQUFQO0FBQ0gsS0FOaUQsQ0FRbEQ7OztBQUNBLFFBQUksS0FBS2pGLFlBQUwsQ0FBa0I4RSxFQUFFLEdBQUcsQ0FBdkIsRUFBMEJHLEVBQUUsR0FBRyxDQUEvQixLQUFxQyxLQUFLbEYsVUFBMUMsSUFBd0Q2RyxRQUFRLElBQUksS0FBeEUsRUFBK0U7QUFDM0VDLE1BQUFBLE1BQU0sR0FBRyxLQUFLTixzQkFBTCxDQUE0QnpCLEVBQTVCLEVBQWdDQyxFQUFoQyxFQUFvQ0MsRUFBcEMsRUFBd0NDLEVBQXhDLEVBQTRDSCxFQUE1QyxFQUFnREcsRUFBaEQsQ0FBVDs7QUFDQSxVQUFJNEIsTUFBSixFQUFZO0FBQ1IsZUFBT0EsTUFBUDtBQUNIO0FBQ0osS0FkaUQsQ0FnQmxEOzs7QUFDQSxRQUFJLEtBQUs3RyxZQUFMLENBQWtCZ0YsRUFBRSxHQUFHLENBQXZCLEVBQTBCRCxFQUFFLEdBQUcsQ0FBL0IsS0FBcUMsS0FBS2hGLFVBQTFDLElBQXdENkcsUUFBUSxJQUFJLElBQXhFLEVBQThFO0FBQzFFQyxNQUFBQSxNQUFNLEdBQUcsS0FBS04sc0JBQUwsQ0FBNEJ6QixFQUE1QixFQUFnQ0MsRUFBaEMsRUFBb0NDLEVBQXBDLEVBQXdDQyxFQUF4QyxFQUE0Q0QsRUFBNUMsRUFBZ0RELEVBQWhELENBQVQ7O0FBQ0EsVUFBSThCLE1BQUosRUFBWTtBQUNSLGVBQU9BLE1BQVA7QUFDSDtBQUNKOztBQUVELFdBQU8sSUFBUDtBQUNILEdBamVJOztBQW1lTDtBQUNKO0FBQ0E7QUFDSUMsRUFBQUEscUJBQXFCLEVBQUUsK0JBQVVoQyxFQUFWLEVBQWNDLEVBQWQsRUFBa0JDLEVBQWxCLEVBQXNCQyxFQUF0QixFQUEwQnVCLEVBQTFCLEVBQThCQyxFQUE5QixFQUFrQ0csUUFBbEMsRUFBNEM7QUFFL0QsUUFBSW5CLEtBQUssR0FBRyxFQUFaOztBQUNBLFFBQUksS0FBS3pGLFlBQUwsQ0FBa0J3RyxFQUFFLEdBQUcsQ0FBdkIsRUFBMEJDLEVBQUUsR0FBRyxDQUEvQixLQUFxQyxLQUFLMUcsVUFBOUMsRUFBMEQ7QUFDdEQwRixNQUFBQSxLQUFLLEdBQUcsS0FBS00sZ0JBQUwsQ0FBc0JTLEVBQXRCLEVBQTBCQyxFQUExQixFQUE4QnpCLEVBQTlCLEVBQWtDQyxFQUFsQyxFQUFzQzJCLFFBQXRDLENBQVI7O0FBQ0EsVUFBSW5CLEtBQUosRUFBVztBQUNQLGVBQU8sQ0FBQ2UsRUFBRCxFQUFLQyxFQUFMLEVBQVNNLE1BQVQsQ0FBZ0J0QixLQUFoQixDQUFQO0FBQThCO0FBQ2pDO0FBQ0o7O0FBQ0QsV0FBTyxJQUFQO0FBQ0gsR0FoZkk7O0FBa2ZMO0FBQ0o7QUFDQTtBQUNBO0FBQ0lPLEVBQUFBLGdCQUFnQixFQUFFLDBCQUFVbEIsRUFBVixFQUFjQyxFQUFkLEVBQWtCQyxFQUFsQixFQUFzQkMsRUFBdEIsRUFBMEI7QUFDeEMsUUFBSTRCLE1BQUo7QUFDQSxRQUFJTCxFQUFFLEdBQUcsQ0FBVDtBQUNBLFFBQUlDLEVBQUUsR0FBRyxDQUFUO0FBQ0EsUUFBSU8sS0FBSyxHQUFHLElBQVo7QUFDQSxRQUFJQyxPQUFPLEdBQUcsSUFBZDtBQUNBLFFBQUlDLE9BQU8sR0FBRyxJQUFkO0FBQ0EsUUFBSUMsUUFBUSxHQUFHLElBQWYsQ0FQd0MsQ0FTeEM7O0FBQ0EsU0FBSyxJQUFJL0YsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxLQUFLL0IsSUFBekIsRUFBK0IrQixDQUFDLEVBQWhDLEVBQW9DO0FBQ2hDO0FBQ0FvRixNQUFBQSxFQUFFLEdBQUcxQixFQUFMO0FBQ0EyQixNQUFBQSxFQUFFLEdBQUcxQixFQUFFLEdBQUczRCxDQUFWOztBQUNBLFVBQUk0RixLQUFLLElBQUlQLEVBQUUsSUFBSSxLQUFLbkgsT0FBeEIsRUFBaUM7QUFDN0IwSCxRQUFBQSxLQUFLLEdBQUcsS0FBS2hILFlBQUwsQ0FBa0J3RyxFQUFFLEdBQUcsQ0FBdkIsRUFBMEJDLEVBQUUsR0FBRyxDQUEvQixLQUFxQyxLQUFLMUcsVUFBbEQ7QUFDQThHLFFBQUFBLE1BQU0sR0FBRyxLQUFLQyxxQkFBTCxDQUEyQmhDLEVBQTNCLEVBQStCQyxFQUEvQixFQUFtQ0MsRUFBbkMsRUFBdUNDLEVBQXZDLEVBQTJDdUIsRUFBM0MsRUFBK0NDLEVBQS9DLEVBQW1ELEtBQW5ELENBQVQ7O0FBQ0EsWUFBSUksTUFBSixFQUFZO0FBQ1IsaUJBQU9BLE1BQVA7QUFDSDtBQUNKLE9BVitCLENBWWhDOzs7QUFDQUwsTUFBQUEsRUFBRSxHQUFHMUIsRUFBTDtBQUNBMkIsTUFBQUEsRUFBRSxHQUFHMUIsRUFBRSxHQUFHM0QsQ0FBVjs7QUFDQSxVQUFJNkYsT0FBTyxJQUFJUixFQUFFLElBQUksQ0FBQyxDQUF0QixFQUF5QjtBQUNyQlEsUUFBQUEsT0FBTyxHQUFHLEtBQUtqSCxZQUFMLENBQWtCd0csRUFBRSxHQUFHLENBQXZCLEVBQTBCQyxFQUFFLEdBQUcsQ0FBL0IsS0FBcUMsS0FBSzFHLFVBQXBEO0FBQ0E4RyxRQUFBQSxNQUFNLEdBQUcsS0FBS0MscUJBQUwsQ0FBMkJoQyxFQUEzQixFQUErQkMsRUFBL0IsRUFBbUNDLEVBQW5DLEVBQXVDQyxFQUF2QyxFQUEyQ3VCLEVBQTNDLEVBQStDQyxFQUEvQyxFQUFtRCxLQUFuRCxDQUFUOztBQUNBLFlBQUlJLE1BQUosRUFBWTtBQUNSLGlCQUFPQSxNQUFQO0FBQ0g7QUFDSixPQXJCK0IsQ0F1QmhDOzs7QUFDQUwsTUFBQUEsRUFBRSxHQUFHMUIsRUFBRSxHQUFHMUQsQ0FBVjtBQUNBcUYsTUFBQUEsRUFBRSxHQUFHMUIsRUFBTDs7QUFDQSxVQUFJbUMsT0FBTyxJQUFJVixFQUFFLElBQUksQ0FBQyxDQUF0QixFQUF5QjtBQUNyQlUsUUFBQUEsT0FBTyxHQUFHLEtBQUtsSCxZQUFMLENBQWtCd0csRUFBRSxHQUFHLENBQXZCLEVBQTBCQyxFQUFFLEdBQUcsQ0FBL0IsS0FBcUMsS0FBSzFHLFVBQXBEO0FBQ0E4RyxRQUFBQSxNQUFNLEdBQUcsS0FBS0MscUJBQUwsQ0FBMkJoQyxFQUEzQixFQUErQkMsRUFBL0IsRUFBbUNDLEVBQW5DLEVBQXVDQyxFQUF2QyxFQUEyQ3VCLEVBQTNDLEVBQStDQyxFQUEvQyxFQUFtRCxJQUFuRCxDQUFUOztBQUNBLFlBQUlJLE1BQUosRUFBWTtBQUNSLGlCQUFPQSxNQUFQO0FBQ0g7QUFDSixPQWhDK0IsQ0FrQ2hDOzs7QUFDQUwsTUFBQUEsRUFBRSxHQUFHMUIsRUFBRSxHQUFHMUQsQ0FBVjtBQUNBcUYsTUFBQUEsRUFBRSxHQUFHMUIsRUFBTDs7QUFDQSxVQUFJb0MsUUFBUSxJQUFJWCxFQUFFLElBQUksS0FBS25ILElBQTNCLEVBQWlDO0FBQzdCOEgsUUFBQUEsUUFBUSxHQUFHLEtBQUtuSCxZQUFMLENBQWtCd0csRUFBRSxHQUFHLENBQXZCLEVBQTBCQyxFQUFFLEdBQUcsQ0FBL0IsS0FBcUMsS0FBSzFHLFVBQXJEO0FBQ0E4RyxRQUFBQSxNQUFNLEdBQUcsS0FBS0MscUJBQUwsQ0FBMkJoQyxFQUEzQixFQUErQkMsRUFBL0IsRUFBbUNDLEVBQW5DLEVBQXVDQyxFQUF2QyxFQUEyQ3VCLEVBQTNDLEVBQStDQyxFQUEvQyxFQUFtRCxJQUFuRCxDQUFUOztBQUNBLFlBQUlJLE1BQUosRUFBWTtBQUNSLGlCQUFPQSxNQUFQO0FBQ0g7QUFDSjtBQUNKOztBQUNELFdBQU8sSUFBUDtBQUNILEdBOWlCSTtBQWtqQkw1RixFQUFBQSxXQWxqQksseUJBa2pCUztBQUNWLFNBQUtYLFFBQUwsR0FBZ0IsS0FBS2xDLE9BQUwsQ0FBYTBDLFlBQWIsQ0FBMEI5RCxFQUFFLENBQUNvSyxTQUE3QixDQUFoQjtBQUNBLFNBQUs5RyxRQUFMLENBQWMzQyxJQUFkLENBQW1CcUQsTUFBbkIsR0FBNEIsS0FBNUI7O0FBQ0EsU0FBS1YsUUFBTCxDQUFjK0csT0FBZCxHQUF3QixZQUFZO0FBQ2hDLFdBQUsvRyxRQUFMLENBQWMzQyxJQUFkLENBQW1CcUQsTUFBbkIsR0FBNEIsS0FBNUI7QUFDSCxLQUZ1QixDQUV0QnNHLElBRnNCLENBRWpCLElBRmlCLENBQXhCLENBSFUsQ0FRVjs7QUFDSCxHQTNqQkk7QUE2akJMQyxFQUFBQSxXQTdqQkssdUJBNmpCT0MsQ0E3akJQLEVBNmpCVWhELENBN2pCVixFQTZqQmE7QUFDZDtBQUNBLFNBQUtsRSxRQUFMLENBQWMzQyxJQUFkLENBQW1CcUQsTUFBbkIsR0FBNEIsS0FBNUI7QUFFQWhFLElBQUFBLEVBQUUsQ0FBQ3NGLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixNQUF0QjtBQUNILEdBbGtCSTs7QUFta0JMO0FBQ0o7QUFDQTtBQUNJa0YsRUFBQUEsUUF0a0JLLHNCQXNrQk07QUFFUCxTQUFLaEksS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLbUIsS0FBTCxHQUFhLENBQWI7QUFDQTVELElBQUFBLEVBQUUsQ0FBQ29GLFdBQUgsQ0FBZUMsZUFBZixHQUpPLENBTVA7O0FBRUEsUUFBSSxLQUFLakMsTUFBTCxHQUFjLEtBQUtmLElBQUwsR0FBWSxLQUFLQyxPQUFqQixHQUEyQixDQUE3QyxFQUFnRDtBQUM1Q3RDLE1BQUFBLEVBQUUsQ0FBQ29GLFdBQUgsQ0FBZVMsVUFBZixDQUEwQixLQUFLakUsV0FBL0IsRUFBNEMsS0FBNUM7QUFHQSxXQUFLUixPQUFMLENBQWF5QyxjQUFiLENBQTRCLEtBQTVCLEVBQW1DRyxNQUFuQyxHQUE0QyxLQUE1QztBQUNBLFdBQUs1QyxPQUFMLENBQWF5QyxjQUFiLENBQTRCLE1BQTVCLEVBQW9DRyxNQUFwQyxHQUE2QyxJQUE3QztBQUNBLFdBQUs1QyxPQUFMLENBQWF5QyxjQUFiLENBQTRCLE1BQTVCLEVBQW9DQyxZQUFwQyxDQUFpRDlELEVBQUUsQ0FBQ3FHLE1BQXBELEVBQTREQyxXQUE1RCxHQUEwRSxLQUFLOUYsVUFBL0U7QUFDSCxLQVBELE1BT087QUFDSFIsTUFBQUEsRUFBRSxDQUFDb0YsV0FBSCxDQUFlUyxVQUFmLENBQTBCLEtBQUtsRSxRQUEvQixFQUF5QyxLQUF6QztBQUVBLFdBQUtQLE9BQUwsQ0FBYXlDLGNBQWIsQ0FBNEIsS0FBNUIsRUFBbUNHLE1BQW5DLEdBQTRDLElBQTVDO0FBQ0EsV0FBSzVDLE9BQUwsQ0FBYXlDLGNBQWIsQ0FBNEIsTUFBNUIsRUFBb0NHLE1BQXBDLEdBQTZDLEtBQTdDO0FBQ0EsV0FBSzVDLE9BQUwsQ0FBYXlDLGNBQWIsQ0FBNEIsS0FBNUIsRUFBbUNDLFlBQW5DLENBQWdEOUQsRUFBRSxDQUFDcUcsTUFBbkQsRUFBMkRDLFdBQTNELEdBQXlFLEtBQUtoRyxTQUE5RTtBQUNIOztBQUVELFNBQUtnRCxRQUFMLENBQWMzQyxJQUFkLENBQW1CcUQsTUFBbkIsR0FBNEIsSUFBNUI7O0FBRUEsUUFBSTBHLEtBQUssR0FBRyxLQUFLcEgsUUFBTCxDQUFjcUgsSUFBZCxDQUFtQixXQUFuQixFQUFnQyxDQUFoQyxDQUFaOztBQUNBRCxJQUFBQSxLQUFLLENBQUNFLFdBQU4sR0FBb0IsQ0FBcEI7QUFDQSxTQUFLdEgsUUFBTCxDQUFjM0MsSUFBZCxDQUFtQmtLLE1BQW5CLEdBQTRCLElBQTVCO0FBRUEsU0FBS2hKLFdBQUwsQ0FBaUI2QixNQUFqQixHQUEwQixJQUExQjtBQUNILEdBcG1CSTs7QUFzbUJMO0FBQ0o7QUFDQTtBQUNJeUUsRUFBQUEsUUFBUSxFQUFFLG9CQUFZLENBQ2xCO0FBQ0gsR0EzbUJJO0FBK21CTDs7QUFDQTtBQUNKO0FBQ0E7QUFDSTJDLEVBQUFBLE1BQU0sRUFBRSxnQkFBVUMsRUFBVixFQUFjO0FBQ2xCLFNBQUtuSCxLQUFMLElBQWNtSCxFQUFkOztBQUNBLFFBQUksS0FBS3pILFFBQUwsQ0FBYzNDLElBQWQsQ0FBbUJxRCxNQUF2QixFQUErQjtBQUMzQixVQUFJLEtBQUtKLEtBQUwsR0FBYSxLQUFLbkIsS0FBdEIsRUFBNkI7QUFDekIsYUFBS2MsUUFBTDs7QUFFQSxZQUFJLEtBQUtBLFFBQUwsR0FBZ0IsQ0FBcEIsRUFBdUI7QUFDbkIsZUFBS2dILFdBQUw7QUFDQTtBQUNIOztBQUNELGFBQUs5SCxLQUFMLElBQWMsQ0FBZDtBQUNIOztBQUVELFdBQUtaLFdBQUwsQ0FBaUI2QixNQUFqQixHQUEwQixNQUFNLEtBQUtILFFBQXJDO0FBQ0E7QUFDSCxLQWZpQixDQWlCbEI7OztBQUNBLFFBQUksS0FBS0ssS0FBTCxHQUFhLEtBQUtuQixLQUF0QixFQUE2QjtBQUN6QixXQUFLN0IsT0FBTCxDQUFhOEMsTUFBYixHQUFzQixLQUFLbEIsUUFBTCxHQUFnQixLQUFLQyxLQUEzQzs7QUFDQSxVQUFJLEtBQUtBLEtBQUwsSUFBYyxLQUFLRCxRQUF2QixFQUFpQztBQUM3QixhQUFLaUksUUFBTDtBQUNIOztBQUNELFdBQUtoSSxLQUFMLElBQWMsQ0FBZDs7QUFFQSxXQUFLdUksV0FBTDtBQUNIO0FBRUosR0Evb0JJO0FBZ3BCTDtBQUNBQSxFQUFBQSxXQWpwQksseUJBaXBCUztBQUNWLFFBQU1qRyxFQUFFLEdBQUdrRyxNQUFNLENBQUMsS0FBS3JLLE9BQUwsQ0FBYThDLE1BQWQsQ0FBakI7O0FBQ0EsUUFBSXFCLEVBQUUsR0FBRyxDQUFMLElBQVVBLEVBQUUsR0FBRyxFQUFuQixFQUF1QjtBQUNuQjtBQUNBO0FBQ0EsVUFBSW1HLEdBQUcsR0FBRyxLQUFLdEssT0FBTCxDQUFhRCxJQUFiLENBQWtCbUQsWUFBbEIsQ0FBK0I5RCxFQUFFLENBQUNvSyxTQUFsQyxDQUFWO0FBQ0EsVUFBSU0sS0FBSyxHQUFHUSxHQUFHLENBQUNQLElBQUosRUFBWjtBQUNBRCxNQUFBQSxLQUFLLENBQUNFLFdBQU4sR0FBb0IsQ0FBcEI7QUFDSDtBQUNKLEdBMXBCSTtBQTRwQkxPLEVBQUFBLFVBNXBCSyx3QkE0cEJRLENBQ1Q7QUFDSCxHQTlwQkk7QUFncUJMQyxFQUFBQSxRQWhxQkssc0JBZ3FCTTtBQUNQLFFBQUlDLEVBQUUsR0FBRyxLQUFLOUosVUFBTCxDQUFnQnVDLFlBQWhCLENBQTZCLE9BQTdCLENBQVQ7QUFDQXVILElBQUFBLEVBQUUsQ0FBQ0MsTUFBSDtBQUNILEdBbnFCSTtBQXFxQkxDLEVBQUFBLFdBcnFCSyx5QkFxcUJRO0FBQ1QsV0FBTyxlQUFQO0FBQ0gsR0F2cUJJO0FBeXFCTDNHLEVBQUFBLGVBenFCSyw2QkF5cUJZO0FBQ2Y7QUFDQTtBQUVFLFFBQUk0RyxPQUFPLEdBQUcsS0FBS3JKLFlBQUwsQ0FBa0IwQixjQUFsQixDQUFpQyxRQUFqQyxFQUEyQ0MsWUFBM0MsQ0FBd0Q5RCxFQUFFLENBQUN5TCxVQUEzRCxFQUF1RUQsT0FBckY7QUFDQSxRQUFNRSxjQUFjLEdBQUcxTCxFQUFFLENBQUMyTCxHQUFILENBQU9DLFlBQVAsQ0FBb0JDLE9BQXBCLENBQTRCLEtBQUtOLFdBQUwsRUFBNUIsQ0FBdkI7O0FBR0EsUUFBRyxDQUFDRyxjQUFELElBQW1CQSxjQUFjLENBQUN0RixNQUFmLEdBQXdCLEVBQTlDLEVBQWlEO0FBQzdDLFdBQUs1QyxhQUFMLEdBQXFCLEtBQUtzSSxZQUFMLENBQWtCLEVBQWxCLENBQXJCO0FBRUgsS0FIRCxNQUdLO0FBQ0QsV0FBS3RJLGFBQUwsR0FBcUJ1SSxJQUFJLENBQUNDLEtBQUwsQ0FBV04sY0FBWCxDQUFyQjtBQUNIOztBQUVELFNBQUtsSSxhQUFMLENBQW1CeUksSUFBbkIsQ0FBd0IsVUFBQ0MsQ0FBRCxFQUFHQyxDQUFILEVBQU87QUFBQyxhQUFPQSxDQUFDLENBQUNDLEVBQUYsR0FBS0YsQ0FBQyxDQUFDRSxFQUFkO0FBQWtCLEtBQWxELEVBZmEsQ0FpQmI7OztBQUNBLFNBQUksSUFBSWhJLENBQUMsR0FBRSxDQUFYLEVBQWNBLENBQUMsR0FBRyxFQUFsQixFQUF1QkEsQ0FBQyxFQUF4QixFQUEyQjtBQUN2QixVQUFLaUksSUFBSSxHQUFHck0sRUFBRSxDQUFDaUcsV0FBSCxDQUFlLEtBQUsvRCxVQUFwQixDQUFaO0FBQ0FtSyxNQUFBQSxJQUFJLENBQUNuRyxLQUFMLEdBQWE5QixDQUFiO0FBQ0FpSSxNQUFBQSxJQUFJLENBQUNDLE1BQUwsR0FBY2QsT0FBZDtBQUNBLFVBQUllLEtBQUssR0FBR0YsSUFBSSxDQUFDdkksWUFBTCxDQUFrQixPQUFsQixDQUFaO0FBQ0EsV0FBS04sYUFBTCxDQUFtQlksQ0FBbkIsRUFBc0JvSSxFQUF0QixHQUEyQnBJLENBQUMsR0FBQyxDQUE3QjtBQUNBbUksTUFBQUEsS0FBSyxDQUFDRSxhQUFOLENBQXFCLEtBQUtqSixhQUFMLENBQW1CWSxDQUFuQixDQUFyQjtBQUNILEtBekJZLENBMkJiOzs7QUFFQXBFLElBQUFBLEVBQUUsQ0FBQzJMLEdBQUgsQ0FBT0MsWUFBUCxDQUFvQmMsT0FBcEIsQ0FBNEIsS0FBS25CLFdBQUwsRUFBNUIsRUFBZ0RRLElBQUksQ0FBQ1ksU0FBTCxDQUFpQixLQUFLbkosYUFBdEIsQ0FBaEQ7QUFDSCxHQXZzQkk7QUF5c0JMb0osRUFBQUEsWUF6c0JLLHdCQXlzQlFwQyxDQXpzQlIsRUF5c0JVaEQsQ0F6c0JWLEVBeXNCWTtBQUNiLFNBQUtyRixZQUFMLENBQWtCNkIsTUFBbEIsR0FBMkIsQ0FBQyxLQUFLN0IsWUFBTCxDQUFrQjZCLE1BQTlDO0FBQ0gsR0Ezc0JJO0FBOHNCTDhILEVBQUFBLFlBOXNCSyx3QkE4c0JRMUMsR0E5c0JSLEVBOHNCWTtBQUViLFFBQUl5RCxJQUFJLEdBQUcsRUFBWDs7QUFDQSxTQUFJLElBQUl6SSxDQUFDLEdBQUMsQ0FBVixFQUFhQSxDQUFDLEdBQUVnRixHQUFoQixFQUFxQmhGLENBQUMsRUFBdEIsRUFBeUI7QUFDckJ5SSxNQUFBQSxJQUFJLENBQUNDLElBQUwsQ0FBVTtBQUNOTixRQUFBQSxFQUFFLEVBQUNwSSxDQUFDLEdBQUMsQ0FEQztBQUVOMkksUUFBQUEsRUFBRSxFQUFFak4sTUFBTSxDQUFDNkQsT0FBUCxDQUFlLENBQWYsQ0FGRTtBQUdOeUksUUFBQUEsRUFBRSxFQUFFM0YsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQixJQUEzQjtBQUhFLE9BQVY7QUFLSCxLQVRZLENBVWI7OztBQUNFa0csSUFBQUEsSUFBSSxDQUFDWixJQUFMLENBQVUsVUFBQ0MsQ0FBRCxFQUFHQyxDQUFILEVBQU87QUFBQyxhQUFPQSxDQUFDLENBQUNDLEVBQUYsR0FBS0YsQ0FBQyxDQUFDRSxFQUFkO0FBQWtCLEtBQXBDO0FBQ0YsV0FBT1MsSUFBUDtBQUNILEdBM3RCSTtBQTh0QkxHLEVBQUFBLFlBOXRCSywwQkE4dEJTO0FBQ1YsUUFBT0MsSUFBSSxHQUFHO0FBQ1ZULE1BQUFBLEVBQUUsRUFBRSxDQURNO0FBRVZPLE1BQUFBLEVBQUUsRUFBRSxLQUFLM0ssUUFBTCxDQUFjc0IsTUFGUjtBQUdWMEksTUFBQUEsRUFBRSxFQUFFLEtBQUtoSjtBQUhDLEtBQWQsQ0FEVSxDQU1WOztBQUNBLFFBQU04SixJQUFJLEdBQUcsS0FBSzFKLGFBQUwsQ0FBbUIsS0FBS0EsYUFBTCxDQUFtQjRDLE1BQW5CLEdBQTBCLENBQTdDLENBQWIsQ0FQVSxDQVFWOztBQUNBLFFBQUc4RyxJQUFJLENBQUNkLEVBQUwsR0FBVWEsSUFBSSxDQUFDYixFQUFsQixFQUFxQjtBQUNqQjtBQUNIOztBQUVELFNBQUssSUFBSWhJLENBQUMsR0FBQyxDQUFYLEVBQWNBLENBQUMsR0FBRSxLQUFLWixhQUFMLENBQW1CNEMsTUFBcEMsRUFBNENoQyxDQUFDLEVBQTdDLEVBQWdEO0FBQzVDLFVBQUcsS0FBS1osYUFBTCxDQUFtQlksQ0FBbkIsRUFBc0IySSxFQUF0QixJQUE0QkUsSUFBSSxDQUFDRixFQUFqQyxJQUF1QyxLQUFLdkosYUFBTCxDQUFtQlksQ0FBbkIsRUFBc0JnSSxFQUF0QixHQUEyQmEsSUFBSSxDQUFDYixFQUExRSxFQUE2RTtBQUN6RSxhQUFLNUksYUFBTCxDQUFtQlksQ0FBbkIsSUFBd0I2SSxJQUF4QjtBQUNBO0FBQ0g7QUFDSjs7QUFDRCxTQUFLekosYUFBTCxDQUFtQnNKLElBQW5CLENBQXdCRyxJQUF4Qjs7QUFDQSxTQUFLekosYUFBTCxDQUFtQnlJLElBQW5CLENBQXdCLFVBQUNDLENBQUQsRUFBR0MsQ0FBSCxFQUFPO0FBQUMsYUFBT0EsQ0FBQyxDQUFDQyxFQUFGLEdBQUtGLENBQUMsQ0FBQ0UsRUFBZDtBQUFrQixLQUFsRDtBQUNILEdBbnZCSTtBQXF2Qkx4RSxFQUFBQSxXQXJ2QkssdUJBcXZCT3VGLFNBcnZCUCxFQXF2QmtCQyxRQXJ2QmxCLEVBcXZCNEI7QUFFN0IsU0FBS2hLLE1BQUwsSUFBZSxDQUFmO0FBQ0EsU0FBSzlCLFNBQUwsQ0FBZW9DLE1BQWYsR0FBd0IsS0FBS04sTUFBN0I7O0FBRUEsU0FBS2dJLFFBQUwsR0FMNkIsQ0FPN0I7QUFDQTs7O0FBQ0EsUUFBSSxLQUFLaEksTUFBTCxJQUFlLEtBQUtmLElBQUwsR0FBWSxLQUFLQyxPQUFwQyxFQUE2QztBQUN6QyxXQUFLZSxXQUFMLEdBRHlDLENBRXpDOztBQUNBLFdBQUtvSCxRQUFMO0FBQ0g7O0FBQ0QsU0FBS3VDLFlBQUw7QUFDSDtBQXB3QkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiDov57ov57nnIvkuLvohJrmnKzmlofku7ZcbiAqIFxuICogYnkg5oWV5a6556eLIG11cm9xaXVAcXEuY29tXG4gKiAyMDE4LTAyLTI1XG4gKiBcbiAqIOS4u+imgeeahOmAu+i+ke+8mlxuICogQeOAgea0l+eJjCBzaHVmZmxl77ya6YGN5Y6G5Zu+54mH5pWw57uE77yM5Y+WMeS4qumaj+acuuS9jee9rueahOWbvueJh+WSjOW9k+WJjeS9jee9ruS6pOaNou+8m1xuICogQuOAgeeUqOS4gOS4quS6jOe7tOaVsOe7hO+8iOWQhOS4quaWueWQkeWdh+avlOWbvueJh+aVsOe7hOWkpzHvvInkv53lrZjlm77niYfnmoTnirbmgIHlgLzvvIzmkJzntKLot6/lvoTml7bmmKDlsITliLDov5nkuKrmlbDnu4TmkJzntKLvvJtcbiAqIEPjgIHmkJzntKLpobrluo/vvJpcbiAqICAgIDHjgIHlkIzkuIDmnaHnm7Tnur/vvJrliKTmlq3nm7Tnur/pl7TmnInml6Dlm77niYfvvJtcbiAqICAgIDLjgIHmnInkuIDkuKrmi5Dop5LvvJrlhYjlrprkvY3lh7rkuKTkuKrmi5Dop5LngrnvvIzoi6Xmi5Dop5LngrnmsqHmnInlm77niYfvvIzlho3ovazmjaLmiJDkuIDmnaHnm7Tnur/nmoTmg4XlhrXnu6fnu63lpITnkIbvvJtcbiAqICAgIDPjgIHkuKTkuKrmi5Dop5LvvJrmn5DkuKrmlrnlkJHnp7vliqjvvIzoi6XliLDovr7ngrnmsqHmnInlm77niYfvvIzlho3ovazmjaLmiJDkuIDkuKrmi5Dop5LnmoTmg4XlhrXnu6fnu63lpITnkIbvvJvoi6XliLDovr7ngrnmnInlm77niYfvvIzmraTmlrnlkJHkuI3lho3nu6fnu63mkJzntKLvvJtcbiAqL1xuLy8gaW1wb3J0IHsgcm5kTmFtZSB9IGZyb20gXCIuL3V0b29sc1wiO1xudmFyIHV0b29scyA9IHJlcXVpcmUoXCIuL3V0b29sc1wiKTtcbi8vIGltcG9ydCB7c2hha2V9IGZyb20gJy4vc2hhZ2UnO1xuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgaXRlbVByZWZhYjogY2MuUHJlZmFiLFxuICAgICAgICBzcHJpdGVXaW46IGNjLlNwcml0ZUZyYW1lLFxuXG4gICAgICAgIHNwcml0ZUxvc2U6IGNjLlNwcml0ZUZyYW1lLFxuXG5cbiAgICAgICAgc3ByaXRlZnJhbWVMaXN0OiBbY2MuU3ByaXRlRnJhbWVdLFxuXG4gICAgICAgIGltYWdlTGlzdDogW2NjLm5vZGVdLFxuXG4gICAgICAgIHRpbWVvdXQ6IGNjLkxhYmVsLFxuICAgICAgICBCdG5BdWRpbzogY2MuQXVkaW9DbGlwLFxuXG4gICAgICAgIEVycm9yQXVkaW86IGNjLkF1ZGlvQ2xpcCxcblxuICAgICAgICBTdWNjZXNzQXVkaW86IGNjLkF1ZGlvQ2xpcCxcbiAgICAgICAgQ29udGludWVBdWRpbzogY2MuQXVkaW9DbGlwLFxuXG5cbiAgICAgICAgYmdNdXNpY0F1ZGlvOiBjYy5BdWRpb0NsaXAsXG5cbiAgICAgICAgZW5kTm9kZTogY2MuTm9kZSxcbiAgICAgICAgZ2FtZVNjb3JlOiBjYy5MYWJlbCxcbiAgICAgICAgY2FtZXJhTm9kZTogY2MuTm9kZSxcbiAgICAgICAgYnRuUHJlTm9kZTogY2MuQnV0dG9uLFxuXG4gICAgICAgIHRpcHNOb2RlOiBjYy5MYWJlbCxcblxuICAgICAgICB3aW5BdWRpbzogY2MuQXVkaW9DbGlwLFxuXG4gICAgICAgIGZhaWxlZEF1ZGlvOiBjYy5BdWRpb0NsaXAsXG5cbiAgICAgICAgZ2FtZU92ZXJMYWI6IGNjLkxhYmVsLFxuXG4gICAgICAgIF9ncmFwaGljczogY2MuR3JhcGhpY3MsXG5cbiAgICAgICAgbm90aWNlTm9kZTogY2MuTm9kZSxcblxuICAgICAgICByYW5kQnRuOiBjYy5CdXR0b24sXG4gICAgICAgIHJhbmtQcmVmYWI6Y2MuUHJlZmFiLFxuICAgICAgICByYW5rTGlzdE5vZGU6Y2MuTm9kZSxcblxuICAgICAgICBuaWNrTmFtZTogY2MuTGFiZWwsXG5cbiAgICAgICAgLy8g6KGM5pWwXG4gICAgICAgIHJvd3M6IDQsXG4gICAgICAgIC8vIOWIl+aVsFxuICAgICAgICBjb2x1bW5zOiA0LFxuICAgICAgICAvLyDmgLvnmoTlm77niYflr7nmlbAgPSBsaW5lcypyb3dzLzLvvIzlvZPkuLow5pe277yM6KGo56S65bey57uP5YWo6YOo5raI6ZmkIFxuICAgICAgICBwYWlyczogOCxcbiAgICAgICAgLy8g5YCS6K6h5pe2XG4gICAgICAgIGR1cmF0aW9uOiAyMCxcbiAgICAgICAgY291bnQ6IDEsXG4gICAgICAgIHNwcml0ZVdpZHRoOiA4MCxcbiAgICAgICAgc3ByaXRlSGVpZ2h0OiA4MCxcbiAgICAgICAgcGFkZGluZ0xlZnQ6IDIwMCxcbiAgICAgICAgcGFkZGluZ1RvcDogNTAwLFxuICAgICAgICAvLyDlm77niYfnirbmgIHvvJog5raI6ZmkXG4gICAgICAgIF9UWVBFX0RFTEVEOiAtMixcbiAgICAgICAgLy8g5Zu+54mH54q25oCB77yaIOWIneWni+WMllxuICAgICAgICBfVFlQRV9JTklUOiAtMSxcbiAgICAgICAgLy8g5LqM57u05pWw57uE77yM5q+U5Zu+54mH5pWw57uE5aSn5LiA5ZyI77yM6K6w5b2V5Zu+54mH54q25oCB5YC8XG4gICAgICAgIF9jYW52YXNHcmlkczogbnVsbCxcbiAgICAgICAgX2xhc3RDbGlja1g6IC0xLFxuICAgICAgICBfbGFzdENsaWNrWTogLTEsXG5cbiAgICAgICAgLy/og4zmma/pn7PmlYhcbiAgICAgICAgX2lzUGF1c2VNdXNpYzogdHJ1ZSxcbiAgICAgICAgLy9zY29yZVxuICAgICAgICBfc2NvcmU6IDAsXG4gICAgICAgIF90b3RhbFNjb3JlOiAwLFxuICAgICAgICAvL+WKqOeUu1xuICAgICAgICBfYW5pU2hvdzogbnVsbCxcbiAgICAgICAgLy/nu5PmnZ/ml7ZVSeWAkuiuoeaXtlxuICAgICAgICBfb3ZlclRNUzogNSxcbiAgICAgICAgLy/mjpLooYzmppxcbiAgICAgICAgX3JhbmtMaXN0RGF0YTpbXVxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICAvKipcbiAgICAgKiDns7vnu5/liqDovb3kuovku7ZcbiAgICAgKi9cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5uaWNrTmFtZS5zdHJpbmcgPSB1dG9vbHMucm5kTmFtZSgzKVxuICAgICAgICB0aGlzLnRpbWVyID0gMDtcbiAgICAgICAgdGhpcy5fZ3JhcGhpY3MgPSB0aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJncmFwaGljc1wiKS5nZXRDb21wb25lbnQoY2MuR3JhcGhpY3MpO1xuICAgICAgICB0aGlzLl9ncmFwaGljcy5saW5lV2lkdGggPSA1O1xuXG4gICAgICAgIHRoaXMucmFua0xpc3ROb2RlLmFjdGl2ZSA9IGZhbHNlO1xuXG4gICAgICAgIHRoaXMuX2luaXRBbmltYWwoKTtcbiAgICAgICAgdGhpcy5fc2V0VGlwc0xhYk5vZGUoZmFsc2UpXG5cbiAgICAgICAgdGhpcy5fY2FudmFzR3JpZHMgPSBuZXcgQXJyYXkoKTtcbiAgICAgICAgLy/lnKjlo7DmmI7kuoznu7RcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLnJvd3MgKyAyOyBpKyspIHtcbiAgICAgICAgICAgIHRoaXMuX2NhbnZhc0dyaWRzW2ldID0gbmV3IEFycmF5KGkpO1xuICAgICAgICAgICAgZm9yICh2YXIgaiA9IDA7IGogPCB0aGlzLmNvbHVtbnMgKyAyOyBqKyspIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9jYW52YXNHcmlkc1tpXVtqXSA9IC0xO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5pbWFnZUxpc3QgPSBuZXcgQXJyYXkoKTtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLnJvd3M7IGkrKykge1xuICAgICAgICAgICAgdGhpcy5pbWFnZUxpc3RbaV0gPSBuZXcgQXJyYXkoaSk7XG4gICAgICAgICAgICBmb3IgKHZhciBqID0gMDsgaiA8IHRoaXMuY29sdW1uczsgaisrKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pbWFnZUxpc3RbaV1bal0gPSBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLS0tLS0tLS0tLWRkZC0tLS0tLS0tLVwiKVxuXG4gICAgICAgIHRoaXMuaW5pdERhdGEoKTtcbiAgICAgICAgdGhpcy5pbml0TWFwKCk7XG4gICAgICAgIHRoaXMuX3Jlc2V0R2FtZSgpO1xuICAgICAgICB0aGlzLl9zZXRQYXVzZUJnTXVzaWMoKTtcblxuICAgICAgICB0aGlzLmdhbWVTY29yZS5zdHJpbmcgPSB0aGlzLl9zY29yZVxuICAgICAgICB0aGlzLmdhbWVPdmVyTGFiLnN0cmluZyA9IFwiLTVcIjtcblxuICAgICAgICB0aGlzLl9kb25lTXVzaWMoZmFsc2UpIFxuXG4gICAgICBcbiAgICAgICAgdGhpcy5faW5pdE5vdGljZU5vZGUoKTtcbiAgICAgICAgdGhpcy5faW5pdFNjcm9sbFZpZXcoKTtcbiAgICB9LFxuICAgIF9pbml0Tm90aWNlTm9kZSgpIHtcbiAgICAgICBcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIGlmKCFzZWxmLm5vdGljZU5vZGUpIHtcbiAgICAgICAgICAgICAgICBsZXQgdHQgPSBzZWxmLm5vdGljZU5vZGUuZ2V0Q29tcG9uZW50KFwibm90aWNlXCIpXG4gICAgICAgICAgICAgICAgLy8gPGNvbG9yPSMwMEZGMDA+546p5a62PC9jPiA8Y29sb3I9IzdGRkYwMD7ljonlrrM8L2M+5Y6J5a6zPGNvbG9yPSNGRkZGMDA+b288L2M+XG4gICAgICAgICAgICAgICAgdHQuYWRkU3RyVG9MaXN0KFwiPGNvbG9yPSMwRkZGNTA+5qyi6L+O5L2T6aqM6Zeq55S16L+e6L+e55yLLOWmguS9oOacieS7u+S9lemXrumimOivt+eCueWHu+WktOWDj+WRiuivieaIkeWTnyE8L2M+XCIpO1xuICAgICAgICAgICAgICAgIHNlbGYuX2luaXROb3RpY2VOb2RlKClcbiAgICAgICAgICAgIH1cbiAgICAgXG4gICAgICAgIH0sIDMwMDApO1xuXG4gICAgfSxcblxuICAgIF9zZXRUaXBzTGFiTm9kZShmbGFnKSB7XG4gICAgICAgIHRoaXMudGlwc05vZGUubm9kZS5hY3RpdmUgPSBmbGFnO1xuICAgICAgICB0aGlzLnRpbWVvdXQubm9kZS5jb2xvciA9IG5ldyBjYy5jb2xvcigyNTUsIDI1NSwgMjU1KTtcbiAgICB9LFxuXG4gICAgYnRuRXZlbnQyUHJlKCkge1xuICAgICAgICBjYy5hdWRpb0VuZ2luZS5wYXVzZUFsbEVmZmVjdHMoKTtcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwibG9hZFwiKTtcbiAgICB9LFxuXG4gICAgX2RvbmVNdXNpYyhzaWduKSB7XG4gICAgICAgIGlmIChzaWduKVxuICAgICAgICAgICAgdGhpcy5faXNQYXVzZU11c2ljID0gIXRoaXMuX2lzUGF1c2VNdXNpYztcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLS0tLS0tLS0tLS0tLS0tLS1cIix0aGlzLl9pc1BhdXNlTXVzaWMpXG5cbiAgICAgICAgaWYgKHRoaXMuX2lzUGF1c2VNdXNpYykge1xuICAgICAgICAgICAgLy8gY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLmJnTXVzaWNBdWRpbywgdHJ1ZSwxKTtcblxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGF1c2VBbGxFZmZlY3RzKCk7XG4gICAgICAgIH1cblxuICAgIH0sXG5cbiAgICBfc2V0UGF1c2VCZ011c2ljKCkge1xuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XG4gICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcInBhdXNlXCIpLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgKGV2ZW50KSA9PiB7XG5cbiAgICAgICAgICAgIHNlbGYuX2RvbmVNdXNpYyh0cnVlKTtcbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICBfcmVzZXRHYW1lKCkge1xuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XG4gICAgICAgIHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcInJlZnJlc2hcIikub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3Qoc2VsZi5Db250aW51ZUF1ZGlvLCBmYWxzZSk7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ2dhbWUnKTtcbiAgICAgICAgfSk7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiDliJ3lp4vljJbmlbDmja5cbiAgICAgKi9cbiAgICBpbml0RGF0YTogZnVuY3Rpb24gKCkge1xuICAgICAgICBmb3IgKHZhciByb3cgPSAwOyByb3cgPCB0aGlzLnJvd3M7IHJvdysrKSB7XG4gICAgICAgICAgICBmb3IgKHZhciBjb2x1bW4gPSAwOyBjb2x1bW4gPCB0aGlzLmNvbHVtbnM7IGNvbHVtbisrKSB7XG4gICAgICAgICAgICAgICAgdmFyIG5ld05vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLml0ZW1QcmVmYWIpOyAgICAgICAgICAgICAgLy/lpI3liLbpooTliLbotYTmupBcbiAgICAgICAgICAgICAgICB2YXIgaW5kZXggPSByb3cgKiB0aGlzLnJvd3MgKyBjb2x1bW47XG4gICAgICAgICAgICAgICAgdmFyIHR5cGUgPSBpbmRleCAlIHRoaXMuc3ByaXRlZnJhbWVMaXN0Lmxlbmd0aDtcblxuICAgICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0tLS0tPj4tLS1cIiwgbmV3Tm9kZS5nZXRDaGlsZEJ5TmFtZShcIkJhY2tncm91bmRcIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkpXG4gICAgICAgICAgICAgICAgbmV3Tm9kZS5nZXRDaGlsZEJ5TmFtZShcIkJhY2tncm91bmRcIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUgPSB0aGlzLnNwcml0ZWZyYW1lTGlzdFt0eXBlXTtcbiAgICAgICAgICAgICAgICBuZXdOb2RlLmlzZW1wdHkgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBuZXdOb2RlLnR5cGUgPSB0eXBlO1xuICAgICAgICAgICAgICAgIG5ld05vZGUuaW5kZXggPSBpbmRleDtcbiAgICAgICAgICAgICAgICBuZXdOb2RlLnNjb3JlID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTApXG5cbiAgICAgICAgICAgICAgICB0aGlzLmltYWdlTGlzdFtyb3ddW2NvbHVtbl0gPSBuZXdOb2RlO1xuICAgICAgICAgICAgICAgIC8vIHR5cGUgPj0gMO+8jOS4uuWunumZheeahOWbvueJh+exu+Wei+WAvFxuICAgICAgICAgICAgICAgIHRoaXMuX2NhbnZhc0dyaWRzW3JvdyArIDFdW2NvbHVtbiArIDFdID0gdHlwZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNodWZmbGUoKTtcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICog5rSX54mMXG4gICAgICovXG5cbiAgICBzaHVmZmxlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGZvciAodmFyIGkgPSB0aGlzLnJvd3MgKiB0aGlzLmNvbHVtbnMgLSAxOyBpID4gMDsgaS0tKSB7XG4gICAgICAgICAgICB2YXIgaiA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIChpICsgMSkpO1xuICAgICAgICAgICAgdmFyIHggPSBpICUgdGhpcy5yb3dzO1xuICAgICAgICAgICAgdmFyIHkgPSBNYXRoLmZsb29yKGkgLyB0aGlzLnJvd3MpO1xuICAgICAgICAgICAgdmFyIHhfdG1wID0gaiAlIHRoaXMucm93cztcbiAgICAgICAgICAgIHZhciB5X3RtcCA9IE1hdGguZmxvb3IoaiAvIHRoaXMucm93cyk7XG4gICAgICAgICAgICB2YXIgdGVtcCA9IHRoaXMuaW1hZ2VMaXN0W3hdW3ldO1xuICAgICAgICAgICAgdGhpcy5pbWFnZUxpc3RbeF1beV0gPSB0aGlzLmltYWdlTGlzdFt4X3RtcF1beV90bXBdO1xuICAgICAgICAgICAgdGhpcy5pbWFnZUxpc3RbeF90bXBdW3lfdG1wXSA9IHRlbXA7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICog5Yid5aeL5YyWXG4gICAgICovXG4gICAgaW5pdE1hcDogZnVuY3Rpb24gKCkge1xuICAgICAgICBmb3IgKHZhciByb3cgPSAwOyByb3cgPCB0aGlzLnJvd3M7IHJvdysrKSB7XG4gICAgICAgICAgICBmb3IgKHZhciBjb2x1bW4gPSAwOyBjb2x1bW4gPCB0aGlzLmNvbHVtbnM7IGNvbHVtbisrKSB7XG4gICAgICAgICAgICAgICAgdmFyIG5ld05vZGUgPSB0aGlzLmltYWdlTGlzdFtyb3ddW2NvbHVtbl07XG4gICAgICAgICAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKG5ld05vZGUpO1xuXG4gICAgICAgICAgICAgICAgbmV3Tm9kZS5zZXRQb3NpdGlvbihjYy5WZWMyKHRoaXMuc3ByaXRlV2lkdGggKiByb3cgLSB0aGlzLnBhZGRpbmdMZWZ0LCB0aGlzLnNwcml0ZUhlaWdodCAqIGNvbHVtbiAtIHRoaXMucGFkZGluZ1RvcCkpO1xuXG4gICAgICAgICAgICAgICAgbmV3Tm9kZS5wb2ludFggPSByb3c7XG4gICAgICAgICAgICAgICAgbmV3Tm9kZS5wb2ludFkgPSBjb2x1bW47XG5cbiAgICAgICAgICAgICAgICBuZXdOb2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCwgdGhpcy5fY2xpY2tOb2RlLCB0aGlzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgfSxcblxuICAgIF9jbGlja05vZGUoZCkge1xuXG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QodGhpcy5CdG5BdWRpbywgZmFsc2UpO1xuXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0tLS1fY2xpY2tOb2RlLS0tLS0tLS0tXCIsbm9kZS5jdXJyZW50VGFyZ2V0LmdldENvbXBvbmVudChcInBpY1wiKSApXG4gICAgICAgIGxldCBzZWxmID0gdGhpcztcbiAgICAgICAgLy8gbGV0ICBub2RlID0gZC5jdXJyZW50VGFyZ2V0LmdldENvbXBvbmVudChcInBpY1wiKTtcbiAgICAgICAgbGV0IG5vZGUgPSBkLmN1cnJlbnRUYXJnZXRcblxuICAgICAgICBsZXQgbGFzdE5vZGUgPSBudWxsO1xuICAgICAgICBpZiAoc2VsZi5fbGFzdENsaWNrWCAhPSAtMSAmJiBzZWxmLl9sYXN0Q2xpY2tZICE9IC0xKSB7XG5cbiAgICAgICAgICAgIGxhc3ROb2RlID0gc2VsZi5pbWFnZUxpc3Rbc2VsZi5fbGFzdENsaWNrWF1bc2VsZi5fbGFzdENsaWNrWV1cblxuICAgICAgICB9XG5cblxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tLS0tMy0tLS0tLS0tXCIsbGFzdE5vZGUpXG5cbiAgICAgICAgLy8g5a2Y5YKo56ys5LiA5qyh54K55Ye75a+56LGhSURcbiAgICAgICAgaWYgKHNlbGYuX2xhc3RDbGlja1ggPT0gLTEgfHwgc2VsZi5fbGFzdENsaWNrWCA9PSAtMSkge1xuICAgICAgICAgICAgLy8gICBjb25zb2xlLmxvZyhcIi0tLS0tMi0tLS0tLS0tXCIpXG5cbiAgICAgICAgICAgIHNlbGYuX2xhc3RDbGlja1ggPSBub2RlLnBvaW50WDtcbiAgICAgICAgICAgIHNlbGYuX2xhc3RDbGlja1kgPSBub2RlLnBvaW50WTtcbiAgICAgICAgfSBlbHNlIGlmIChzZWxmLl9sYXN0Q2xpY2tYID09IG5vZGUucG9pbnRYICYmIHNlbGYuX2xhc3RDbGlja1kgPT0gbm9kZS5wb2ludFkpIHtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0tMy0t5LiN5YGa5Lu75L2V5aSE55CGLS0tLS0tLS1cIilcblxuICAgICAgICB9IGVsc2UgaWYgKGxhc3ROb2RlLnR5cGUgPT0gbm9kZS50eXBlKSB7ICAgICAvL+WmguaenOebuOWQjOWbvueJh1xuICAgICAgICAgICAgaWYgKHNlbGYuaXNMaW5rZWQoc2VsZi5fbGFzdENsaWNrWCwgc2VsZi5fbGFzdENsaWNrWSwgbm9kZS5wb2ludFgsIG5vZGUucG9pbnRZKSkgeyAgICAvL+W5tuS4lOWPr+i/numAmlxuICAgICAgICAgICAgICAgIHNlbGYuX3NldFVJU2NvcmUobGFzdE5vZGUuc2NvcmUsIG5vZGUuc2NvcmUpXG4gICAgICAgICAgICAgICAgLy8gbm9kZS5zY2hlZHVsZU9uY2UoICAoKT0+e1xuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyDov5nph4znmoQgdGhpcyDmjIflkJEgY29tcG9uZW50XG4gICAgICAgICAgICAgICAgICAgIHNlbGYuY2xlYXJMaW5rZWQoc2VsZi5fbGFzdENsaWNrWCwgc2VsZi5fbGFzdENsaWNrWSwgbm9kZS5wb2ludFgsIG5vZGUucG9pbnRZKTtcblxuICAgICAgICAgICAgICAgICAgICBzZWxmLl9sYXN0Q2xpY2tYID0gLTE7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYuX2xhc3RDbGlja1kgPSAtMTtcbiAgICAgICAgICAgICAgICB9LCAxMDApO1xuXG4gICAgICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICAgICAgc2VsZi5fbGFzdENsaWNrWCA9IG5vZGUucG9pbnRYO1xuICAgICAgICAgICAgICAgIHNlbGYuX2xhc3RDbGlja1kgPSBub2RlLnBvaW50WTtcbiAgICAgICAgICAgICAgICAvLyBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHNlbGYuRXJyb3JBdWRpbywgZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuXG4gICAgICAgICAgICBzZWxmLl9sYXN0Q2xpY2tYID0gbm9kZS5wb2ludFg7XG4gICAgICAgICAgICBzZWxmLl9sYXN0Q2xpY2tZID0gbm9kZS5wb2ludFk7XG5cbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDmtojpmaTlt7Lov57mjqVcbiAgICAgKiBuZXdOb2RlLmdldENoaWxkQnlOYW1lKFwiQmFja2dyb3VuZFwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZVxuICAgICAqL1xuICAgIGNsZWFyTGlua2VkOiBmdW5jdGlvbiAoeDEsIHkxLCB4MiwgeTIpIHtcblxuICAgICAgICB0aGlzLmltYWdlTGlzdFt4MV1beTFdLmdldENoaWxkQnlOYW1lKFwiQmFja2dyb3VuZFwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IG51bGw7XG5cbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLS0tMi0tLS0tLS0+Pj4tLS1cIix0aGlzLmltYWdlTGlzdFt4Ml1beTJdIClcbiAgICAgICAgdGhpcy5pbWFnZUxpc3RbeDJdW3kyXS5nZXRDaGlsZEJ5TmFtZShcIkJhY2tncm91bmRcIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUgPSBudWxsO1xuXG4gICAgICAgIHRoaXMuX2NhbnZhc0dyaWRzW3gxICsgMV1beTEgKyAxXSA9IHRoaXMuX1RZUEVfREVMRUQ7XG4gICAgICAgIHRoaXMuX2NhbnZhc0dyaWRzW3gyICsgMV1beTIgKyAxXSA9IHRoaXMuX1RZUEVfREVMRUQ7XG5cbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLlN1Y2Nlc3NBdWRpbywgZmFsc2UpO1xuXG4gICAgICAgIHRoaXMuX2dyYXBoaWNzLmNsZWFyKCk7XG4gICAgICAgIHRoaXMucGFpcnMgLT0gMTtcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLS0tMy0tLS0tLS0+Pj4tLS1cIilcblxuICAgICAgICBpZiAodGhpcy5wYWlycyA9PSAwKVxuICAgICAgICAgICAgdGhpcy5nYW1lUGFzcygpO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDmoLnmja7nn6npmLVYWeiOt+WPlue7neWvueWdkOagh1xuICAgICAqL1xuICAgIGdldEFic1hZOiBmdW5jdGlvbiAoeCwgeSkge1xuICAgICAgICB2YXIgYWJzWCA9IDA7XG4gICAgICAgIHZhciBhYnNZID0gMDtcbiAgICAgICAgaWYgKHggPCAwKSB7XG4gICAgICAgICAgICBhYnNYID0gdGhpcy5ub2RlLnggKyB0aGlzLmltYWdlTGlzdFswXVswXS54IC0gdGhpcy5pbWFnZUxpc3RbMF1bMF0ud2lkdGg7XG4gICAgICAgIH0gZWxzZSBpZiAoeCA+PSB0aGlzLnJvd3MpIHtcbiAgICAgICAgICAgIGFic1ggPSB0aGlzLm5vZGUueCArIHRoaXMuaW1hZ2VMaXN0W3RoaXMucm93cyAtIDFdWzBdLnggKyB0aGlzLmltYWdlTGlzdFswXVswXS53aWR0aDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGFic1ggPSB0aGlzLm5vZGUueCArIHRoaXMuaW1hZ2VMaXN0W3hdWzBdLng7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHkgPCAwKSB7XG4gICAgICAgICAgICBhYnNZID0gdGhpcy5ub2RlLnkgKyB0aGlzLmltYWdlTGlzdFswXVswXS55IC0gdGhpcy5pbWFnZUxpc3RbMF1bMF0uaGVpZ2h0O1xuICAgICAgICB9IGVsc2UgaWYgKHkgPj0gdGhpcy5jb2x1bW5zKSB7XG4gICAgICAgICAgICBhYnNZID0gdGhpcy5ub2RlLnkgKyB0aGlzLmltYWdlTGlzdFswXVt0aGlzLmNvbHVtbnMgLSAxXS55ICsgdGhpcy5pbWFnZUxpc3RbMF1bMF0uaGVpZ2h0O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgYWJzWSA9IHRoaXMubm9kZS55ICsgdGhpcy5pbWFnZUxpc3RbMF1beV0ueTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBbYWJzWCwgYWJzWV07XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIOaYr+WQpui/numAmlxuICAgICAqL1xuICAgIGlzTGlua2VkOiBmdW5jdGlvbiAoeDEsIHkxLCB4MiwgeTIpIHtcbiAgICAgICAgdmFyIHRtcFhZID0gW107XG4gICAgICAgIHZhciB0bXBBYnNYWSA9IFtdO1xuXG4gICAgICAgIGlmICh0aGlzLm1hdGNoQmxvY2tMaW5lKHgxLCB5MSwgeDIsIHkyKSkge1xuICAgICAgICAgICAgLy8g55u057q/XG4gICAgICAgICAgICB0bXBBYnNYWSA9IHRoaXMuZ2V0QWJzWFkoeDEsIHkxKTtcbiAgICAgICAgICAgIHRoaXMuX2dyYXBoaWNzLm1vdmVUbyh0bXBBYnNYWVswXSwgdG1wQWJzWFlbMV0pO1xuICAgICAgICAgICAgdG1wQWJzWFkgPSB0aGlzLmdldEFic1hZKHgyLCB5Mik7XG4gICAgICAgICAgICB0aGlzLl9ncmFwaGljcy5saW5lVG8odG1wQWJzWFlbMF0sIHRtcEFic1hZWzFdKTtcbiAgICAgICAgICAgIHRoaXMuX2dyYXBoaWNzLnN0cm9rZSgpO1xuXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRtcFhZID0gdGhpcy5tYXRjaEJsb2NrQ29ybmVyKHgxLCB5MSwgeDIsIHkyLCBudWxsKVxuICAgICAgICAgICAgaWYgKHRtcFhZKSB7XG4gICAgICAgICAgICAgICAgLy8g5LiA5Liq6L2s6KeSXG4gICAgICAgICAgICAgICAgdG1wQWJzWFkgPSB0aGlzLmdldEFic1hZKHgxLCB5MSk7XG4gICAgICAgICAgICAgICAgdGhpcy5fZ3JhcGhpY3MubW92ZVRvKHRtcEFic1hZWzBdLCB0bXBBYnNYWVsxXSk7XG4gICAgICAgICAgICAgICAgdG1wQWJzWFkgPSB0aGlzLmdldEFic1hZKHRtcFhZWzBdLCB0bXBYWVsxXSk7XG4gICAgICAgICAgICAgICAgdGhpcy5fZ3JhcGhpY3MubGluZVRvKHRtcEFic1hZWzBdLCB0bXBBYnNYWVsxXSk7XG4gICAgICAgICAgICAgICAgdG1wQWJzWFkgPSB0aGlzLmdldEFic1hZKHgyLCB5Mik7XG4gICAgICAgICAgICAgICAgdGhpcy5fZ3JhcGhpY3MubGluZVRvKHRtcEFic1hZWzBdLCB0bXBBYnNYWVsxXSk7XG4gICAgICAgICAgICAgICAgdGhpcy5fZ3JhcGhpY3Muc3Ryb2tlKCk7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRtcFhZID0gdGhpcy5tYXRjaEJsb2NrVW5mb2xkKHgxLCB5MSwgeDIsIHkyKVxuICAgICAgICAgICAgICAgIGlmICh0bXBYWSkge1xuICAgICAgICAgICAgICAgICAgICAvLyDkuKTkuKrovazop5JcbiAgICAgICAgICAgICAgICAgICAgdG1wQWJzWFkgPSB0aGlzLmdldEFic1hZKHgxLCB5MSk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2dyYXBoaWNzLm1vdmVUbyh0bXBBYnNYWVswXSwgdG1wQWJzWFlbMV0pO1xuICAgICAgICAgICAgICAgICAgICB0bXBBYnNYWSA9IHRoaXMuZ2V0QWJzWFkodG1wWFlbMF0sIHRtcFhZWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5fZ3JhcGhpY3MubGluZVRvKHRtcEFic1hZWzBdLCB0bXBBYnNYWVsxXSk7XG4gICAgICAgICAgICAgICAgICAgIHRtcEFic1hZID0gdGhpcy5nZXRBYnNYWSh0bXBYWVsyXSwgdG1wWFlbM10pO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9ncmFwaGljcy5saW5lVG8odG1wQWJzWFlbMF0sIHRtcEFic1hZWzFdKTtcbiAgICAgICAgICAgICAgICAgICAgdG1wQWJzWFkgPSB0aGlzLmdldEFic1hZKHgyLCB5Mik7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuX2dyYXBoaWNzLmxpbmVUbyh0bXBBYnNYWVswXSwgdG1wQWJzWFlbMV0pO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9ncmFwaGljcy5zdHJva2UoKTtcblxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIOebtOi/nlxuICAgICAqL1xuICAgIG1hdGNoQmxvY2tMaW5lOiBmdW5jdGlvbiAoeDEsIHkxLCB4MiwgeTIpIHtcbiAgICAgICAgLy8gY2Mud2FybignbWF0Y2hCbG9jayAgJyArIHgxICsgJywgJyArIHkxICsgJyAgOiAnICsgeDIgKyAnLCAnICsgeTIpO1xuICAgICAgICBpZiAoeDEgIT0geDIgJiYgeTEgIT0geTIpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh4MSA9PSB4Mikge1xuICAgICAgICAgICAgLy8g5ZCM5LiA5YiXXG4gICAgICAgICAgICBpZiAoeDEgPCAwIHx8IHgxID49IHRoaXMucm93cykge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIFltaW4gPSBNYXRoLm1pbih5MSwgeTIpICsgMTtcbiAgICAgICAgICAgIHZhciBZbWF4ID0gTWF0aC5tYXgoeTEsIHkyKTtcbiAgICAgICAgICAgIGZvciAoWW1pbjsgWW1pbiA8IFltYXg7IFltaW4rKykge1xuICAgICAgICAgICAgICAgIGlmICh0aGlzLl9jYW52YXNHcmlkc1t4MSArIDFdW1ltaW4gKyAxXSA+IHRoaXMuX1RZUEVfSU5JVCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHkxID09IHkyKSB7XG4gICAgICAgICAgICAvLyDlkIzkuIDooYxcbiAgICAgICAgICAgIGlmICh5MSA8IDAgfHwgeTEgPj0gdGhpcy5jb2x1bW5zKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgWG1pbiA9IE1hdGgubWluKHgxLCB4MikgKyAxO1xuICAgICAgICAgICAgdmFyIFhtYXggPSBNYXRoLm1heCh4MSwgeDIpO1xuICAgICAgICAgICAgZm9yIChYbWluOyBYbWluIDwgWG1heDsgWG1pbisrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuX2NhbnZhc0dyaWRzW1htaW4gKyAxXVt5MSArIDFdID4gdGhpcy5fVFlQRV9JTklUKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICog6L2s6KeS6YC76L6RXG4gICAgICovXG4gICAgbWF0Y2hCbG9ja0Nvcm5lcl9wb2ludDogZnVuY3Rpb24gKHgxLCB5MSwgeDIsIHkyLCB4MywgeTMpIHtcbiAgICAgICAgdmFyIHN0TWF0Y2ggPSB0aGlzLm1hdGNoQmxvY2tMaW5lKHgxLCB5MSwgeDMsIHkzKTtcbiAgICAgICAgaWYgKHN0TWF0Y2gpIHtcbiAgICAgICAgICAgIHZhciB0ZE1hdGNoID0gdGhpcy5tYXRjaEJsb2NrTGluZSh4MywgeTMsIHgyLCB5Mik7XG4gICAgICAgICAgICBpZiAodGRNYXRjaCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBbeDMsIHkzXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9LFxuXG4gICAgLyoqXG4gICAgICog5LiA5Liq6L2s6KeSXG4gICAgICog5pCc57Si5Yiw6Lev5b6E5pe277yM6L+U5Zue6L2s6KeS5Z2Q5qCHIHgzLCB5M1xuICAgICAqL1xuICAgIG1hdGNoQmxvY2tDb3JuZXI6IGZ1bmN0aW9uICh4MSwgeTEsIHgyLCB5MiwgaXNBeGlzX1gpIHtcbiAgICAgICAgLy8gY2Mud2FybignbWF0Y2hCbG9ja0Nvcm5lciAgJyArIHgxICsgJywgJyArIHkxICsgJyAgOiAnICsgeDIgKyAnLCAnICsgeTIpO1xuICAgICAgICB2YXIgcmVzdWx0O1xuICAgICAgICAvLyDnm7Tov57nmoTov5Tlm55cbiAgICAgICAgaWYgKHgxID09IHgyIHx8IHkxID09IHkyKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOi9rOinkueCuTEgKHgxLCB5MinvvIxZ5pa55ZCRXG4gICAgICAgIGlmICh0aGlzLl9jYW52YXNHcmlkc1t4MSArIDFdW3kyICsgMV0gPD0gdGhpcy5fVFlQRV9JTklUICYmIGlzQXhpc19YICE9IGZhbHNlKSB7XG4gICAgICAgICAgICByZXN1bHQgPSB0aGlzLm1hdGNoQmxvY2tDb3JuZXJfcG9pbnQoeDEsIHkxLCB4MiwgeTIsIHgxLCB5Mik7XG4gICAgICAgICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOi9rOinkueCuTIgKHgyLCB5MSnvvIxY5pa55ZCRXG4gICAgICAgIGlmICh0aGlzLl9jYW52YXNHcmlkc1t4MiArIDFdW3kxICsgMV0gPD0gdGhpcy5fVFlQRV9JTklUICYmIGlzQXhpc19YICE9IHRydWUpIHtcbiAgICAgICAgICAgIHJlc3VsdCA9IHRoaXMubWF0Y2hCbG9ja0Nvcm5lcl9wb2ludCh4MSwgeTEsIHgyLCB5MiwgeDIsIHkxKTtcbiAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfSxcblxuICAgIC8qKlxuICAgICAqIOafkOS4quaWueWQkeS4iueahOaQnOe0oumAu+i+kVxuICAgICAqL1xuICAgIG1hdGNoQmxvY2tVbmZvbGRfYXhpczogZnVuY3Rpb24gKHgxLCB5MSwgeDIsIHkyLCB4MywgeTMsIGlzQXhpc19YKSB7XG5cbiAgICAgICAgdmFyIHRtcFhZID0gW107XG4gICAgICAgIGlmICh0aGlzLl9jYW52YXNHcmlkc1t4MyArIDFdW3kzICsgMV0gPD0gdGhpcy5fVFlQRV9JTklUKSB7XG4gICAgICAgICAgICB0bXBYWSA9IHRoaXMubWF0Y2hCbG9ja0Nvcm5lcih4MywgeTMsIHgyLCB5MiwgaXNBeGlzX1gpO1xuICAgICAgICAgICAgaWYgKHRtcFhZKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFt4MywgeTNdLmNvbmNhdCh0bXBYWSk7O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDnlLHkuK3lv4PlvoDlpJblsZXlvIDmkJzntKLot6/lvoTvvIzmn5DkuKrmlrnlkJHlvZPnorDliLDmnInlm77niYfml7bvvIzov5nkuKrmlrnlkJHlsLHkuI3lho3nu6fnu63mkJzntKJcbiAgICAgKiDmkJzntKLliLDot6/lvoTml7bvvIzov5Tlm57kuKTkuKrovazop5LngrnlnZDmoIcgeDMsIHkzLCB4NCwgeTRcbiAgICAgKi9cbiAgICBtYXRjaEJsb2NrVW5mb2xkOiBmdW5jdGlvbiAoeDEsIHkxLCB4MiwgeTIpIHtcbiAgICAgICAgdmFyIHJlc3VsdDtcbiAgICAgICAgdmFyIHgzID0gMDtcbiAgICAgICAgdmFyIHkzID0gMDtcbiAgICAgICAgdmFyIGNhblVwID0gdHJ1ZTtcbiAgICAgICAgdmFyIGNhbkRvd24gPSB0cnVlO1xuICAgICAgICB2YXIgY2FuTGVmdCA9IHRydWU7XG4gICAgICAgIHZhciBjYW5SaWdodCA9IHRydWU7XG5cbiAgICAgICAgLy8gY2Mud2FybignbWF0Y2hCbG9ja1VuZm9sZCAgJyArIHgxICsgJywgJyArIHkxICsgJyAgOiAnICsgeDIgKyAnLCAnICsgeTIpO1xuICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IHRoaXMucm93czsgaSsrKSB7XG4gICAgICAgICAgICAvLyDkuIpcbiAgICAgICAgICAgIHgzID0geDE7XG4gICAgICAgICAgICB5MyA9IHkxICsgaTtcbiAgICAgICAgICAgIGlmIChjYW5VcCAmJiB5MyA8PSB0aGlzLmNvbHVtbnMpIHtcbiAgICAgICAgICAgICAgICBjYW5VcCA9IHRoaXMuX2NhbnZhc0dyaWRzW3gzICsgMV1beTMgKyAxXSA8PSB0aGlzLl9UWVBFX0lOSVQ7XG4gICAgICAgICAgICAgICAgcmVzdWx0ID0gdGhpcy5tYXRjaEJsb2NrVW5mb2xkX2F4aXMoeDEsIHkxLCB4MiwgeTIsIHgzLCB5MywgZmFsc2UpO1xuICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIOS4i1xuICAgICAgICAgICAgeDMgPSB4MTtcbiAgICAgICAgICAgIHkzID0geTEgLSBpO1xuICAgICAgICAgICAgaWYgKGNhbkRvd24gJiYgeTMgPj0gLTEpIHtcbiAgICAgICAgICAgICAgICBjYW5Eb3duID0gdGhpcy5fY2FudmFzR3JpZHNbeDMgKyAxXVt5MyArIDFdIDw9IHRoaXMuX1RZUEVfSU5JVDtcbiAgICAgICAgICAgICAgICByZXN1bHQgPSB0aGlzLm1hdGNoQmxvY2tVbmZvbGRfYXhpcyh4MSwgeTEsIHgyLCB5MiwgeDMsIHkzLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8g5bemXG4gICAgICAgICAgICB4MyA9IHgxIC0gaTtcbiAgICAgICAgICAgIHkzID0geTE7XG4gICAgICAgICAgICBpZiAoY2FuTGVmdCAmJiB4MyA+PSAtMSkge1xuICAgICAgICAgICAgICAgIGNhbkxlZnQgPSB0aGlzLl9jYW52YXNHcmlkc1t4MyArIDFdW3kzICsgMV0gPD0gdGhpcy5fVFlQRV9JTklUO1xuICAgICAgICAgICAgICAgIHJlc3VsdCA9IHRoaXMubWF0Y2hCbG9ja1VuZm9sZF9heGlzKHgxLCB5MSwgeDIsIHkyLCB4MywgeTMsIHRydWUpO1xuICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIOWPs1xuICAgICAgICAgICAgeDMgPSB4MSArIGk7XG4gICAgICAgICAgICB5MyA9IHkxO1xuICAgICAgICAgICAgaWYgKGNhblJpZ2h0ICYmIHgzIDw9IHRoaXMucm93cykge1xuICAgICAgICAgICAgICAgIGNhblJpZ2h0ID0gdGhpcy5fY2FudmFzR3JpZHNbeDMgKyAxXVt5MyArIDFdIDw9IHRoaXMuX1RZUEVfSU5JVDtcbiAgICAgICAgICAgICAgICByZXN1bHQgPSB0aGlzLm1hdGNoQmxvY2tVbmZvbGRfYXhpcyh4MSwgeTEsIHgyLCB5MiwgeDMsIHkzLCB0cnVlKTtcbiAgICAgICAgICAgICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH0sXG5cbiBcblxuICAgIF9pbml0QW5pbWFsKCkge1xuICAgICAgICB0aGlzLl9hbmlTaG93ID0gdGhpcy5lbmROb2RlLmdldENvbXBvbmVudChjYy5BbmltYXRpb24pO1xuICAgICAgICB0aGlzLl9hbmlTaG93Lm5vZGUuYWN0aXZlID0gZmFsc2U7XG4gICAgICAgIHRoaXMuX2FuaVNob3cuaGlkZUVuZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHRoaXMuX2FuaVNob3cubm9kZS5hY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgfS5iaW5kKHRoaXMpO1xuXG5cbiAgICAgICAgLy8gdGhpcy5fYW5pU2hvdy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0RPV04sdGhpcy5jbG9zZUhhbmRsZSx0aGlzKTtcbiAgICB9LFxuXG4gICAgY2xvc2VIYW5kbGUoZSwgZCkge1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tLS0tY2xvc2VIYW5kbGUtLS0tLS0tLS0tXCIsZSxkKVxuICAgICAgICB0aGlzLl9hbmlTaG93Lm5vZGUuYWN0aXZlID0gZmFsc2U7XG5cbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdnYW1lJyk7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiDmuLjmiI/nu5PmnZ9cbiAgICAgKi9cbiAgICBnYW1lT3ZlcigpIHtcblxuICAgICAgICB0aGlzLmNvdW50ID0gMDtcbiAgICAgICAgdGhpcy50aW1lciA9IDA7XG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBhdXNlQWxsRWZmZWN0cygpO1xuXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0tLS0tLWdhbWVPdmVyLS0tLS0tLS0tLS1cIix0aGlzLl9zY29yZSwgdGhpcy5yb3dzICogdGhpcy5jb2x1bW5zLHRoaXMuZW5kTm9kZS5nZXRDaGlsZEJ5TmFtZShcIndpblwiKSlcblxuICAgICAgICBpZiAodGhpcy5fc2NvcmUgPCB0aGlzLnJvd3MgKiB0aGlzLmNvbHVtbnMgLyAyKSB7XG4gICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuZmFpbGVkQXVkaW8sIGZhbHNlKTtcblxuXG4gICAgICAgICAgICB0aGlzLmVuZE5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJ3aW5cIikuYWN0aXZlID0gZmFsc2VcbiAgICAgICAgICAgIHRoaXMuZW5kTm9kZS5nZXRDaGlsZEJ5TmFtZShcImxvc2VcIikuYWN0aXZlID0gdHJ1ZVxuICAgICAgICAgICAgdGhpcy5lbmROb2RlLmdldENoaWxkQnlOYW1lKFwibG9zZVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByaXRlTG9zZVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLndpbkF1ZGlvLCBmYWxzZSk7XG5cbiAgICAgICAgICAgIHRoaXMuZW5kTm9kZS5nZXRDaGlsZEJ5TmFtZShcIndpblwiKS5hY3RpdmUgPSB0cnVlXG4gICAgICAgICAgICB0aGlzLmVuZE5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJsb3NlXCIpLmFjdGl2ZSA9IGZhbHNlXG4gICAgICAgICAgICB0aGlzLmVuZE5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJ3aW5cIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUgPSB0aGlzLnNwcml0ZVdpblxuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5fYW5pU2hvdy5ub2RlLmFjdGl2ZSA9IHRydWU7XG5cbiAgICAgICAgdmFyIHN0YXRlID0gdGhpcy5fYW5pU2hvdy5wbGF5KCdzY2FsZVNob3cnLCAxKVxuICAgICAgICBzdGF0ZS5yZXBlYXRDb3VudCA9IDE7XG4gICAgICAgIHRoaXMuX2FuaVNob3cubm9kZS56SW5kZXggPSAxMDAwO1xuXG4gICAgICAgIHRoaXMuZ2FtZU92ZXJMYWIuc3RyaW5nID0gXCItNVwiO1xuICAgIH0sXG5cbiAgICAvKipcbiAgICAgKiDov4flhbNcbiAgICAgKi9cbiAgICBnYW1lUGFzczogZnVuY3Rpb24gKCkge1xuICAgICAgICAvLyBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoJ2dhbWVwYXNzJyk7XG4gICAgfSxcblxuXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8qKlxuICAgICAqIOezu+e7n+eahOabtOaWsOS6i+S7tlxuICAgICAqL1xuICAgIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG4gICAgICAgIHRoaXMudGltZXIgKz0gZHQ7XG4gICAgICAgIGlmICh0aGlzLl9hbmlTaG93Lm5vZGUuYWN0aXZlKSB7XG4gICAgICAgICAgICBpZiAodGhpcy50aW1lciA+IHRoaXMuY291bnQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9vdmVyVE1TLS07XG5cbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fb3ZlclRNUyA8IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZUhhbmRsZSgpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5jb3VudCArPSAxO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aGlzLmdhbWVPdmVyTGFiLnN0cmluZyA9IFwiLVwiICsgdGhpcy5fb3ZlclRNUztcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOWkp+S6juW3suiuoeaXtuenkuaVsFxuICAgICAgICBpZiAodGhpcy50aW1lciA+IHRoaXMuY291bnQpIHtcbiAgICAgICAgICAgIHRoaXMudGltZW91dC5zdHJpbmcgPSB0aGlzLmR1cmF0aW9uIC0gdGhpcy5jb3VudDtcbiAgICAgICAgICAgIGlmICh0aGlzLmNvdW50ID49IHRoaXMuZHVyYXRpb24pIHtcbiAgICAgICAgICAgICAgICB0aGlzLmdhbWVPdmVyKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmNvdW50ICs9IDE7XG5cbiAgICAgICAgICAgIHRoaXMuX3RpbWVMYWJBbmkoKVxuICAgICAgICB9XG5cbiAgICB9LFxuICAgIC8v5bCP5LqOMTDkuIDkuIvpl6rng4Hmj5DnpLpcbiAgICBfdGltZUxhYkFuaSgpIHtcbiAgICAgICAgY29uc3QgdHQgPSBOdW1iZXIodGhpcy50aW1lb3V0LnN0cmluZylcbiAgICAgICAgaWYgKHR0ID4gMCAmJiB0dCA8IDEwKSB7XG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tLS0tLS0tLVwiLCB0dClcbiAgICAgICAgICAgIC8vIHRoaXMudGltZW91dC5ub2RlLmNvbG9yID0gbmV3IGNjLmNvbG9yKDI1NSwxLDEpOyBcbiAgICAgICAgICAgIGxldCBhbmkgPSB0aGlzLnRpbWVvdXQubm9kZS5nZXRDb21wb25lbnQoY2MuQW5pbWF0aW9uKTtcbiAgICAgICAgICAgIGxldCBzdGF0ZSA9IGFuaS5wbGF5KCk7XG4gICAgICAgICAgICBzdGF0ZS5yZXBlYXRDb3VudCA9IDI7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgX2JpbmRFdmVudCgpIHtcbiAgICAgICAgLy8gRXZlbnRNYW5hZ2VyLmdldEluc3RhbmNlKCkuYWRkRXZlbnRMaXN0ZW5lcihcInNoYWtlXCIsIHRoaXMuYWRkRXZlbnQsIHRoaXMpO1xuICAgIH0sXG5cbiAgICBfbXlTaGFrZSgpIHtcbiAgICAgICAgbGV0IG1rID0gdGhpcy5jYW1lcmFOb2RlLmdldENvbXBvbmVudChcInNoYWtlXCIpXG4gICAgICAgIG1rLnNoYWtlcigpO1xuICAgIH0sXG5cbiAgICBfc3RvcmFnZUtleSgpe1xuICAgICAgICByZXR1cm4gXCJyYW5kX2RhdGFfa2V5XCI7XG4gICAgfSxcblxuICAgIF9pbml0U2Nyb2xsVmlldygpe1xuICAgICAgLy90ZXN0XG4gICAgICAvL2NjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLl9zdG9yYWdlS2V5KCksICBcInt9XCIgKVxuXG4gICAgICAgIGxldCBjb250ZW50ID0gdGhpcy5yYW5rTGlzdE5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJzY3JvbGxcIikuZ2V0Q29tcG9uZW50KGNjLlNjcm9sbFZpZXcpLmNvbnRlbnQgXG4gICAgICAgIGNvbnN0IGxhc3RSYW5rU3RyaW5nID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKHRoaXMuX3N0b3JhZ2VLZXkoKSk7XG4gICAgIFxuXG4gICAgICAgIGlmKCFsYXN0UmFua1N0cmluZyB8fCBsYXN0UmFua1N0cmluZy5sZW5ndGggPCAxMCl7XG4gICAgICAgICAgICB0aGlzLl9yYW5rTGlzdERhdGEgPSB0aGlzLl9nZXRJdGVtRGF0YSgxMClcbiAgICAgICAgICAgIFxuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgIHRoaXMuX3JhbmtMaXN0RGF0YSA9IEpTT04ucGFyc2UobGFzdFJhbmtTdHJpbmcpIFxuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5fcmFua0xpc3REYXRhLnNvcnQoKGEsYik9PntyZXR1cm4gYi5zMy1hLnMzO30pXG5cbiAgICAgICAgLy8gbGlzdERhdGEgPSB0aGlzLl9nZXRJdGVtRGF0YSgxMClcbiAgICAgICAgZm9yKGxldCBpID0wOyBpIDwgMTAgOyBpKyspeyAgXG4gICAgICAgICAgICBsZXQgIGl0ZW0gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnJhbmtQcmVmYWIpOyAgXG4gICAgICAgICAgICBpdGVtLmluZGV4ID0gaTtcbiAgICAgICAgICAgIGl0ZW0ucGFyZW50ID0gY29udGVudDsgXG4gICAgICAgICAgICBsZXQgdGFibGUgPSBpdGVtLmdldENvbXBvbmVudChcInRhYmxlXCIpXG4gICAgICAgICAgICB0aGlzLl9yYW5rTGlzdERhdGFbaV0uczEgPSBpKzE7XG4gICAgICAgICAgICB0YWJsZS5zZXRMYWJDb250ZW50KCB0aGlzLl9yYW5rTGlzdERhdGFbaV0pOyAgXG4gICAgICAgIH0gIFxuXG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0zMzMtbGlzdERhdGEtLS0tLS0tLS1cIixKU09OLnN0cmluZ2lmeSggIHRoaXMuX3JhbmtMaXN0RGF0YSkgKVxuXG4gICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSh0aGlzLl9zdG9yYWdlS2V5KCksIEpTT04uc3RyaW5naWZ5KCAgdGhpcy5fcmFua0xpc3REYXRhKSApXG4gICAgfSxcblxuICAgIG9uQWN0aW9uUmFuayhlLGQpeyBcbiAgICAgICAgdGhpcy5yYW5rTGlzdE5vZGUuYWN0aXZlID0gIXRoaXMucmFua0xpc3ROb2RlLmFjdGl2ZTsgXG4gICAgfSxcblxuXG4gICAgX2dldEl0ZW1EYXRhKG1heCl7ICBcbiAgICAgICBcbiAgICAgICAgbGV0IGxpc3QgPSBbXTtcbiAgICAgICAgZm9yKGxldCBpPTA7IGk8IG1heDsgaSsrKXtcbiAgICAgICAgICAgIGxpc3QucHVzaCh7XG4gICAgICAgICAgICAgICAgczE6aSsxLFxuICAgICAgICAgICAgICAgIHMyOiB1dG9vbHMucm5kTmFtZSgzKSxcbiAgICAgICAgICAgICAgICBzMzogTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTAwMClcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS1saXN0Pj4tLS1cIiwgbGlzdClcbiAgICAgICAgICBsaXN0LnNvcnQoKGEsYik9PntyZXR1cm4gYi5zMy1hLnMzO30pXG4gICAgICAgIHJldHVybiBsaXN0OyBcbiAgICB9LFxuICAgXG5cbiAgICBfYWRkUmFua0xpc3QoKXtcbiAgICAgICAgY29uc3QgIGRhdGEgPSB7XG4gICAgICAgICAgICBzMTogMSxcbiAgICAgICAgICAgIHMyOiB0aGlzLm5pY2tOYW1lLnN0cmluZyxcbiAgICAgICAgICAgIHMzOiB0aGlzLl9zY29yZVxuICAgICAgICB9XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiLS0tLS0tLV9hZGRSYW5rTGlzdC0tLS0tLS0tXCIsIGRhdGEpXG4gICAgICAgIGNvbnN0IGdlbmQgPSB0aGlzLl9yYW5rTGlzdERhdGFbdGhpcy5fcmFua0xpc3REYXRhLmxlbmd0aC0xXVxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIi0tLS0tLS1fYWRkUmFua0xpc3QtLS0tLS0tLVwiLCBnZW5kKVxuICAgICAgICBpZihnZW5kLnMzID4gZGF0YS5zMyl7XG4gICAgICAgICAgICByZXR1cm4gO1xuICAgICAgICB9XG5cbiAgICAgICAgZm9yKCBsZXQgaT0wOyBpPCB0aGlzLl9yYW5rTGlzdERhdGEubGVuZ3RoOyBpKyspe1xuICAgICAgICAgICAgaWYodGhpcy5fcmFua0xpc3REYXRhW2ldLnMyID09IGRhdGEuczIgJiYgdGhpcy5fcmFua0xpc3REYXRhW2ldLnMzIDwgZGF0YS5zMyl7XG4gICAgICAgICAgICAgICAgdGhpcy5fcmFua0xpc3REYXRhW2ldID0gZGF0YTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fcmFua0xpc3REYXRhLnB1c2goZGF0YSlcbiAgICAgICAgdGhpcy5fcmFua0xpc3REYXRhLnNvcnQoKGEsYik9PntyZXR1cm4gYi5zMy1hLnMzO30pXG4gICAgfSxcblxuICAgIF9zZXRVSVNjb3JlKGxhc3RTY29yZSwgY3J0U2NvcmUpIHtcblxuICAgICAgICB0aGlzLl9zY29yZSArPSAyXG4gICAgICAgIHRoaXMuZ2FtZVNjb3JlLnN0cmluZyA9IHRoaXMuX3Njb3JlXG5cbiAgICAgICAgdGhpcy5fbXlTaGFrZSgpXG5cbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLS0tLS1fc2V0VUlTY29yZS0tLS0tXCIsdGhpcy5fc2NvcmUgLCB0aGlzLnJvd3MgKiB0aGlzLmNvbHVtbnMpXG4gICAgICAgIC8v5piv5ZCm5Yi35pawXG4gICAgICAgIGlmICh0aGlzLl9zY29yZSA+PSB0aGlzLnJvd3MgKiB0aGlzLmNvbHVtbnMpIHtcbiAgICAgICAgICAgIHRoaXMuX3RvdGFsU2NvcmUrKyBcbiAgICAgICAgICAgIC8vIHRoaXMuX3Jlc2V0R2FtZSgpXG4gICAgICAgICAgICB0aGlzLmdhbWVPdmVyKClcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9hZGRSYW5rTGlzdCgpOyAgICBcbiAgICB9LFxufSk7XG5cblxuIl19