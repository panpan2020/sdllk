
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/sandian.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7255afBSUNPxJn9zlmHzpeB', 'sandian');
// scripts/sandian.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    this._draw = this.node.getComponent(cc.Graphics);
    this._curDetail = Math.random() * 10;
    var p = cc.winSize;
    this._scWidth = p.width;
    this._scHeight = p.height;
  },
  update: function update(dt) {
    // console.log("-------------") 
    this._draw.clear();

    var x1 = Math.random() * this._scWidth;

    var y1 = Math.random() * this._scHeight;

    var x2 = Math.random() * this._scWidth * 1.1;
    var y2 = Math.random() * this._scHeight * 1.1;
    var display = Math.random() * 500;

    this._lighting(x1, y1, x2, y2, display);
  },
  _startDraw: function _startDraw(x1, y1, x2, y2) {
    this._draw.moveTo(x1, y1);

    this._draw.lineTo(x2, y2);

    this._draw.stroke();
  },
  _lighting: function _lighting(x1, y1, x2, y2, displace) {
    if (displace < this._curDetail) {
      this._startDraw(x1, y1, x2, y2);
    } else {
      var mid_x = (x1 + x2) / 2;
      var mid_y = (y1 + y2) / 2;
      mid_x += (Math.random() - 0.5) * displace;
      mid_y += (Math.random() - 0.5) * displace;

      this._lighting(x1, y1, mid_x, mid_y, displace / 2);

      this._lighting(x2, y2, mid_x, mid_y, displace / 2);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc2FuZGlhbi5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50Iiwic3RhcnQiLCJfZHJhdyIsIm5vZGUiLCJnZXRDb21wb25lbnQiLCJHcmFwaGljcyIsIl9jdXJEZXRhaWwiLCJNYXRoIiwicmFuZG9tIiwicCIsIndpblNpemUiLCJfc2NXaWR0aCIsIndpZHRoIiwiX3NjSGVpZ2h0IiwiaGVpZ2h0IiwidXBkYXRlIiwiZHQiLCJjbGVhciIsIngxIiwieTEiLCJ4MiIsInkyIiwiZGlzcGxheSIsIl9saWdodGluZyIsIl9zdGFydERyYXciLCJtb3ZlVG8iLCJsaW5lVG8iLCJzdHJva2UiLCJkaXNwbGFjZSIsIm1pZF94IiwibWlkX3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0w7QUFFQTtBQUVBQyxFQUFBQSxLQVBLLG1CQU9HO0FBQ0osU0FBS0MsS0FBTCxHQUFhLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1Qk4sRUFBRSxDQUFDTyxRQUExQixDQUFiO0FBQ0EsU0FBS0MsVUFBTCxHQUFrQkMsSUFBSSxDQUFDQyxNQUFMLEtBQWdCLEVBQWxDO0FBRUEsUUFBTUMsQ0FBQyxHQUFHWCxFQUFFLENBQUNZLE9BQWI7QUFDQSxTQUFLQyxRQUFMLEdBQWdCRixDQUFDLENBQUNHLEtBQWxCO0FBQ0EsU0FBS0MsU0FBTCxHQUFpQkosQ0FBQyxDQUFDSyxNQUFuQjtBQUVILEdBZkk7QUFpQkxDLEVBQUFBLE1BakJLLGtCQWlCRUMsRUFqQkYsRUFpQk07QUFDUDtBQUNBLFNBQUtkLEtBQUwsQ0FBV2UsS0FBWDs7QUFDQSxRQUFNQyxFQUFFLEdBQUdYLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixLQUFLRyxRQUFoQzs7QUFDQSxRQUFNUSxFQUFFLEdBQUdaLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixLQUFLSyxTQUFoQzs7QUFFQSxRQUFNTyxFQUFFLEdBQUdiLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixLQUFLRyxRQUFyQixHQUFnQyxHQUEzQztBQUNBLFFBQU1VLEVBQUUsR0FBR2QsSUFBSSxDQUFDQyxNQUFMLEtBQWdCLEtBQUtLLFNBQXJCLEdBQWlDLEdBQTVDO0FBQ0EsUUFBTVMsT0FBTyxHQUFHZixJQUFJLENBQUNDLE1BQUwsS0FBZ0IsR0FBaEM7O0FBQ0EsU0FBS2UsU0FBTCxDQUFlTCxFQUFmLEVBQW1CQyxFQUFuQixFQUF1QkMsRUFBdkIsRUFBMkJDLEVBQTNCLEVBQStCQyxPQUEvQjtBQUNILEdBM0JJO0FBNkJMRSxFQUFBQSxVQTdCSyxzQkE2Qk1OLEVBN0JOLEVBNkJVQyxFQTdCVixFQTZCY0MsRUE3QmQsRUE2QmtCQyxFQTdCbEIsRUE2QnNCO0FBRXZCLFNBQUtuQixLQUFMLENBQVd1QixNQUFYLENBQWtCUCxFQUFsQixFQUFzQkMsRUFBdEI7O0FBQ0EsU0FBS2pCLEtBQUwsQ0FBV3dCLE1BQVgsQ0FBa0JOLEVBQWxCLEVBQXNCQyxFQUF0Qjs7QUFDQSxTQUFLbkIsS0FBTCxDQUFXeUIsTUFBWDtBQUNILEdBbENJO0FBb0NMSixFQUFBQSxTQXBDSyxxQkFvQ0tMLEVBcENMLEVBb0NTQyxFQXBDVCxFQW9DYUMsRUFwQ2IsRUFvQ2lCQyxFQXBDakIsRUFvQ3FCTyxRQXBDckIsRUFvQytCO0FBRWhDLFFBQUlBLFFBQVEsR0FBRyxLQUFLdEIsVUFBcEIsRUFBZ0M7QUFDNUIsV0FBS2tCLFVBQUwsQ0FBZ0JOLEVBQWhCLEVBQW9CQyxFQUFwQixFQUF3QkMsRUFBeEIsRUFBNEJDLEVBQTVCO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsVUFBSVEsS0FBSyxHQUFHLENBQUNYLEVBQUUsR0FBR0UsRUFBTixJQUFZLENBQXhCO0FBQ0EsVUFBSVUsS0FBSyxHQUFHLENBQUNYLEVBQUUsR0FBR0UsRUFBTixJQUFZLENBQXhCO0FBQ0FRLE1BQUFBLEtBQUssSUFBSSxDQUFDdEIsSUFBSSxDQUFDQyxNQUFMLEtBQWdCLEdBQWpCLElBQXdCb0IsUUFBakM7QUFDQUUsTUFBQUEsS0FBSyxJQUFJLENBQUN2QixJQUFJLENBQUNDLE1BQUwsS0FBZ0IsR0FBakIsSUFBd0JvQixRQUFqQzs7QUFDQSxXQUFLTCxTQUFMLENBQWVMLEVBQWYsRUFBbUJDLEVBQW5CLEVBQXVCVSxLQUF2QixFQUE4QkMsS0FBOUIsRUFBcUNGLFFBQVEsR0FBRyxDQUFoRDs7QUFDQSxXQUFLTCxTQUFMLENBQWVILEVBQWYsRUFBbUJDLEVBQW5CLEVBQXVCUSxLQUF2QixFQUE4QkMsS0FBOUIsRUFBcUNGLFFBQVEsR0FBRyxDQUFoRDtBQUNIO0FBQ0o7QUFoREksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsIFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCgpIHtcclxuICAgICAgICB0aGlzLl9kcmF3ID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5HcmFwaGljcyk7ICBcclxuICAgICAgICB0aGlzLl9jdXJEZXRhaWwgPSBNYXRoLnJhbmRvbSgpICogMTA7XHJcblxyXG4gICAgICAgIGNvbnN0IHAgPSBjYy53aW5TaXplO1xyXG4gICAgICAgIHRoaXMuX3NjV2lkdGggPSBwLndpZHRoXHJcbiAgICAgICAgdGhpcy5fc2NIZWlnaHQgPSBwLmhlaWdodFxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGUoZHQpIHsgXHJcbiAgICAgICAgLy8gY29uc29sZS5sb2coXCItLS0tLS0tLS0tLS0tXCIpIFxyXG4gICAgICAgIHRoaXMuX2RyYXcuY2xlYXIoKTtcclxuICAgICAgICBjb25zdCB4MSA9IE1hdGgucmFuZG9tKCkgKiB0aGlzLl9zY1dpZHRoXHJcbiAgICAgICAgY29uc3QgeTEgPSBNYXRoLnJhbmRvbSgpICogdGhpcy5fc2NIZWlnaHRcclxuXHJcbiAgICAgICAgY29uc3QgeDIgPSBNYXRoLnJhbmRvbSgpICogdGhpcy5fc2NXaWR0aCAqIDEuMVxyXG4gICAgICAgIGNvbnN0IHkyID0gTWF0aC5yYW5kb20oKSAqIHRoaXMuX3NjSGVpZ2h0ICogMS4xXHJcbiAgICAgICAgY29uc3QgZGlzcGxheSA9IE1hdGgucmFuZG9tKCkgKiA1MDBcclxuICAgICAgICB0aGlzLl9saWdodGluZyh4MSwgeTEsIHgyLCB5MiwgZGlzcGxheSk7XHJcbiAgICB9LFxyXG5cclxuICAgIF9zdGFydERyYXcoeDEsIHkxLCB4MiwgeTIpIHtcclxuXHJcbiAgICAgICAgdGhpcy5fZHJhdy5tb3ZlVG8oeDEsIHkxKTtcclxuICAgICAgICB0aGlzLl9kcmF3LmxpbmVUbyh4MiwgeTIpO1xyXG4gICAgICAgIHRoaXMuX2RyYXcuc3Ryb2tlKCk7XHJcbiAgICB9LFxyXG5cclxuICAgIF9saWdodGluZyh4MSwgeTEsIHgyLCB5MiwgZGlzcGxhY2UpIHtcclxuXHJcbiAgICAgICAgaWYgKGRpc3BsYWNlIDwgdGhpcy5fY3VyRGV0YWlsKSB7XHJcbiAgICAgICAgICAgIHRoaXMuX3N0YXJ0RHJhdyh4MSwgeTEsIHgyLCB5MilcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBsZXQgbWlkX3ggPSAoeDEgKyB4MikgLyAyXHJcbiAgICAgICAgICAgIGxldCBtaWRfeSA9ICh5MSArIHkyKSAvIDI7XHJcbiAgICAgICAgICAgIG1pZF94ICs9IChNYXRoLnJhbmRvbSgpIC0gMC41KSAqIGRpc3BsYWNlO1xyXG4gICAgICAgICAgICBtaWRfeSArPSAoTWF0aC5yYW5kb20oKSAtIDAuNSkgKiBkaXNwbGFjZTtcclxuICAgICAgICAgICAgdGhpcy5fbGlnaHRpbmcoeDEsIHkxLCBtaWRfeCwgbWlkX3ksIGRpc3BsYWNlIC8gMik7XHJcbiAgICAgICAgICAgIHRoaXMuX2xpZ2h0aW5nKHgyLCB5MiwgbWlkX3gsIG1pZF95LCBkaXNwbGFjZSAvIDIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSk7XHJcbiJdfQ==