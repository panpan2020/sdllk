
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/table.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9ba34lAu6NG8KupHeC87EBN', 'table');
// scripts/table.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    nameLab: cc.Label,
    duanwieLab: cc.Label,
    zhanjiLab: cc.Label
  },
  start: function start() {},
  // update (dt) {},
  setLabContent: function setLabContent(data) {
    this.nameLab.string = data.s1;
    this.duanwieLab.string = data.s2;
    this.zhanjiLab.string = data.s3;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcdGFibGUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJuYW1lTGFiIiwiTGFiZWwiLCJkdWFud2llTGFiIiwiemhhbmppTGFiIiwic3RhcnQiLCJzZXRMYWJDb250ZW50IiwiZGF0YSIsInN0cmluZyIsInMxIiwiczIiLCJzMyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBRVJDLElBQUFBLE9BQU8sRUFBQ0osRUFBRSxDQUFDSyxLQUZIO0FBR1JDLElBQUFBLFVBQVUsRUFBQ04sRUFBRSxDQUFDSyxLQUhOO0FBSVJFLElBQUFBLFNBQVMsRUFBQ1AsRUFBRSxDQUFDSztBQUpMLEdBSFA7QUFZTEcsRUFBQUEsS0FaSyxtQkFZSSxDQUVSLENBZEk7QUFnQkw7QUFDQUMsRUFBQUEsYUFqQksseUJBaUJTQyxJQWpCVCxFQWlCYztBQUVYLFNBQUtOLE9BQUwsQ0FBYU8sTUFBYixHQUFzQkQsSUFBSSxDQUFDRSxFQUEzQjtBQUNBLFNBQUtOLFVBQUwsQ0FBZ0JLLE1BQWhCLEdBQXlCRCxJQUFJLENBQUNHLEVBQTlCO0FBQ0EsU0FBS04sU0FBTCxDQUFlSSxNQUFmLEdBQXVCRCxJQUFJLENBQUNJLEVBQTVCO0FBQ1A7QUF0QkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIFxyXG4gICAgICAgIG5hbWVMYWI6Y2MuTGFiZWwsXHJcbiAgICAgICAgZHVhbndpZUxhYjpjYy5MYWJlbCxcclxuICAgICAgICB6aGFuamlMYWI6Y2MuTGFiZWxcclxuICAgIH0sXHJcblxyXG4gIFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG4gICAgc2V0TGFiQ29udGVudChkYXRhKXtcclxuIFxyXG4gICAgICAgICAgICB0aGlzLm5hbWVMYWIuc3RyaW5nID0gZGF0YS5zMTtcclxuICAgICAgICAgICAgdGhpcy5kdWFud2llTGFiLnN0cmluZyA9IGRhdGEuczI7XHJcbiAgICAgICAgICAgIHRoaXMuemhhbmppTGFiLnN0cmluZyA9ZGF0YS5zMzsgXHJcbiAgICB9LFxyXG59KTtcclxuIl19