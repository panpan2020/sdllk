
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/rank.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '10c9c72ENxIAYCxVgqsAewv', 'rank');
// scripts/rank.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    duanweiLab: cc.Label,
    zhanjiLab: cc.Label,
    closeBtn: cc.Button,
    scrollView: cc.ScrollView,
    itemPrefab: cc.Prefab
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.list = [];

    for (var i = 1; i < 10; i++) {
      this.list.push(i);
    }

    this.content = this.scrollView.content;
    this.optItem = [];

    for (var j = 0; j < 8; j++) {
      var item = cc.instantiate(this.itemPrefab);
      this.content.addChild(item);
      this.optItem.push(item);
    }

    this.scrollView.node.on("scroll-ended", this.onToEnd.bind(this), this);
  },
  start: function start() {
    this.startIndex = 0;
    this.loadRecord(this.startIndex);
  },
  loadRecord: function loadRecord(startIndex) {
    this.startIndex = startIndex;

    for (var i = 0; i < 8; i++) {
      var mytable = this.optItem[i].getComponent("table");
      mytable.setLabContent({
        s1: "s1",
        s2: "s2",
        s3: "s3"
      });
    }
  },
  onToEnd: function onToEnd() {
    this.loadScrollRecord();
    this.scrollView.elastic = true;
  },
  update: function update(dt) {
    this.loadScrollRecord();
  },
  loadScrollRecord: function loadScrollRecord() {
    if (this.start_index + this.PAGE_NUM * 3 < this.value_set.length && this.content.y >= this.start_y + this.PAGE_NUM * 2 * this.HIGH) //content超过2个PAGE的高度
      {
        //_autoScrolling在引擎源码中负责处理scrollview的滚动动作
        if (this.scroll_view._autoScrolling) {
          //等自动滚动结束后再加载防止滚动过快，直接跳到非常后的位置
          this.scroll_view.elastic = false; //关闭回弹效果 美观

          return;
        }

        var down_loaded = this.PAGE_NUM;
        this.start_index += down_loaded;

        if (this.start_index + this.PAGE_NUM * 3 > this.value_set.length) {
          //超过数据范围的长度
          var out_len = this.start_index + this.PAGE_NUM * 3 - this.value_set.length;
          down_loaded -= out_len;
          this.start_index -= out_len;
        }

        this.load_recode(this.start_index);
        this.content.y -= down_loaded * this.HIGH;
        return;
      } //向上加载


    if (this.start_index > 0 && this.content.y <= this.start_y) {
      if (this.scroll_view._autoScrolling) {
        this.scroll_view.elastic = false;
        return;
      }

      var up_loaded = this.PAGE_NUM;
      this.start_index -= up_loaded;

      if (this.start_index < 0) {
        up_loaded += this.start_index;
        this.start_index = 0;
      }

      this.load_recode(this.start_index);
      this.content.y += up_loaded * this.HIGH;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xccmFuay5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImR1YW53ZWlMYWIiLCJMYWJlbCIsInpoYW5qaUxhYiIsImNsb3NlQnRuIiwiQnV0dG9uIiwic2Nyb2xsVmlldyIsIlNjcm9sbFZpZXciLCJpdGVtUHJlZmFiIiwiUHJlZmFiIiwib25Mb2FkIiwibGlzdCIsImkiLCJwdXNoIiwiY29udGVudCIsIm9wdEl0ZW0iLCJqIiwiaXRlbSIsImluc3RhbnRpYXRlIiwiYWRkQ2hpbGQiLCJub2RlIiwib24iLCJvblRvRW5kIiwiYmluZCIsInN0YXJ0Iiwic3RhcnRJbmRleCIsImxvYWRSZWNvcmQiLCJteXRhYmxlIiwiZ2V0Q29tcG9uZW50Iiwic2V0TGFiQ29udGVudCIsInMxIiwiczIiLCJzMyIsImxvYWRTY3JvbGxSZWNvcmQiLCJlbGFzdGljIiwidXBkYXRlIiwiZHQiLCJzdGFydF9pbmRleCIsIlBBR0VfTlVNIiwidmFsdWVfc2V0IiwibGVuZ3RoIiwieSIsInN0YXJ0X3kiLCJISUdIIiwic2Nyb2xsX3ZpZXciLCJfYXV0b1Njcm9sbGluZyIsImRvd25fbG9hZGVkIiwib3V0X2xlbiIsImxvYWRfcmVjb2RlIiwidXBfbG9hZGVkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDVEMsSUFBQUEsVUFBVSxFQUFDSixFQUFFLENBQUNLLEtBREw7QUFFVEMsSUFBQUEsU0FBUyxFQUFDTixFQUFFLENBQUNLLEtBRko7QUFHVEUsSUFBQUEsUUFBUSxFQUFDUCxFQUFFLENBQUNRLE1BSEg7QUFJVEMsSUFBQUEsVUFBVSxFQUFDVCxFQUFFLENBQUNVLFVBSkw7QUFLVEMsSUFBQUEsVUFBVSxFQUFDWCxFQUFFLENBQUNZO0FBTEwsR0FIUDtBQVdMO0FBRUFDLEVBQUFBLE1BYkssb0JBYUs7QUFDTixTQUFLQyxJQUFMLEdBQVUsRUFBVjs7QUFDQSxTQUFJLElBQUlDLENBQUMsR0FBQyxDQUFWLEVBQWFBLENBQUMsR0FBQyxFQUFmLEVBQW1CQSxDQUFDLEVBQXBCLEVBQXVCO0FBQ25CLFdBQUtELElBQUwsQ0FBVUUsSUFBVixDQUFlRCxDQUFmO0FBQ0g7O0FBQ0QsU0FBS0UsT0FBTCxHQUFlLEtBQUtSLFVBQUwsQ0FBZ0JRLE9BQS9CO0FBQ0EsU0FBS0MsT0FBTCxHQUFlLEVBQWY7O0FBQ0EsU0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFhQSxDQUFDLEdBQUUsQ0FBaEIsRUFBbUJBLENBQUMsRUFBcEIsRUFBdUI7QUFDbkIsVUFBSUMsSUFBSSxHQUFHcEIsRUFBRSxDQUFDcUIsV0FBSCxDQUFlLEtBQUtWLFVBQXBCLENBQVg7QUFDQSxXQUFLTSxPQUFMLENBQWFLLFFBQWIsQ0FBc0JGLElBQXRCO0FBQ0EsV0FBS0YsT0FBTCxDQUFhRixJQUFiLENBQWtCSSxJQUFsQjtBQUNIOztBQUNELFNBQUtYLFVBQUwsQ0FBZ0JjLElBQWhCLENBQXFCQyxFQUFyQixDQUF3QixjQUF4QixFQUF1QyxLQUFLQyxPQUFMLENBQWFDLElBQWIsQ0FBa0IsSUFBbEIsQ0FBdkMsRUFBK0QsSUFBL0Q7QUFDSCxHQTFCSTtBQTRCTEMsRUFBQUEsS0E1QkssbUJBNEJJO0FBRUwsU0FBS0MsVUFBTCxHQUFrQixDQUFsQjtBQUNBLFNBQUtDLFVBQUwsQ0FBZ0IsS0FBS0QsVUFBckI7QUFDSCxHQWhDSTtBQWtDTEMsRUFBQUEsVUFsQ0ssc0JBa0NNRCxVQWxDTixFQWtDaUI7QUFDbEIsU0FBS0EsVUFBTCxHQUFrQkEsVUFBbEI7O0FBQ0EsU0FBSSxJQUFJYixDQUFDLEdBQUMsQ0FBVixFQUFhQSxDQUFDLEdBQUUsQ0FBaEIsRUFBbUJBLENBQUMsRUFBcEIsRUFBdUI7QUFDbkIsVUFBSWUsT0FBTyxHQUFHLEtBQUtaLE9BQUwsQ0FBYUgsQ0FBYixFQUFnQmdCLFlBQWhCLENBQTZCLE9BQTdCLENBQWQ7QUFDQUQsTUFBQUEsT0FBTyxDQUFDRSxhQUFSLENBQXNCO0FBQ2xCQyxRQUFBQSxFQUFFLEVBQUMsSUFEZTtBQUVsQkMsUUFBQUEsRUFBRSxFQUFDLElBRmU7QUFHbEJDLFFBQUFBLEVBQUUsRUFBQztBQUhlLE9BQXRCO0FBS0g7QUFDSixHQTVDSTtBQTZDTFYsRUFBQUEsT0E3Q0sscUJBNkNJO0FBQ0wsU0FBS1csZ0JBQUw7QUFDQSxTQUFLM0IsVUFBTCxDQUFnQjRCLE9BQWhCLEdBQXlCLElBQXpCO0FBQ0gsR0FoREk7QUFpRExDLEVBQUFBLE1BakRLLGtCQWlER0MsRUFqREgsRUFpRE87QUFDUixTQUFLSCxnQkFBTDtBQUNILEdBbkRJO0FBcURMQSxFQUFBQSxnQkFyREssOEJBcURjO0FBQ2YsUUFBRyxLQUFLSSxXQUFMLEdBQW1CLEtBQUtDLFFBQUwsR0FBZ0IsQ0FBbkMsR0FBdUMsS0FBS0MsU0FBTCxDQUFlQyxNQUF0RCxJQUNDLEtBQUsxQixPQUFMLENBQWEyQixDQUFiLElBQWtCLEtBQUtDLE9BQUwsR0FBZSxLQUFLSixRQUFMLEdBQWdCLENBQWhCLEdBQW9CLEtBQUtLLElBRDlELEVBQ21FO0FBQ2pFO0FBQ0k7QUFDQSxZQUFHLEtBQUtDLFdBQUwsQ0FBaUJDLGNBQXBCLEVBQW1DO0FBQUU7QUFDakMsZUFBS0QsV0FBTCxDQUFpQlYsT0FBakIsR0FBMkIsS0FBM0IsQ0FEK0IsQ0FDRzs7QUFDbEM7QUFDSDs7QUFDRCxZQUFJWSxXQUFXLEdBQUcsS0FBS1IsUUFBdkI7QUFDQSxhQUFLRCxXQUFMLElBQW9CUyxXQUFwQjs7QUFFQSxZQUFHLEtBQUtULFdBQUwsR0FBbUIsS0FBS0MsUUFBTCxHQUFnQixDQUFuQyxHQUFxQyxLQUFLQyxTQUFMLENBQWVDLE1BQXZELEVBQ0E7QUFDSTtBQUNBLGNBQUlPLE9BQU8sR0FBRyxLQUFLVixXQUFMLEdBQW1CLEtBQUtDLFFBQUwsR0FBZ0IsQ0FBbkMsR0FBdUMsS0FBS0MsU0FBTCxDQUFlQyxNQUFwRTtBQUNBTSxVQUFBQSxXQUFXLElBQUlDLE9BQWY7QUFDQSxlQUFLVixXQUFMLElBQW9CVSxPQUFwQjtBQUNIOztBQUNELGFBQUtDLFdBQUwsQ0FBaUIsS0FBS1gsV0FBdEI7QUFDQSxhQUFLdkIsT0FBTCxDQUFhMkIsQ0FBYixJQUFrQkssV0FBVyxHQUFHLEtBQUtILElBQXJDO0FBQ0E7QUFDSCxPQXRCWSxDQXVCYjs7O0FBQ0EsUUFBRyxLQUFLTixXQUFMLEdBQWlCLENBQWpCLElBQXNCLEtBQUt2QixPQUFMLENBQWEyQixDQUFiLElBQWdCLEtBQUtDLE9BQTlDLEVBQ0E7QUFDSSxVQUFHLEtBQUtFLFdBQUwsQ0FBaUJDLGNBQXBCLEVBQW1DO0FBQy9CLGFBQUtELFdBQUwsQ0FBaUJWLE9BQWpCLEdBQTJCLEtBQTNCO0FBQ0E7QUFDRjs7QUFDRixVQUFJZSxTQUFTLEdBQUcsS0FBS1gsUUFBckI7QUFDQSxXQUFLRCxXQUFMLElBQW9CWSxTQUFwQjs7QUFDQSxVQUFHLEtBQUtaLFdBQUwsR0FBaUIsQ0FBcEIsRUFBc0I7QUFDbEJZLFFBQUFBLFNBQVMsSUFBRyxLQUFLWixXQUFqQjtBQUNBLGFBQUtBLFdBQUwsR0FBaUIsQ0FBakI7QUFDSDs7QUFDRCxXQUFLVyxXQUFMLENBQWlCLEtBQUtYLFdBQXRCO0FBQ0EsV0FBS3ZCLE9BQUwsQ0FBYTJCLENBQWIsSUFBa0JRLFNBQVMsR0FBRyxLQUFLTixJQUFuQztBQUNIO0FBQ047QUE1RkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgZHVhbndlaUxhYjpjYy5MYWJlbCxcclxuICAgICAgIHpoYW5qaUxhYjpjYy5MYWJlbCxcclxuICAgICAgIGNsb3NlQnRuOmNjLkJ1dHRvbixcclxuICAgICAgIHNjcm9sbFZpZXc6Y2MuU2Nyb2xsVmlldyxcclxuICAgICAgIGl0ZW1QcmVmYWI6Y2MuUHJlZmFiXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcbiAgICAgICAgdGhpcy5saXN0PVtdO1xyXG4gICAgICAgIGZvcihsZXQgaT0xOyBpPDEwOyBpKyspe1xyXG4gICAgICAgICAgICB0aGlzLmxpc3QucHVzaChpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5jb250ZW50ID0gdGhpcy5zY3JvbGxWaWV3LmNvbnRlbnQ7XHJcbiAgICAgICAgdGhpcy5vcHRJdGVtID0gW107XHJcbiAgICAgICAgZm9yKGxldCBqPTA7IGo8IDg7IGorKyl7XHJcbiAgICAgICAgICAgIGxldCBpdGVtID0gY2MuaW5zdGFudGlhdGUodGhpcy5pdGVtUHJlZmFiKTtcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50LmFkZENoaWxkKGl0ZW0pO1xyXG4gICAgICAgICAgICB0aGlzLm9wdEl0ZW0ucHVzaChpdGVtKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5zY3JvbGxWaWV3Lm5vZGUub24oXCJzY3JvbGwtZW5kZWRcIix0aGlzLm9uVG9FbmQuYmluZCh0aGlzKSx0aGlzKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkgeyBcclxuXHJcbiAgICAgICAgdGhpcy5zdGFydEluZGV4ID0gMDtcclxuICAgICAgICB0aGlzLmxvYWRSZWNvcmQodGhpcy5zdGFydEluZGV4KTtcclxuICAgIH0sXHJcblxyXG4gICAgbG9hZFJlY29yZChzdGFydEluZGV4KXtcclxuICAgICAgICB0aGlzLnN0YXJ0SW5kZXggPSBzdGFydEluZGV4O1xyXG4gICAgICAgIGZvcihsZXQgaT0wOyBpPCA4OyBpKyspe1xyXG4gICAgICAgICAgICBsZXQgbXl0YWJsZSA9IHRoaXMub3B0SXRlbVtpXS5nZXRDb21wb25lbnQoXCJ0YWJsZVwiKTtcclxuICAgICAgICAgICAgbXl0YWJsZS5zZXRMYWJDb250ZW50KHtcclxuICAgICAgICAgICAgICAgIHMxOlwiczFcIixcclxuICAgICAgICAgICAgICAgIHMyOlwiczJcIixcclxuICAgICAgICAgICAgICAgIHMzOlwiczNcIlxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgb25Ub0VuZCgpe1xyXG4gICAgICAgIHRoaXMubG9hZFNjcm9sbFJlY29yZCgpO1xyXG4gICAgICAgIHRoaXMuc2Nyb2xsVmlldy5lbGFzdGljPSB0cnVlO1xyXG4gICAgfSxcclxuICAgIHVwZGF0ZSAoZHQpIHtcclxuICAgICAgICB0aGlzLmxvYWRTY3JvbGxSZWNvcmQoKTtcclxuICAgIH0sXHJcblxyXG4gICAgbG9hZFNjcm9sbFJlY29yZCggKXtcclxuICAgICAgICBpZih0aGlzLnN0YXJ0X2luZGV4ICsgdGhpcy5QQUdFX05VTSAqIDMgPCB0aGlzLnZhbHVlX3NldC5sZW5ndGggJiZcclxuICAgICAgICAgICAgdGhpcy5jb250ZW50LnkgPj0gdGhpcy5zdGFydF95ICsgdGhpcy5QQUdFX05VTSAqIDIgKiB0aGlzLkhJR0gpLy9jb250ZW506LaF6L+HMuS4qlBBR0XnmoTpq5jluqZcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvL19hdXRvU2Nyb2xsaW5n5Zyo5byV5pOO5rqQ56CB5Lit6LSf6LSj5aSE55CGc2Nyb2xsdmlld+eahOa7muWKqOWKqOS9nFxyXG4gICAgICAgICAgICAgIGlmKHRoaXMuc2Nyb2xsX3ZpZXcuX2F1dG9TY3JvbGxpbmcpeyAvL+etieiHquWKqOa7muWKqOe7k+adn+WQjuWGjeWKoOi9vemYsuatoua7muWKqOi/h+W/q++8jOebtOaOpei3s+WIsOmdnuW4uOWQjueahOS9jee9rlxyXG4gICAgICAgICAgICAgICAgICB0aGlzLnNjcm9sbF92aWV3LmVsYXN0aWMgPSBmYWxzZTsgLy/lhbPpl63lm57lvLnmlYjmnpwg576O6KeCXHJcbiAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgdmFyIGRvd25fbG9hZGVkID0gdGhpcy5QQUdFX05VTTsgXHJcbiAgICAgICAgICAgICAgdGhpcy5zdGFydF9pbmRleCArPSBkb3duX2xvYWRlZDtcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICBpZih0aGlzLnN0YXJ0X2luZGV4ICsgdGhpcy5QQUdFX05VTSAqIDM+dGhpcy52YWx1ZV9zZXQubGVuZ3RoKVxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgLy/otoXov4fmlbDmja7ojIPlm7TnmoTplb/luqZcclxuICAgICAgICAgICAgICAgICAgdmFyIG91dF9sZW4gPSB0aGlzLnN0YXJ0X2luZGV4ICsgdGhpcy5QQUdFX05VTSAqIDMgLSB0aGlzLnZhbHVlX3NldC5sZW5ndGg7XHJcbiAgICAgICAgICAgICAgICAgIGRvd25fbG9hZGVkIC09IG91dF9sZW47XHJcbiAgICAgICAgICAgICAgICAgIHRoaXMuc3RhcnRfaW5kZXggLT0gb3V0X2xlbjtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgdGhpcy5sb2FkX3JlY29kZSh0aGlzLnN0YXJ0X2luZGV4KTtcclxuICAgICAgICAgICAgICB0aGlzLmNvbnRlbnQueSAtPSBkb3duX2xvYWRlZCAqIHRoaXMuSElHSDtcclxuICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAvL+WQkeS4iuWKoOi9vVxyXG4gICAgICAgICAgaWYodGhpcy5zdGFydF9pbmRleD4wICYmIHRoaXMuY29udGVudC55PD10aGlzLnN0YXJ0X3kpXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgaWYodGhpcy5zY3JvbGxfdmlldy5fYXV0b1Njcm9sbGluZyl7IFxyXG4gICAgICAgICAgICAgICAgICB0aGlzLnNjcm9sbF92aWV3LmVsYXN0aWMgPSBmYWxzZTtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgdmFyIHVwX2xvYWRlZCA9IHRoaXMuUEFHRV9OVU07XHJcbiAgICAgICAgICAgICAgdGhpcy5zdGFydF9pbmRleCAtPSB1cF9sb2FkZWQ7XHJcbiAgICAgICAgICAgICAgaWYodGhpcy5zdGFydF9pbmRleDwwKXtcclxuICAgICAgICAgICAgICAgICAgdXBfbG9hZGVkICs9dGhpcy5zdGFydF9pbmRleDtcclxuICAgICAgICAgICAgICAgICAgdGhpcy5zdGFydF9pbmRleD0wO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB0aGlzLmxvYWRfcmVjb2RlKHRoaXMuc3RhcnRfaW5kZXgpO1xyXG4gICAgICAgICAgICAgIHRoaXMuY29udGVudC55ICs9IHVwX2xvYWRlZCAqIHRoaXMuSElHSDtcclxuICAgICAgICAgIH1cclxuICAgIH1cclxufSk7XHJcbiJdfQ==