// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component, 

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start() {
        this._draw = this.node.getComponent(cc.Graphics);  
        this._curDetail = Math.random() * 10;

        const p = cc.winSize;
        this._scWidth = p.width
        this._scHeight = p.height
        
    },

    update(dt) { 
        // console.log("-------------") 
        this._draw.clear();
        const x1 = Math.random() * this._scWidth
        const y1 = Math.random() * this._scHeight

        const x2 = Math.random() * this._scWidth * 1.1
        const y2 = Math.random() * this._scHeight * 1.1
        const display = Math.random() * 500
        this._lighting(x1, y1, x2, y2, display);
    },

    _startDraw(x1, y1, x2, y2) {

        this._draw.moveTo(x1, y1);
        this._draw.lineTo(x2, y2);
        this._draw.stroke();
    },

    _lighting(x1, y1, x2, y2, displace) {

        if (displace < this._curDetail) {
            this._startDraw(x1, y1, x2, y2)
        } else {
            let mid_x = (x1 + x2) / 2
            let mid_y = (y1 + y2) / 2;
            mid_x += (Math.random() - 0.5) * displace;
            mid_y += (Math.random() - 0.5) * displace;
            this._lighting(x1, y1, mid_x, mid_y, displace / 2);
            this._lighting(x2, y2, mid_x, mid_y, displace / 2);
        }
    }
});
