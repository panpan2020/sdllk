cc.Class({
    extends: cc.Component,
    properties: {
        bg: cc.Node,
        richText: cc.RichText,

        _str_list: [],
        _running: false,
    },

    onLoad() {
        console.log("========1=======")
        this._str_list = [];
        this._running = false;

    },

    start() {
        this._str_list = [];
        // console.log("=======2======")
        this.unshowRichText(1);
    },

    addStrToList(str) {

        this._str_list.push(str);
        if (!this._running) {
            this.showRichText(this._str_list.shift());
        }
    },

    showRichText(str) {
        // console.log("=======showRichText===========",this.node.position)
        this._running = true;
        if(this.bg!=null&&this.bg.getComponent(cc.Animation)!=null){
            this.bg.getComponent(cc.Animation).play('notice');
        }

        this._enableNode(true);

        this.richText.string = str;
        let maskWidth = cc.find('Mask', this.node).width;

        // console.log("=======4======",str,maskWidth)

        this.richText.node.x = maskWidth / 2 * 1.6;

        console.log("=======5======", this.richText.node.x, this.richText.node.width, -maskWidth - this.richText.node.width);

        this.richText.node.runAction(cc.sequence(
            cc.moveBy(10, cc.v2(-maskWidth - this.richText.node.width - 100, 0)),
            cc.callFunc(() => {
                console.log("=======43=====", str)
                if (this._str_list.length > 0) {
                    this.showRichText(this._str_list.shift());
                }
                else {
                    this.unshowRichText(2);
                    this._running = false;
                }
            })
        ));

    },

    unshowRichText(from) {
        // console.log("---------stop----------", from)
        if (this.bg != null && this.bg.getComponent(cc.Animation) !=null) {
            this.bg.getComponent(cc.Animation).stop('notice');
        }
        this._enableNode(false);
    },

    _enableNode(flag) {
        for (let item of this.node.children) {
            item.active = flag;
        }
    }
});
