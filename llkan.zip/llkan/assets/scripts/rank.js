// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
       duanweiLab:cc.Label,
       zhanjiLab:cc.Label,
       closeBtn:cc.Button,
       scrollView:cc.ScrollView,
       itemPrefab:cc.Prefab
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.list=[];
        for(let i=1; i<10; i++){
            this.list.push(i);
        }
        this.content = this.scrollView.content;
        this.optItem = [];
        for(let j=0; j< 8; j++){
            let item = cc.instantiate(this.itemPrefab);
            this.content.addChild(item);
            this.optItem.push(item);
        }
        this.scrollView.node.on("scroll-ended",this.onToEnd.bind(this),this);
    },

    start () { 

        this.startIndex = 0;
        this.loadRecord(this.startIndex);
    },

    loadRecord(startIndex){
        this.startIndex = startIndex;
        for(let i=0; i< 8; i++){
            let mytable = this.optItem[i].getComponent("table");
            mytable.setLabContent({
                s1:"s1",
                s2:"s2",
                s3:"s3"
            });
        }
    },
    onToEnd(){
        this.loadScrollRecord();
        this.scrollView.elastic= true;
    },
    update (dt) {
        this.loadScrollRecord();
    },

    loadScrollRecord( ){
        if(this.start_index + this.PAGE_NUM * 3 < this.value_set.length &&
            this.content.y >= this.start_y + this.PAGE_NUM * 2 * this.HIGH)//content超过2个PAGE的高度
          {
              //_autoScrolling在引擎源码中负责处理scrollview的滚动动作
              if(this.scroll_view._autoScrolling){ //等自动滚动结束后再加载防止滚动过快，直接跳到非常后的位置
                  this.scroll_view.elastic = false; //关闭回弹效果 美观
                  return;
              }
              var down_loaded = this.PAGE_NUM; 
              this.start_index += down_loaded;
              
              if(this.start_index + this.PAGE_NUM * 3>this.value_set.length)
              {
                  //超过数据范围的长度
                  var out_len = this.start_index + this.PAGE_NUM * 3 - this.value_set.length;
                  down_loaded -= out_len;
                  this.start_index -= out_len;
              }
              this.load_recode(this.start_index);
              this.content.y -= down_loaded * this.HIGH;
              return;
          }
          //向上加载
          if(this.start_index>0 && this.content.y<=this.start_y)
          {
              if(this.scroll_view._autoScrolling){ 
                  this.scroll_view.elastic = false;
                  return;
               }
              var up_loaded = this.PAGE_NUM;
              this.start_index -= up_loaded;
              if(this.start_index<0){
                  up_loaded +=this.start_index;
                  this.start_index=0;
              }
              this.load_recode(this.start_index);
              this.content.y += up_loaded * this.HIGH;
          }
    }
});
